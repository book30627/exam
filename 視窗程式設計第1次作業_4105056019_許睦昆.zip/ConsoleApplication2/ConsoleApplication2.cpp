// ConsoleApplication1.cpp : �w�q�D���x���ε{�����i�J�I�C
//
/********
4105056019 �\���� �Ĥ@���@�~10/9
 *********/
#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include<fstream>
#include<string>
#include<ctype.h>

using namespace std;

int *chartonumber(char *);
int *charlength(char *);
void initialload();
void load(int*);
void map();
void topdown(int *, int *);
void leftright(int *, int *);
void topdownLR(int *, int *,int *);
void printcountry(int *);
void printspace();
void printprice(int *);
void location(int *);
void rolldice();
void landevent();
void build();
void gotojail();
void checkasset();
void sell(int *);
void sellhouse();
void sellland();
void store();
string *initialland = new string[40];
string *land = new string[40];
string *landpricestring = new string[40];
string *chancecard = new string[8];
string *communitycard = new string[8];
int *cardprice = new int[8]();
int *landpriceint = new int[40];
int *house = new int[40]();
int *jailcount = new int(3);
string *name = new string;
int *money = new int(0);
int *position = new int(0);
bool *buy = new bool[40]();
int *dice = new int(0);
int *key = new int(0);
int *buildland = new int(0);
int main()
{
	char *tempmoney = new char;
	cout << "�j�I�ιC��" << endl;
	cout << "�ϧθѻ�:" << endl;
	cout << "�H��:*" << endl;
	cout<<"�Фl:�b�g�a��H�Ʀr�Щ�1~4�Cex:���ƿ�1�A�N�����ƿ����@�ɩФl�A���]�h�O ^ ex:���ƿ�^" << endl;
	char *choose = new char;
	int *length = new int(0);
	int *num = new int(0);
	while (true)
	{
		cout << "���J���e�C���Ы�0�B���s�}�l�Ы�1" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			switch (*choose - '0')
			{
			case 0:
				initialload();
				load(num);
				break;
			case 1:
				*num = 1;
				initialload();
				load(num);
				*position = 0;
				cout << "�п�J���a�W��" << endl;
				getline(cin,*name);
				do {
					cout << "�п�J��l���B(�j��0)�A���঳�B�I�ơA��Ƴ̦h��9���)" << endl;
					cin.getline(tempmoney, 80, '\n');
					money = chartonumber(tempmoney);
				} while (*money <= 0);
				break;
			}
			if (*choose == '1' || *choose == '0'&& *key != 2)
				break;
		}
	}
	*num = 0;
	location(num);
	map();
	while (true)
	{
		cout << "�Y��l��J:y�A�s�ɿ�J:s�A���}��J:q" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			if (*choose == 'y') {
				rolldice();
				*num = 0;
				location(num);
				map();
				landevent();
				if (*key == 1)
					break;
				*num = 1;
				location(num);
				map();
			}
			else if (*choose == 's') {
				store();
				cout << "�s�ɦ��\" << endl;
			}
			else if (*choose == 'q') 
				break;
		}
	}
	if (*key == 1)
		cout << "Game Over" << endl;
	delete dice;
	delete buildland,key,num,choose,name,money,length, tempmoney,jailcount,position;
	delete[] landpricestring;
	delete[] landpriceint;
	delete[] land;
	delete[] initialland;
	delete[] communitycard;
	delete[] chancecard;
	delete[] cardprice;
	delete[] house;
	delete[] buy;
	chancecard = NULL; cardprice = NULL; communitycard = NULL; dice = NULL; buy = NULL; position = NULL; house = NULL; jailcount = NULL;
	tempmoney = NULL; length = NULL; money = NULL; name = NULL; initialland = NULL; land = NULL; landpriceint = NULL; landpricestring = NULL;
	choose = NULL; num = NULL; key = NULL; buildland = NULL;
	return 0;
}
int *chartonumber(char *c)
{
	int *i = new int(0);
	int *nint = new int(0);
	int *money = new int(0);
	int *length = new int(0);
	length = charlength(c);
	if (*length > 9) {
		*money = -1;
		return money;
	}
	else {
		while (*(c + *i) != '\0') {
			if (*(c + *i) < '0' || *(c + *i) > '9') {
				*nint = 1;
				break;
			}
			else
				*money = *money * 10 + *(c + *i) - '0';
			*i += 1;
		}
	}
	delete i,length;
	i = NULL, length = NULL;
	if (*nint == 1) {
		*money = -1;
		delete nint;
		nint = NULL;
		return money;
	}	
	else {
		delete nint;
		nint = NULL;
		return money;
	}
		
}
int *charlength(char *c) {
	int *i = new int(0);
	int *count = new int(0);
	while (*(c + *i) != '\0') {
		*i += 1;
		*count += 1;
	}
	delete i;
	i = NULL;
	return count;
}
void store() {
	//�W�� ���� ��m �g�a �Фl
	ofstream *ofilelandbuy = new ofstream("landbuy.txt", ios::out);
	int *i = new int(0);
	int *housecount = new int(0);
	int *landcount = new int(0);
	for (*i = 0; *i <= 39; *i+=1) {
		*ofilelandbuy << *(buy + *i);//�g�J�r��
		if (*(buy + *i) == 1)
			*landcount += 1;
		if(*i!=39)
			*ofilelandbuy<< endl;
	}
	ofilelandbuy->close();
	ofstream *ofileland = new ofstream("landrec.txt", ios::out);
	*i = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		*ofileland << *(land + *i);//�g�J�r��
		if (*i != 39)
			*ofileland << endl;
	}
	ofileland->close();
	ofstream *ofilehouse = new ofstream("houserec.txt", ios::out);
	 *i = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		*ofilehouse << *(house + *i);//�g�J�r��
		if (*(house + *i) > 0)
			*housecount += *(house + *i);
		if (*i != 39)
			*ofilehouse << endl;
	}
	ofilehouse->close();
	ofstream *ofileother = new ofstream("����.txt", ios::app);
	*ofileother <<"�m�W: "<< *name << "  ����: " << *money << " ��m: " << *position<<" �g�a��: "<<*landcount<<" �Ыμ�: "<<*housecount << endl;
	ofileother->close();
	ofstream *ofilekey = new ofstream("endrec.txt", ios::out);
	*ofilekey << *name << endl;
	*ofilekey << *money << endl;
	*ofilekey << *position;
	ofilekey->close();
	delete i,housecount,landcount,ofileother,ofilehouse,ofilelandbuy,ofileland,ofilekey;
	ofilekey = NULL; ofileland = NULL; ofilelandbuy = NULL; ofilehouse = NULL; ofileother = NULL; i = NULL; housecount = NULL; landcount = NULL;
}
void initialload() {
	int *i = new int(0);
	ifstream *ifileland = new ifstream("��l�Ƥg�a.txt", ios::in);
		while (!ifileland->eof()) {
			getline(*ifileland, *(initialland + *i), '\n');
			/*	cout << *i << endl;*/
			//	cout << *(initialland + *i) << endl;
			*i += 1;
		}
		ifileland->close();
		*i = 0;
		ifstream *ifileprice = new ifstream("��l�ƻ���.txt", ios::in);
		char *price = new char[80];
		int *cash = new int(0);
		while (!ifileprice->eof()) {
			getline(*ifileprice, *(landpricestring + *i), '\n');
			*i += 1;
		}
		ifileprice->close();
		*i = 0;
		ifstream *ifilepriceint = new ifstream("��l�ƻ���.txt", ios::in);
		while (ifilepriceint->getline(price, 80, '\n')) {
			cash = chartonumber(price);
			*(landpriceint + *i) = *cash;
			*i += 1;
		}
		ifilepriceint->close();
		*i = 0;
		int *j = new int(0);
		ifstream *ifilecard = new ifstream("��d.txt", ios::in);
		while (!ifilecard->eof()) {
			if (*i <= 7) {
				getline(*ifilecard, *(chancecard + *i), '\n');
			//cout << *(chancecard + *i) << endl;
			}
			else if (*i >7) {
				getline(*ifilecard, *(communitycard + *j), '\n');
			//	cout << *(communitycard + *j) << endl;
				*j += 1;
			}
			*i += 1;
		}
		ifilecard->close();
		*i = 0;
		ifstream *ifilecardprice = new ifstream("��d����.txt", ios::in);
		
		while (ifilecardprice->getline(price, 80, '\n')) {
			cash = chartonumber(price);
			*(cardprice + *i) = *cash;
			//cout << *(cardprice + *i)<< endl;
			*i += 1;
		}
		
		ifilecardprice->close();
		delete i,j,price,ifileland,ifileprice,ifilepriceint,ifilecardprice,ifilecard,cash;
		ifilecardprice = NULL; ifilecard = NULL; ifilepriceint = NULL; ifileprice = NULL; ifileland = NULL; cash = NULL; price = NULL; i = NULL; j = NULL;
}
void load(int *chose) {
	int *i = new int(0);
	if (*chose == 0) {
		ifstream *ifileland = new ifstream("landrec.txt", ios::in);
		if (ifileland->is_open()) {
			while (!ifileland->eof()) {
				getline(*ifileland, *(land + *i), '\n');
				*i += 1;
			}
			ifileland->close();
			*i = 0;
			ifstream *ifilelandbuy = new ifstream("landbuy.txt", ios::in);
			char *price = new char[80];
			int *cash = new int(0);
			while (ifilelandbuy->getline(price, 80, '\n')) {
				cash = chartonumber(price);
				*(buy + *i) = *cash;
				*i += 1;
			}
			ifilelandbuy->close();
			*i = 0;
			ifstream *ifilehouse = new ifstream("houserec.txt", ios::in);
			while (ifilehouse->getline(price, 80, '\n')) {
				cash = chartonumber(price);
				*(house + *i) = *cash;
				*i += 1;
			}
			ifilehouse->close();
			*i = 0;
			ifstream *ifilekey1 = new ifstream("endrec.txt", ios::in);
			while (!ifilekey1->eof()) {
				getline(*ifilekey1, *name, '\n');
				*i += 1;
				if (*i == 1)
					break;
			}
			ifilekey1->close();
			ifstream *ifilekey2 = new ifstream("endrec.txt", ios::in);
			*i = 0;
			while (ifilekey2->getline(price, 80, '\n')) {
				if (*i == 1)
				{
					cash = chartonumber(price);
					*money = *cash;
				}
				else if (*i == 2)
				{
					cash = chartonumber(price);
					*position = *cash;
				}
				*i += 1;
			}
			ifilekey2->close();
			delete price,cash,ifilekey2,ifilekey1,ifilehouse,ifileland,ifilelandbuy;
			ifilekey2 = NULL; ifilekey1 = NULL; ifilehouse = NULL; ifileland = NULL; ifilelandbuy = NULL; price = NULL; cash = NULL;
		}
		else {
		cout << "�d�L����" << endl;
		*key = 2;
		}
			
	}
	else if (*chose == 1) {
		ifstream *ifileland = new ifstream("��l�Ƥg�a.txt", ios::in);
		while (!ifileland->eof()) {
			getline(*ifileland, *(land + *i), '\n');
			*i += 1;
		}
		ifileland->close();
		remove("landrec.txt");
		remove("landbuy.txt");
		remove("houserec.txt");
		remove("����.txt");
		remove("endrec.txt");
		delete ifileland;
		ifileland = NULL;
	}
	delete i;
	i = NULL;
}
void rolldice() {
	string *enter = new string;
	int *one = new int(0);
	*dice = 0;
	srand((unsigned)time(NULL));
	*one = rand() % 6 + 1;
	*dice += *one;
	*one = rand() % 6 + 1;
	*dice += *one;
	cout <<"��l�Ʀr��: "<<*dice<<"  �п�Jenter���ܽT�{"<< endl;
	getline(cin, *enter,'\n');
	delete enter,one;
	one = NULL; enter = NULL;
}
void location(int *num) {
	if (*(house + *position) > 0) {
		if (*(house + *position) <= 4) {
			char *temp = new char;
			*temp = (*(house + *position) + '0');
			*(land + *position) = *(initialland + *position) + *temp;
			delete temp;
		}
		else if(*(house + *position) == 5)
			*(land + *position) = *(initialland + *position) + '^';
	}
	else
	*(land + *position) = *(initialland + *position);
	if(*num==0)
	*position += *dice;
	if (*position > 39) {
		*position -= 40;
		if (*position != 0)
			*money += 2000;
	}
	*(land + *position) +=  "*";
}
void landevent() {
	char *choose = new char(0);
	int *length = new int(0);
	if (*position != 2 && *position != 5 && *position != 12 && *position != 15 && *position != 25 && *position != 28 && *position != 35 && *position != 38)
	{
		if (*(landpriceint + *position) != -1&& *position !=0) {
			if (*(buy + *position) == 0) {
				while (true)
				{
					cout <<"��F"<<*(initialland+*position) <<"�O�_�n�R�U���g�a�A��J(y)���ܭn�A��J(n)���ܤ��n" << endl;
					cin.getline(choose, 80, '\n');
					length = charlength(choose);
					if (*length == 1) {
						if (*choose == 'y') {
							if (*money < *(landpriceint + *position)) {
								cout << "�ѩ���������ݶi����" << endl;
								*buildland = 1;
								sell((landpriceint + *position));
								if (*buildland ==3) {
									*(buy + *position) = 1;
								string *enter = new string;
								cout << "�ʶR���\" << endl;
								cout << "�п�Jenter���ܽT�{" << endl;
								getline(cin, *enter, '\n');
								delete enter;
								enter = NULL;
								}
								*buildland = 0;
							}
							else {
								*money -= *(landpriceint + *position);
								*(buy + *position) = 1;
								string *enter = new string;
								cout << "�ʶR���\" << endl;
								cout << "�п�Jenter���ܽT�{" << endl;
								getline(cin, *enter, '\n');
								delete enter;
								enter = NULL;
							}
							break;
						}
						else if (*choose == 'n')
							break;
					}
				}
			}
			else
				build();
		}
		else {
			if (*(initialland + *position) == "  ���c") {
				cout << "��F" << *(initialland + *position) << endl;
				gotojail();
			}
			else if (*(initialland + *position) == "  ���|") {
				cout << "��F" << *(initialland + *position) << endl;
				string *enter = new string;
				int *one = new int(0);
				srand((unsigned)time(NULL));
				*one = rand() % 8;
				cout << "���: " << *(chancecard + *one) << endl;
				cout << "�o��" << *(cardprice + *one) << "��" << endl;	
				cout << "�п�Jenter���ܽT�{" << endl;
				getline(cin, *enter, '\n');
				*money += *(cardprice + *one);
				delete enter,one;
				enter = NULL; one = NULL;
			}
			else if (*(initialland + *position) == "  �R�B") {
				cout << "��F" << *(initialland + *position) << endl;
				string *enter = new string;
				int *one = new int(0);
				srand((unsigned)time(NULL));
				*one = rand() % 8;
				cout << "���: " << *(communitycard + *one) << endl;
				cout << "�o��" << *(cardprice + *one) << "��" << endl;
				cout << "�п�Jenter���ܽT�{" << endl;
				getline(cin, *enter, '\n');
				*money += *(cardprice + *one);
				delete enter,one;
				enter = NULL; one = NULL;
			}
			else {
				cout << "��F" << *(initialland + *position) << endl;
				string *enter = new string;
				cout << "�п�Jenter���ܽT�{" << endl;
				getline(cin, *enter, '\n');
				delete enter;
				enter = NULL;
			}
				
		}
	}
	else {
		cout << "��F" << *(initialland + *position) << endl;
		string *enter=new string;
		cout <<"��ú��"<<*(initialland + *position) <<": "<< *(landpriceint + *position)<<"��"<< endl;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		if (*money < *(landpriceint + *position)){
		checkasset();
		if (*key == 1)
			return;
		*buildland = 0;
		sell((landpriceint + *position));
		cout << "�w�v��" << endl;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		}
		else
			*money -= *(landpriceint + *position);
		delete enter;
		enter = NULL;
	}
	delete length,choose;
	choose = NULL; length = NULL;
}
void checkasset() {
	int *i = new int(0);
	int *num = new int(0);
	string *enter = new string;
	for (*i = 0; *i <= 39; *i += 1) {
		if (*(buy + *i) == 1) {
			if (*(house + *i) > 0) {
				if (*(landpriceint + *i) >= 3000)
					*num += 1000 * *(house + *i);
				else
					*num += 500 * *(house + *i);
			}
			*num+= *(landpriceint + *i) / 2;
		}
	}
	*num += *money;
	if (*num < *(landpriceint + *position)) {
		cout << "�ثe�]���`�B�p���ú����B�A�}��  �C������" << endl;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		*key = 1;
		return;
	}
	delete enter,num,i;
	i = NULL; num = NULL; enter = NULL;
}
void sell(int *price) {
	int *i = new int(0);
	string *enter = new string;
	char *choose = new char;
	int  *length = new int;
	int *num = new int(0);
	for (*i = 0; *i <= 39; *i += 1) {
		if (*(buy + *i) == 1) {
			*num=1;
			break;
		}	
	}
	if (*num == 0) {
		cout << "�L����F�����i����" << endl;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		return;
	}
	while (true)
	{
		cout << "�ѩ���������ݭn�i����A�ЫΡB�g�a���N����Ӫ��@�b" << endl;
		if(*buildland==0)
		cout << "���ﶵ:�Фl:1�B�g�a:2" << endl;
		else if(*buildland==1)
		cout << "���ﶵ:�Фl:1�B�g�a:2�B���}:q" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			if (*choose == '1') {
				sellhouse();
			}
			else if(*choose == '2')
			{
				sellland();
			}
			if (*buildland == 1 && *choose == 'q')
					break;
			if (*money >= *price) {
				cout << "�I�M" << endl;
				*money -= *price;
				*buildland = 3;
				break;
			}
		 }
	}
	delete i,enter,choose,length,num;
	enter = NULL; choose = NULL; length = NULL; num = NULL; i = NULL;
}
void sellland() {
	string *enter = new string;
	char *choose = new char;
	int  *length = new int;
	int *num = new int(0);
	int *i = new int(0);
	while (true)
	{
		cout << "�п�J�Q�c�檺�g�a�W�١A���}�Ы�q" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			if (*choose == 'q')
				break;
		}
		else {
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(initialland + *i) == choose) {
					*num = 1;
					if (*(buy + *i) == 1) {
						if (*(house + *i) > 0)
							cout << "���g�a�W���Фl�A�Х��槹�Фl�A��g�a" << endl;
						else if (*(house + *i) == 0) {
							*(buy + *i) = 0;
							int *mode = new int(1);
							cout << "�w��X" << endl;
							cout << "�п�Jenter���ܽT�{" << endl;
							getline(cin, *enter, '\n');
							*money += *(landpriceint + *i)/2;
							location(mode);
							map();
							delete mode;
							mode = NULL;
						}	
					}
					else
						cout << "���g�a�ä��A�֦���" << endl;
					break;
				}
			}
			if (*num == 0)
				cout << "�õL���g�a" << endl;
		}
		
	}
	delete i, enter, choose, length, num;
	enter = NULL; choose = NULL; length = NULL; num = NULL; i = NULL;
}
void sellhouse() {
	char *choose = new char;
	int  *length = new int;
	int *num = new int(0);
	int *i = new int(0);
	while (true)
	{
		cout << "�п�J�Q�c��Фl���g�a�W�١A���}�Ы�q" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			if (*choose == 'q')
				break;
		}
		else {
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(initialland + *i) == choose ) {
					*num = 1;
					if (*(buy + *i) == 1) {
						if (*(house + *i) > 0) {
							while (true) {
								cout << "�п�J�Q�c��Фl���ƶq�A���}�Ы�q" << endl;
								cin.getline(choose, 80, '\n');
								length = charlength(choose);
								if (*length == 1) {
									int *housenum = new int(0);
									if (*choose > '0'&&*choose < '9') {
										*housenum = *choose - '0';
										if (*housenum > *(house + *i))
											cout << "�Ыμƶq����" << endl;
										else if (*housenum > 0 && *housenum <= *(house + *i)) {
											cout << "�w�c��"<<*housenum<<"�ɩФl" << endl;
											*(house + *i) -= *housenum;
											if (*(landpriceint + *i) >= 3000)
												*money += *housenum * 1000;
											else
												*money += *housenum * 500;
											if (*(house + *i) > 0) {
												char *temp = new char;
												*temp = (*(house + *i) + '0');
												*(land + *i) = *(initialland + *i) + *temp;
												delete temp;
												temp = NULL;
											}
											else if (*(house + *i) == 0) 
												*(land + *i) = *(initialland + *i);
											int *mode = new int(1);
											location(mode);
											map();
											delete mode;
											mode = NULL;
										}
										else if (*housenum == 0)
											cout << "�L�c�����Фl" << endl;
									}
									else if (*choose == 'q')
										break;
									delete housenum;
									housenum = NULL;
								}
							}
						}
						else
							cout << "���g�a�õL�Фl" << endl;
					}
					else
						cout << "���g�a�ä��O�A�֦���" << endl;
					break;
				}
			}
			if (*num == 0)
				cout << "�L���g�a" << endl;
		}
	}
	delete i, choose, length, num;
	choose = NULL; length = NULL; num = NULL; i = NULL;
}
void gotojail() {
	string *enter = new string;
	char *choose = new char;
	int  *length = new int;
	int *num = new int(1);
	cout << "���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����" << endl;
	cout << "�п�Jenter���ܽT�{" << endl;
	getline(cin, *enter, '\n');
	*(land + *position) = *(initialland + *position);
	*position = 10;
	*jailcount = 3;
	while (true)
	{
		if (*jailcount == 0) {
		cout << "�X��" << endl;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
			break;
		}
			
		cout << "���Y�T����l�A��J:y" << endl;
		cin.getline(choose, 80, '\n');
		length = charlength(choose);
		if (*length == 1) {
			if (*choose == 'y') {
				rolldice();
				*jailcount -= 1;
				location(num);
				map();
				if(jailcount>0)
				cout << "�ثe�b���c�A�٦�" << *jailcount << "�^�X" << endl;
				
			}
		}
	}
	delete enter,choose, length, num;
	enter = NULL;  choose = NULL; length = NULL; num = NULL;
}
void build() {
	char *choose = new char(0);
	int *length = new int(0);
	int *houseprice = new int(0);
	if (*(house + *position) <= 4) {
		while (true)
		{
			cout << "�Ыλ���: ";
			if (*(landpriceint + *position) < 3000) {
				*houseprice = 1000;
				cout << *houseprice << endl;
			}
			else {
				*houseprice = 2000;
				cout << *houseprice << endl;
			}
			cout<<"��F" << *(initialland + *position) << "�O�_�n�\�Фl�A��J(y)���ܭn�A��J(n)���ܤ��n" << endl;
			cin.getline(choose, 80, '\n');
			length = charlength(choose);
			if (*length == 1) {
				if (*choose == 'y') {
					if (*money < *houseprice) {
						cout << "�ѩ���������ݶi����" << endl;
						*buildland = 1;
						sell(houseprice);
						if (*buildland == 3) {
							char *temp = new char;
							*(house + *position) += 1;
							if (*(house + *position) < 4) {
								*temp = (*(house + *position) + '0');
								*(land + *position) = *(initialland + *position) + *temp;
							}
							else if (*(house + *position) == 5) {
								*(land + *position) = *(initialland + *position) + '^';
							}
						string *enter = new string;
						cout << "�\�Ц��\" << endl;
						cout << "�п�Jenter���ܽT�{" << endl;
						getline(cin, *enter, '\n');
						delete enter,temp;
						temp = NULL; enter = NULL;
						}
						*buildland = 0;
					}
					else {
						char *temp = new char;
						*money -= *houseprice;
						*(house + *position) += 1;
						if (*(house + *position) < 4) {
							*temp = (*(house + *position) + '0');
							*(land + *position) = *(initialland + *position) + *temp;
						}
						else if (*(house + *position) == 5) {
							*(land + *position) = *(initialland + *position) + '^';
						}
						string *enter = new string;
						cout << "�\�Ц��\" << endl;
						cout << "�п�Jenter���ܽT�{" << endl;
						getline(cin, *enter, '\n');
						delete enter,temp;
						temp = NULL; enter = NULL;
					}
					break;
				}
				else if (*choose == 'n')
					break;
			}
		}
	}
	else {
		string *enter = new string;
		cout << "�w�g�L�k�A�\�Фl�A�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		delete enter;
		enter = NULL;
	}
	delete length,houseprice,choose;
	houseprice = NULL; choose = NULL; length = NULL;
}
void map() {
	system("CLS");
	int *begin = new int(20);
	int *end = new int(30);
	int *turn = new int(1);
	topdown(begin, end);
	topdownLR(begin, end,turn);
	*turn = 2;
	topdownLR(begin, end, turn);
	topdown(begin, end);
	*begin = 19;
	*end = 11;
	leftright(begin,end);
	*begin = 10;
	*end = 0;
	topdown(end, begin);
	*turn = 3;
	topdownLR(begin, end, turn);
	*turn = 4;
	topdownLR(begin, end, turn);
	topdown(end, begin);
	cout << endl;
	cout << "����W: " << *name << "  �{������: " << *money << endl;
	cout << "�{���g�a: ";
	int *i = new int(0);
	for (*i = 0; *i <= 39; *i += 1) {
		if (*(buy + *i) == 1)
			cout << *(initialland + *i) << "  ";
	}
	cout << endl;
	delete i,begin,turn,end;
	begin = NULL; turn = NULL; end = NULL; i = NULL;
}
void topdown(int *begin, int *end) {
	int *i = new int(0);
	for (*i = *begin; *i <= *end; *i += 1) {
		cout.width(9);
		cout << "�@�@�@�@";
	}
	cout << endl;
	delete i;
	i = NULL;
}
void leftright(int *begin, int *end) {
	int *i = new int(0);
	int *difference = new int(12);//20,32
	int *temp = new int(0);
	for (*i = *begin; *i >= *end; *i-=1) {
		*temp = *i + *difference;
		printcountry(i);
		printspace();
		printcountry(temp);
		cout << endl;
		printprice(i);
		printspace();
		printprice(temp);
		cout << endl;
		if (*i == *end)
			break;
		cout.width(9);
		cout << "�@�@�@�@";
		printspace();
		cout.width(9);
		cout << "�@�@�@�@";
		cout << endl;
		*difference += 2;
	}
	delete temp,difference,i;
	i = NULL; difference = NULL; temp = NULL;
}
void printcountry(int *index) {
	cout << "|";
	cout.setf(ios::left);//�V�����
	cout.width(8);
	cout << *(land + *index);
	cout.unsetf(ios::left); //�����V������覡
	cout << "|";
}
void printspace() {
	int *i = new int(0);
	for (*i = 0; *i < 9; *i += 1) {
		if(*i==8)
			cout << "        ";
		else
			cout << "         ";
	}
	delete i;
	i = NULL;
}
void printprice(int *index) {
	cout << "|";
	cout.width(6);
	cout << *(landpricestring + *index);
	cout.width(3);
	cout << "|";
}
void topdownLR(int *begin, int *end,int *turn) {
	int *i = new int(0);
	if (*turn == 1 || *turn == 2) {
		for (*i = *begin; *i <= *end; *i += 1) {
			cout << "|";
			if (*turn == 1) {
				cout.setf(ios::left);//�V�����
				cout.width(8);
				cout << *(land + *i);
				cout.unsetf(ios::left); //�����V������覡
			}
			else if (*turn == 2) {
				cout.width(6);
				cout << *(landpricestring + *i);
				cout.width(3);
			}
			if (*i == 30)
				cout << "|";
		}
	}
	else if (*turn == 3 || *turn == 4) {
		for (*i = *begin; *i >=*end; *i -= 1) {
			cout << "|";
			if (*turn == 3) {
				cout.setf(ios::left);//�V�����
				cout.width(8);
				cout << *(land + *i);
				cout.unsetf(ios::left); //�����V������覡
			}
			else if (*turn == 4) {
				cout.width(6);
				cout << *(landpricestring + *i);
				cout.width(3);
			}
			if (*i == 0)
				cout << "|";

		}
	}
	cout << endl;
	delete i;
	i = NULL;
}

