#pragma once

namespace ConsoleApplication1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// MyForm ���K�n
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		Label^ meglabel = gcnew Label();
		array<Label^>^ labelland = gcnew array<Label^>(40);
		array<PictureBox^>^ rolepic = gcnew array<PictureBox^>(4);
		array<PictureBox^>^ housepic = gcnew array<PictureBox^>(40);
		array<Button^>^ op = gcnew array<Button^>(4);
		array<Label^>^ labelbutton = gcnew array<Label^>(4);
		array<Label^>^ labelname = gcnew array<Label^>(4);
		array<Label^>^ labelmoney = gcnew array<Label^>(4);
		MenuStrip^ gm = gcnew  MenuStrip();

		array<String^>^ initialland = gcnew array<String^>(40);
		array<String^>^ otherplayerec = gcnew array<String^>(3);
		array<int>^ landprice = gcnew array<int>(40);
		array<String^>^ alt = gcnew array<String^>(3);
		array<int>^ house = gcnew array<int>(40);
		array<int>^ money = gcnew array<int>(4);// { 20000, 20000, 20000, 20000 };
		array<int>^ position = gcnew array<int>(4);
		String^ name;
		array<int>^ buy = gcnew array<int>(40);
		array<int>^ jailn = gcnew array<int>(4);
		String^ majorpic;
		int ^turn = 0;
		int ^dice = 0;
		int ^playern = 0;
		int ^controldice = -1;
	public:



	public:

			 int^lasturn = 0;
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->SuspendLayout();
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(582, 523);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
		Label^ enterlabel = gcnew Label();
		array<Button^>^ recordbutton = gcnew array<Button^>(3);
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		enterlabel->Text = L"�j�I��";
		enterlabel->AutoSize = false;
		enterlabel->BorderStyle = System::Windows::Forms::BorderStyle::None;
		enterlabel->Font = (gcnew System::Drawing::Font(L"�s�ө���", 30, System::Drawing::FontStyle::Regular));
		enterlabel->Location = System::Drawing::Point(150, 100);
		enterlabel->Size = System::Drawing::Size(180, 50);
		this->Controls->Add(enterlabel);
		int ^startx = 50, ^starty = 200;
		for (int ^i = 0; *i < 3; *i += 1) {
			recordbutton[*i] = gcnew Button();
			recordbutton[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
			recordbutton[*i]->Location = System::Drawing::Point(*startx, *starty);
			recordbutton[*i]->Size = System::Drawing::Size(90, 50);
			recordbutton[*i]->UseVisualStyleBackColor = true;
			if (*i == 0) {
				recordbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::prerecord_Click);
				recordbutton[*i]->Text = L"���J���e����";
			}
			else if (*i == 1) {
				recordbutton[*i]->Text = L"�s�C��";
				recordbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::new_Click);
			}
			else if (*i == 2) {
				recordbutton[*i]->Text = L"�W�h����";
				recordbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::explain_Click);
			}
			*startx += 120;
			this->Controls->Add(recordbutton[*i]);
		}
	}
	private: System::Void explain_Click(System::Object^  sender, System::EventArgs^  e) {
		MessageBox::Show(L"�_�l:\n�q����l���B��20000���A���a�i�ۦ�]�w��l���B�ΦW���٦��Ϯ�"+
			L"�C\n�g�a:\n���a�����ʶR���g�a�A�P���I���C��ۦP�H���@����O�C\n�`�N:\n�Y�h�H�b�P"+
			L"�@���g�a�W�ȷ|��ܤ@�H���ϮסC\nGM:\n�������l�B�����B���c���A3�ءA�ϥα����l"+
			L"�O�o�٭n�I���Y��l���s�A�~�|�Ϩ���e�i��ت��a�C", L"�W�h");
	}
	private: System::Void prerecord_Click(System::Object^  sender, System::EventArgs^  e) {
			if (File::Exists("house.txt")) {
				this->Controls->Remove(recordbutton[0]);
				this->Controls->Remove(recordbutton[1]);
				this->Controls->Remove(recordbutton[2]);
				this->Controls->Remove(enterlabel);
				StreamReader^ infor = gcnew StreamReader("infor.txt");
				String^ line;
				int ^i = 0;
				while ((line = infor->ReadLine()) != nullptr)
				{
					alt[*i] = line;
					*i += 1;
				}
				infor->Close();
				name = alt[0];
				*playern = Int32::Parse(alt[1]);
				majorpic = alt[2];
				*i = 0;
				StreamReader^ hou = gcnew StreamReader("house.txt");
				while ((line = hou->ReadLine()) != nullptr)
				{
					house[*i] = Int32::Parse(line);
					*i += 1;
				}
				hou->Close();
				*i = 0;
				StreamReader^ by = gcnew StreamReader("buy.txt");
				while ((line = by->ReadLine()) != nullptr)
				{
					buy[*i] = Int32::Parse(line);
					*i += 1;
				}
				by->Close();
				*i = 0;
				StreamReader^ jai = gcnew StreamReader("jail.txt");
				while ((line = jai->ReadLine()) != nullptr)
				{
					jailn[*i] = Int32::Parse(line);
					*i += 1;
				}
				jai->Close();
				*i = 0;
				StreamReader^ mon = gcnew StreamReader("money.txt");
				while ((line = mon->ReadLine()) != nullptr)
				{
					money[*i] = Int32::Parse(line);
					*i += 1;
				}
				mon->Close();
				*i = 0;
				StreamReader^ pos = gcnew StreamReader("position.txt");
				while ((line = pos->ReadLine()) != nullptr)
				{
					position[*i] = Int32::Parse(line);
					*i += 1;
				}
				pos->Close();
				submain(0);
			}
			else
			{
				MessageBox::Show(L"�d�L����", L"�T��");
			}
	}
			 array<Label^>^ informationlabel = gcnew  array<Label^>(3);
			 array<TextBox^>^ information = gcnew array<TextBox^>(3);
			 Button^ check = gcnew Button();
	private: System::Void new_Click(System::Object^  sender, System::EventArgs^  e) {
		this->Controls->Remove(recordbutton[0]);
		this->Controls->Remove(recordbutton[1]);
		this->Controls->Remove(recordbutton[2]);
		this->Controls->Remove(enterlabel);
		File::Delete("buy.txt");
		File::Delete("house.txt");
		File::Delete("infor.txt");
		File::Delete("jail.txt");
		File::Delete("money.txt");
		File::Delete("position.txt");
		int ^startx = 150, ^starty = 50;
		for (int ^i = 0; *i < 3; *i += 1) {
			informationlabel[*i] = gcnew Label();
			if (*i == 0)
				informationlabel[*i]->Text = L"�п�J���a�W��(�ݤp�󤭭Ӧr)";
			else if (*i == 1)
				informationlabel[*i]->Text = L"�п�J��l���B(�j��0)�A���঳�B�I�ơA��Ƴ̦h��9���)";
			else if (*i == 2)
				informationlabel[*i]->Text = L"�п�J���a���ƶq2~4";
			informationlabel[*i]->AutoSize = false;
			informationlabel[*i]->BorderStyle = System::Windows::Forms::BorderStyle::None;
			informationlabel[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10, System::Drawing::FontStyle::Regular));
			informationlabel[*i]->Location = System::Drawing::Point(*startx, *starty);
			informationlabel[*i]->Size = System::Drawing::Size(280, 40);
			this->Controls->Add(informationlabel[*i]);
			*starty += 40;
			information[*i]= gcnew TextBox();
			information[*i]->BorderStyle = System::Windows::Forms::BorderStyle::None;
			information[*i]->Location = System::Drawing::Point(*startx, *starty);
			information[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
			information[*i]->Size = System::Drawing::Size(100, 40);
			*starty += 60;
			this->Controls->Add(information[*i]);
		}
		check->Text = L"�T�{";
		check->Location = System::Drawing::Point(150, 350);
		check->Size = System::Drawing::Size(100, 40);
		check->Click += gcnew System::EventHandler(this, &MyForm::check_Click);
		this->Controls->Add(check);
	}
	private: System::Void check_Click(System::Object^  sender, System::EventArgs^  e) {
		int ^ok = 1;
		if (information[0]->Text->Length > 5|| information[0]->Text->Length==0) {
			information[0]->BackColor = System::Drawing::Color::Red;
			*ok = 0;
		}//�W�r
		else
			information[0]->BackColor = System::Drawing::Color::White;
		if (information[1]->Text->Length > 9|| information[1]->Text->Length==0) {
			information[1]->BackColor = System::Drawing::Color::Red;
			*ok = 0;
		}//����
		else
		{
			if (!*(isdigit(information[1]->Text))) {
				information[1]->BackColor = System::Drawing::Color::Red;
				*ok = 0;
			}
			else
			{
				information[1]->BackColor = System::Drawing::Color::White;
			}
		}

		if (information[2]->Text->Length == 1) {
			if (information[2]->Text[0] - '0' < 2 || information[2]->Text[0] - '0' > 4) {
				information[2]->BackColor = System::Drawing::Color::Red;
				*ok = 0;
			}
			else
				information[2]->BackColor = System::Drawing::Color::White;
		}//���a�H��
		else {
			information[2]->BackColor = System::Drawing::Color::Red;
			*ok = 0;
		}
		if (*ok == 1) {
			name = information[0]->Text;
			money[0] = Int32::Parse(information[1]->Text);
			*playern = Int32::Parse(information[2]->Text);
			for (int ^i = 0; *i < 3; *i += 1) {
				this->Controls->Remove(information[*i]);
				this->Controls->Remove(informationlabel[*i]);
			}
			this->Controls->Remove(check);
			delete[]information;
			delete[]informationlabel;
			delete check;
			chooseroleimage();
		}
	}
	private: System::Void rolldice_Click(System::Object^  sender, System::EventArgs^  e) {
		//�D�n���a
		int^num = 0;
		int^eventn = 0;
		for (int ^i = 0; *i<4; *i += 1)
			op[*i]->Enabled = false;
		rolldice();
		labelbutton[0]->Text = L"�I��:" + dice->ToString();
		if (jailn[0] > 0) {
			jailn[0] -= 1;
			MessageBox::Show(L"�٦�"+ jailn[0].ToString()+L"�^�X", L"�T��");
		}
		else {
			locate(num);
			eventn = landevent();
			if (*eventn == 2)
				jailn[0] = 3;
			refreshlabelmoney();
		}
		if (*eventn == 1) {
			MessageBox::Show(L"�C������", L"�T��");
			gm->Enabled = false;
		}
		else {
			*turn += 1;
			otherplayer();
		}
		
	}
	private: System::Void save_Click(System::Object^  sender, System::EventArgs^  e) {
		//�s��
		int ^i = 0;
		StreamWriter^ pos = gcnew StreamWriter("position.txt");
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				pos->Write(position[*i].ToString());
			else
				pos->WriteLine(position[*i].ToString());
		}
		pos->Close();
		StreamWriter^ jai = gcnew StreamWriter("jail.txt");
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				jai->Write(jailn[*i].ToString());
			else
				jai->WriteLine(jailn[*i].ToString());
		}
		jai->Close();
		StreamWriter^ mon = gcnew StreamWriter("money.txt");
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				mon->Write(money[*i].ToString());
			else
				mon->WriteLine(money[*i].ToString());
		}
		mon->Close();
		StreamWriter^ by = gcnew StreamWriter("buy.txt");
		for (*i = 0; *i < 40; *i += 1) {
			if (*i == 39)
				by->Write(buy[*i].ToString());
			else
				by->WriteLine(buy[*i].ToString());
		}
		by->Close();
		StreamWriter^ hou = gcnew StreamWriter("house.txt");
		for (*i = 0; *i < 40; *i += 1) {
			if (*i == 39)
				hou->Write(house[*i].ToString());
			else
				hou->WriteLine(house[*i].ToString());
		}
		hou->Close();
		StreamWriter^ infor = gcnew StreamWriter("infor.txt");
		infor->WriteLine(name);
		infor->WriteLine(playern);
		infor->Write(majorpic);
		infor->Close();
		MessageBox::Show(L"�s�ɦ��\", L"�T��");
	}
	 private: System::Void show_Click(System::Object^  sender, System::EventArgs^  e) {
		//�D�n����
		 StreamReader^ ld = gcnew StreamReader("����.txt");
		 String^ line;
		 ListBox^ rec = gcnew  ListBox();
		 
		 while ((line = ld->ReadLine()) != nullptr)
		 {
			 rec->Items->Add(line);
		 }
		 ld->Close();
		 Form^ record = gcnew Form;
		 record->MaximizeBox = false;
		 record->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		 record->Size = System::Drawing::Size(500, 600);
		 rec->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular));
		 rec->Size = System::Drawing::Size(record->Width, record->Height);
		 record->Show();
		 record->Controls->Add(rec);
	}
	private: System::Void close_Click(System::Object^  sender, System::EventArgs^  e) {
				  //���}
		Application::Exit();
	}
			 TextBox^ getdice;// = gcnew TextBox;
			 Form^ rd;
	private: System::Void controlrolldice_Click(System::Object^  sender, System::EventArgs^  e) {
		Button^ getdiceenter = gcnew Button;
		getdice = gcnew TextBox;
		rd = gcnew Form;
		rd->MaximizeBox = false;
		rd->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		rd->Size = System::Drawing::Size(400, 100);
		getdice->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular));
		getdice->Size= System::Drawing::Size(400, 20);
		getdice->Text = L"��J���w��l���Ʀr(����O�p�ƩM�W�L40)";
		getdice->Click += gcnew System::EventHandler(this, &MyForm::mcdicenter_Click);
		getdiceenter->Text = L"�T�{";
		getdiceenter->Location = System::Drawing::Point(320,30);
		getdiceenter->Size = System::Drawing::Size(60, 25);
		getdiceenter->Click += gcnew System::EventHandler(this, &MyForm::dicenter_Click);
		rd->Show();
		rd->Controls->Add(getdice);
		rd->Controls->Add(getdiceenter);
	}
	private: System::Void mcdicenter_Click(System::Object^  sender, System::EventArgs^  e) {
		if (getdice->Text == "��J���w��l���Ʀr(����O�p�ƩM�W�L40)")
			getdice->Text = "";
		else if (getdice->Text == "�L�Ŀ�J")
			getdice->Text = "";
	}
	private: System::Void dicenter_Click(System::Object^  sender, System::EventArgs^  e) {
		if (getdice->Text->Length <= 2 && *(isdigit(getdice->Text)) && getdice->Text->Length != 0) {
			if (Int32::Parse(getdice->Text) >= 0 && Int32::Parse(getdice->Text) <= 40) {
				*controldice = Int32::Parse(getdice->Text);
				rd->Close();
				
			}
			else
				getdice->Text = L"�L�Ŀ�J";
		}
		else
			getdice->Text = L"�L�Ŀ�J";
	}
	 private: System::Void controlmoney_Click(System::Object^  sender, System::EventArgs^  e) {
				 Button^ getmoneyenter = gcnew Button;
				 getdice = gcnew TextBox;
				 rd = gcnew Form;
				 rd->MaximizeBox = false;
				 rd->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
				 rd->Size = System::Drawing::Size(400, 100);
				 getdice->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular));
				 getdice->Size = System::Drawing::Size(400, 20);
				 getdice->Text = L"��J�n�W�[���B(����W�L9��ơB�p�ơB�t��)";
				 getdice->Click += gcnew System::EventHandler(this, &MyForm::mcmoneyenter_Click);
				 getmoneyenter->Text = L"�T�{";
				 getmoneyenter->Location = System::Drawing::Point(320, 30);
				 getmoneyenter->Size = System::Drawing::Size(60, 25);
				 getmoneyenter->Click += gcnew System::EventHandler(this, &MyForm::moneyenter_Click);
				 rd->Show();
				 rd->Controls->Add(getdice);
				 rd->Controls->Add(getmoneyenter);
	}
	private: System::Void mcmoneyenter_Click(System::Object^  sender, System::EventArgs^  e) {
		if (getdice->Text == "��J�n�W�[���B(����W�L9��ơB�p�ơB�t��)")
			getdice->Text = "";
		else if(getdice->Text == "�L�Ŀ�J")
			getdice->Text = "";
	}
	private: System::Void moneyenter_Click(System::Object^  sender, System::EventArgs^  e) {
		if (getdice->Text->Length <= 9 && *(isdigit(getdice->Text)) && getdice->Text->Length != 0) {
			if (Int32::Parse(getdice->Text) >= 0) {
				money[0] += Int32::Parse(getdice->Text);
				rd->Close();
				refreshlabelmoney();
			}
			else
				getdice->Text = L"�L�Ŀ�J";
		}
		else
			getdice->Text = L"�L�Ŀ�J";
	}
	private: System::Void controljail_Click(System::Object^  sender, System::EventArgs^  e) {
		Button^ cancelljail = gcnew Button;
		rd = gcnew Form;
		rd->MaximizeBox = false;
		rd->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		rd->Size = System::Drawing::Size(400, 100);
		cancelljail->Text = L"�Ѱ����c";
		cancelljail->Location = System::Drawing::Point(160, 10);
		cancelljail->Size = System::Drawing::Size(80, 40);
		cancelljail->Click += gcnew System::EventHandler(this, &MyForm::jailenter_Click);
		rd->Show();
		rd->Controls->Add(cancelljail);
	}
	private: System::Void jailenter_Click(System::Object^  sender, System::EventArgs^  e) {
		rd->Close();
		jailn[0] = 0;
	}
			 array<Button^>^  chose = gcnew array<Button^>(2);
	private: System::Void choserolepic_Click(System::Object^  sender, System::EventArgs^  e) {
		OpenFileDialog ^opd = gcnew OpenFileDialog;
		if (opd->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			System::IO::File::Copy(opd->FileName, opd->SafeFileName);
			majorpic = opd->SafeFileName;
			this->Controls->Remove(chose[0]);
			this->Controls->Remove(chose[1]);
			submain(1);
		}
	}
	private: System::Void defaultrolepic_Click(System::Object^  sender, System::EventArgs^  e) {
		majorpic = "1.png";
		this->Controls->Remove(chose[0]);
		this->Controls->Remove(chose[1]);
		submain(1);
	}
			 bool^ isdigit(String ^num) {
				 int ^i = 0;
				 bool ^ok = true;
				 while (*i < num->Length) {
					 if (num[*i] - '0' < 0 || num[*i] - '0'>9) {
						 *ok = false;
						 break;
					 }
					 *i += 1;
				 }
				 return ok;
			 }
			 void chooseroleimage() {
				 int ^startx = 100, ^starty = 200;
				 for (int ^i = 0; *i < 2; *i += 1) {
					 chose[*i] = gcnew  Button();
					 chose[*i]->Location = System::Drawing::Point(*startx, *starty);
					 chose[*i]->Size = System::Drawing::Size(90, 50);
					 if (*i == 0) {
						 chose[*i]->Text = L"��ܨ���Ϯ�";
						 chose[*i]->Click += gcnew System::EventHandler(this, &MyForm::choserolepic_Click);
					 }
					 else {
						 chose[*i]->Text = L"�ϥιw�]�Ϯ�";
						 chose[*i]->Click += gcnew System::EventHandler(this, &MyForm::defaultrolepic_Click);
					 }
					 this->Controls->Add(chose[*i]);
					 *startx += 150;
				 }
			 }
			 void submain(int ^num) {
				 initialload();
				 otherinitial();
				 map(num);
				 createbutton();
				 maphouse();
				 namemoney(num);
				 array<ToolStripMenuItem^>^  select = gcnew array<ToolStripMenuItem^>(3);
				 ToolStripMenuItem^ title = gcnew ToolStripMenuItem();
				 title->Text = "GM";
				 for (int ^i = 0; *i < 3; *i += 1) {
					 select[*i] = gcnew ToolStripMenuItem();
					 if (*i == 0) {
						 select[*i]->Text = "�����l";
						 select[*i] ->Click += gcnew System::EventHandler(this, &MyForm::controlrolldice_Click);
					 }
					 else if (*i == 1) {
						 select[*i]->Text = "�������";
						 select[*i]->Click += gcnew System::EventHandler(this, &MyForm::controlmoney_Click);
					 }
					 else if (*i == 2) {
						 select[*i]->Text = "����c";
						 select[*i]->Click += gcnew System::EventHandler(this, &MyForm::controljail_Click);
					 }
					 title->DropDownItems->Add(select[*i]);
				 }
				 gm->Items->Add(title);
				 this->Controls->Add(gm);
				 gm->BringToFront();
				
			 }
			 void initialload() {
				 StreamReader^ ld = gcnew StreamReader("��l�Ƥg�a.txt");
				 String^ line;
				 int ^i = 0;
				 while ((line = ld->ReadLine()) != nullptr)
				 {
					 initialland[*i] = line;
					 *i += 1;
				 }
				 ld->Close();
				 StreamReader^ ldp = gcnew StreamReader("��l�ƻ���.txt");
				 *i = 0;
				 int ^num = 0;
				 while ((line = ldp->ReadLine()) != nullptr)
				 {
					 num = Int32::Parse(line);
					 landprice[*i] = *num;
					 *i += 1;
				 }
				 ldp->Close();
			 }
			 void otherinitial() {
				 meglabel->AutoSize = false;
				 meglabel->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
				 meglabel->Location = System::Drawing::Point(400, 300);
				 meglabel->Size = System::Drawing::Size(600, 150);
				 this->Controls->Add(meglabel);
			 }
			 void namemoney(int ^num) {
				 int ^startx = 0,^starty=650;
				 for (int ^i = 0; *i < *playern; *i += 1) {
					 if (*num == 1) {
						 if(*i!=0)
							money[*i] = 20000;
						 jailn[*i] = 0;
					 }
					 labelname[*i] = gcnew Label();
					 labelname[*i]->AutoSize = false;
					 labelname[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular));
					 labelname[*i]->Location = System::Drawing::Point(*startx, *starty);
					 labelname[*i]->Size = System::Drawing::Size(200, 20);
					 labelname[*i]->Text = L"����W: ";
					 if(*i==0)
						 labelname[*i]->Text+=name;
					 else if(*i==1)
						 labelname[*i]->Text += L"�G�����a(���j�P)";
					 else if (*i == 2)
						 labelname[*i]->Text += L"�T�����a(������)";
					 else if (*i == 3)
						 labelname[*i]->Text += L"�|�����a(�ɦ���)";
					 this->Controls->Add(labelname[*i]);
					 labelmoney[*i] = gcnew Label();
					 labelmoney[*i]->AutoSize = false;
					 labelmoney[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 12, System::Drawing::FontStyle::Regular));
					 labelmoney[*i]->Location = System::Drawing::Point(*startx+200, *starty);
					 labelmoney[*i]->Size = System::Drawing::Size(150, 20);
					 labelmoney[*i]->Text = L"�{������: " + money[*i].ToString();
					 this->Controls->Add(labelmoney[*i]);
					 *starty += 20;
				 }
			 }
			 void map(int ^num) {
				 // 1200 600 
				 int ^startx = 1200;
				 int ^starty = 600;
				 for (int ^i = 0; *i < 40; *i += 1) {
					 if(*num==1)
						buy[*i] = -1;
					 labelland[*i] = gcnew Label();
					 labelland[*i]->AutoSize = false;
					 labelland[*i]->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
					 if (*num == 1)
						 labelland[*i]->BackColor = System::Drawing::SystemColors::Window;
					 else {
						 if (buy[*i] == -1)
							 labelland[*i]->BackColor = System::Drawing::SystemColors::Window;
						 else if (buy[*i] == 0)
							 labelland[*i]->BackColor = System::Drawing::Color::Yellow;
						 else if (buy[*i] == 1)
							 labelland[*i]->BackColor = System::Drawing::Color::Pink;
						 else if (buy[*i] == 2)
							 labelland[*i]->BackColor = System::Drawing::Color::Green;
						 else if (buy[*i] == 3)
							 labelland[*i]->BackColor = System::Drawing::Color::Red;
					 } 
					 labelland[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
					 labelland[*i]->Location = System::Drawing::Point(*startx, *starty);
					 //land[0]->Name = L"label2";
					 labelland[*i]->Size = System::Drawing::Size(110, 50);
					 if (landprice[*i] != -1)
						 labelland[*i]->Text = initialland[*i] + L"\r\n" + landprice[*i].ToString();
					 else
						 labelland[*i]->Text = initialland[*i] + L"\r\n";
					 this->Controls->Add(labelland[*i]);
					 labelland[*i]->SendToBack();
					 if (*i < 10) {
						 *startx -= 110;
					 }
					 else if (*i >= 10&&*i<20) {
						  *starty -=50;
					 }
					 else if (*i >= 20 && *i < 30) {
						 *startx += 110;
					 }
					 else {
						 *starty += 50;
					 }
				 }
				 for (int ^i = 0; *i < *playern; *i += 1) {
					 rolepic[*i] = gcnew PictureBox();
					 if (*i == 0)
						 rolepic[*i]->BackColor = System::Drawing::Color::Yellow;
					 else if (*i == 1)
						 rolepic[*i]->BackColor = System::Drawing::Color::Pink;
					 else if (*i == 2)
						 rolepic[*i]->BackColor = System::Drawing::Color::Green;
					 else if (*i == 3)
						 rolepic[*i]->BackColor = System::Drawing::Color::Red;
					 if(*i==0)
						 rolepic[*i]->BackgroundImage = System::Drawing::Image::FromFile(majorpic);
					 else
						rolepic[*i]->BackgroundImage = System::Drawing::Image::FromFile((*i+1).ToString()+L".png");
					 rolepic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 if(*num==1)
						rolepic[*i]->Location = System::Drawing::Point(labelland[0]->Location.X + 67, labelland[0]->Location.Y + 5);
					 else
						 rolepic[*i]->Location = System::Drawing::Point(labelland[position[*i]]->Location.X + 67, labelland[position[*i]]->Location.Y + 5);
					 rolepic[*i]->Size = System::Drawing::Size(40, 40);
					 this->Controls->Add(rolepic[*i]);
					 rolepic[*i]->BringToFront();
				}
				 rolepic[0]->BringToFront();
			 }
			 void maphouse() {
				 for (int^i = 0; *i < 40; *i += 1) {
					 housepic[*i] = gcnew PictureBox();
					 housepic[*i]->BackColor = System::Drawing::SystemColors::Window;
					 housepic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 
					 if (*i < 10) {
						 if (*i != 0) {
							 if(*i==9)
								housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X+50, labelland[*i]->Location.Y - 35);
							 else
								housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X+5, labelland[*i]->Location.Y - 35);
						 }
						 drawhouse(house[*i], *i);
					 }
					 else if (*i >= 10 && *i<20) {
						 if (*i != 10)
							 housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X+110, labelland[*i]->Location.Y+5);
						 drawhouse(house[*i], *i);
					 }
					 else if (*i >= 20 && *i < 30) {
						 if (*i != 20) {
							 if(*i==29)
								 housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X + 25, labelland[*i]->Location.Y + 50);
							 else
								housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X + 70, labelland[*i]->Location.Y + 50);
						 }
						 drawhouse(house[*i], *i);
					 }
					 else {
						 if (*i != 30)
							 housepic[*i]->Location = System::Drawing::Point(labelland[*i]->Location.X-35, labelland[*i]->Location.Y +10);
						 drawhouse(house[*i], *i);
					 }
					 housepic[*i]->Size = System::Drawing::Size(35, 35);
					 this->Controls->Add(housepic[*i]);
					 housepic[*i]->BringToFront();
				 }
			 }
			 void drawhouse(int ^housenum,int ^pos) {
				 if (*housenum == 0) {
					 housepic[*pos]->BackColor = System::Drawing::SystemColors::Control;
					 housepic[*pos]->BackgroundImage = nullptr;
				}
				else if (*housenum == 1) 
					 housepic[*pos]->BackgroundImage = System::Drawing::Image::FromFile("1house.png");
				 else if (*housenum == 2)
					 housepic[*pos]->BackgroundImage = System::Drawing::Image::FromFile("2house.png");
				 else if (*housenum == 3) 
					 housepic[*pos]->BackgroundImage = System::Drawing::Image::FromFile("3house.png");
				 else if (*housenum == 4) 
					 housepic[*pos]->BackgroundImage = System::Drawing::Image::FromFile("4house.png");
				 else if (*housenum == 5) 
					 housepic[*pos]->BackgroundImage = System::Drawing::Image::FromFile("5house.png");
			 }
			 void createbutton() {
				 int ^startx = 450, ^starty = 700;
				 for (int ^i = 0; *i < 4; *i += 1) {
					 op[*i] = gcnew Button();
					 op[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
					 op[*i]->Location = System::Drawing::Point(*startx, *starty);
					 op[*i]->Size = System::Drawing::Size(90, 40);
					 op[*i]->UseVisualStyleBackColor = true;
					 if (*i == 0) {
						 op[*i]->Click += gcnew System::EventHandler(this, &MyForm::rolldice_Click);
						 op[*i]->Text = L"�Y��l";
					 }
					 else if (*i == 1) {
						 op[*i]->Text = L"�s��";
						 op[*i]->Click += gcnew System::EventHandler(this, &MyForm::save_Click);
					 }
					 else if (*i == 2) {
						 op[*i]->Text = L"���v����";
						 op[*i]->Click += gcnew System::EventHandler(this, &MyForm::show_Click);
					 }
					 else if (*i == 3) {
						 op[*i]->Text = L"���}";
						 op[*i]->Click += gcnew System::EventHandler(this, &MyForm::close_Click);
					 }
					 *startx += 150;
					 this->Controls->Add(op[*i]);
				 }
				 labelbutton[0]= gcnew Label();
				 labelbutton[0]->AutoSize = false;
				 labelbutton[0]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
				 labelbutton[0]->Location = System::Drawing::Point(450, 680);
				 labelbutton[0]->Size = System::Drawing::Size(80, 20);
				 labelbutton[0]->Text = L"�I��:";
				 this->Controls->Add(labelbutton[0]);
			 }
			 void rolldice() {
				 *dice = 0;
				 Random ^generator = gcnew Random;
				 *dice = generator->Next(2, 13);
				 if (*controldice != -1) {
					 *dice = *controldice;
					 *controldice = -1;
				 }
				 //*dice = 30;
				 //Console::WriteLine(L"��l�Ʀr��:{0}", *dice);
			 }
			 void locate(int ^num) {
				 //�H�U�O��ܷs��m	
				 if (*num == 0)
					 position[*turn] += *dice;
				 if (position[*turn]> 39) {
					 position[*turn] -= 40;
					 if (position[*turn] != 0)
						 money[*turn] += 2000;
				 }
				 rolepic[*turn]->Location = System::Drawing::Point(labelland[position[*turn]]->Location.X + 67, labelland[position[*turn]]->Location.Y + 5);
			 }
			 int^ landevent() {
				 String^ choose;
				 int ^mustsell = 0;
				 int ^paidok = 0;
				 int ^eventn = 0;
				 if (position[*turn] != 2 && position[*turn] != 5 && position[*turn] != 12 && position[*turn] != 15 && position[*turn] != 25 && position[*turn] != 28 && position[*turn] != 35 && position[*turn] != 38)
				 {
					 if (landprice[position[*turn]] != -1 && position[*turn] != 0) {
						 if (buy[position[*turn]] == -1) {
							 while (true)
							 {
								 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]] + L"�O�_�n�R�U���g�a", L"�T��", MessageBoxButtons::YesNo);//, MessageBoxIcon::Question);
								 storeevent(name + L"��F" + initialland[position[*turn]]);
								 if (*result == System::Windows::Forms::DialogResult::Yes) {
									 if (money[*turn] < landprice[position[*turn]]) {
										 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��������", L"�T��");
									 }
									 else {
										 money[*turn] -= landprice[position[*turn]];
										 buy[position[*turn]] = *turn;
										 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"�ʶR���\", L"�T��");//, MessageBoxIcon::Question);
										 labelland[position[*turn]]->BackColor = System::Drawing::Color::Yellow;
										 storeevent(L"�ʶR���\");
									 }
									 break;
								 }
								 else if (*result == System::Windows::Forms::DialogResult::No) {
									 storeevent(L"���ʶR");
									 break;
								 }

							 }
						 }
						 else if (buy[position[*turn]] == *turn)
							 build();
						 else {
							 eventn = otherland();
							 return eventn;
						 }
					 }
					 else {
						 if (initialland[position[*turn]]->Contains("���c")) {
							 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]]+ L"�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����", L"�T��");
							 storeevent(name + L"��F���c");
							 eventn = gotojail();
							 return eventn;
						 }
						 else if (initialland[position[*turn]]->Contains("���|")) {
							 int ^chfa = 1;
							 card(chfa);
							 storeevent(name + L"��F���|");
						 }
						 else if (initialland[position[*turn]]->Contains("�R�B")) {
							 int ^chfa = 0;
							 card(chfa);
							 storeevent(name + L"��F�R�B");
						 }
						 else {
						//	 Console::WriteLine("��F{0}", initialland[position[*turn]]);
							 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]], L"�T��");//, MessageBoxIcon::Question);
							 storeevent(name + L"��F" + initialland[position[*turn]]);
						 }

					 }
				 }
				 else {
					 Console::WriteLine("��F{0}�A��ú��{1}��", initialland[position[*turn]], landprice[position[*turn]]);
					 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]]+L"��ú��"+ landprice[position[*turn]].ToString()+L"��", L"�T��");//, MessageBoxIcon::Question);
					 storeevent(name + L"��F" + initialland[position[*turn]]);
					 //checkenter();
					 if (money[*turn] < landprice[position[*turn]]) {
						 MessageBox::Show(L"��������", L"�T��");
						 *eventn = 1;
						 return eventn;
					 }
					 else {
						 money[*turn] -= landprice[position[*turn]];
						 storeevent(L"�wú��" + landprice[position[*turn]].ToString() + L"��");
					 }

				 }
				 return eventn;
			 }
			 
			 void storeevent(String ^line) {
				 if (*turn != 0) {
					 if (*lasturn != *turn) {
						 *lasturn = *turn;
						 otherplayerec[*turn-1] = line;
					 }
					 else
						 otherplayerec[*turn-1] += line;
				 }
				 StreamWriter^ sw = gcnew StreamWriter("����.txt", 1);
				 sw->WriteLine(line);
				 sw->Write(" ");
				 sw->Close();
			 }
			 int^ gotojail() {
				 int ^eventn = 2;//0:n,1:over,2:jail
				// Console::WriteLine(L"���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����");
				 storeevent(L"���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����");
				 position[*turn] = 10;
				 rolepic[*turn]->Location = System::Drawing::Point(labelland[position[*turn]]->Location.X + 67, labelland[position[*turn]]->Location.Y + 5);
				 return eventn;
			 }
			 void card(int ^chfa) {
				 int ^num = 0;
				 array<int>^cardcash = { 2000,1500,1000,2000,500,3000,1000,4000 };
				 Random ^generator = gcnew Random;
				 *num = generator->Next(0, 7);
				 if (*chfa == 1) {
					 array<String^>^cword = { L"�B�ʸ����a�x",L"�Ȧ�I�A�Q��",L"�g��p���ͷN",L"���ͷN���\",L"�����B��",L"���U�ѤH",L"��{�}�n����",L"���ֳz" };
				//	 Console::WriteLine("���{0}�A�o��{1}��", cword[*num], cardcash[*num]);
					 if(*turn==0)
						 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]] + L"���"+ cword[*num] + L"�o��"+ cardcash[*num].ToString()+L"��", L"�T��");
				 }
				 else {
					 array<String^>^cword = { L"����������",L"������ɱo�a�x",L"�u�@�V�O",L"�O�I�z��",L"�o��j�Ǽ��Ǫ�",L"�Ѳ�����",L"�a���ϧU��",L"�q�v���ɱo�a�x" };
					 if(*turn==0)
						System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]] + L"���" + cword[*num] + L"�o��" + cardcash[*num].ToString() + L"��", L"�T��");
				 }
				 money[*turn] += cardcash[*num];
			 }
			 int^ checkasset(int ^price) {
				 int ^i = 0;
				 int ^asset = 0;
				 int ^eventn = 0;
				 for (*i = 0; *i <= 39; *i += 1) {
					 if (buy[*i] == *turn) {
						 if (house[*i] > 0) {
							 if (landprice[*i] >= 3000)
								 *asset += 1000 * house[*i];
							 else
								 *asset += 500 * house[*i];
						 }
						 *asset += landprice[*i] / 2;
					 }
				 }
				 *asset += money[*turn];
				 if (*asset < *price) {
					// Console::WriteLine(L"�ثe�]���`�B�p���ú����B�A�}��  �C������");
					 storeevent(L"�ثe�]���`�B�p���ú����B�A�}��  �C������");
					 *eventn = 1;
					 return eventn;
				 }
				 return eventn;
			 }
			 void build() {
			//	 String ^choose;
				 int ^houseprice = 0;
				 int ^mustsell = 0;
				 int ^paidok = 0;
				 if (house[position[*turn]] <= 4) {
					 while (true)
					 {
						 Console::Write(L"�Ыλ���: ");
						 if (landprice[position[*turn]] < 3000)
							 *houseprice = 1000;
						 else
							 *houseprice = 2000;
						 Console::WriteLine(*houseprice);
						 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��F" + initialland[position[*turn]] + L"�O�_�n�\�Фl", L"�T��", MessageBoxButtons::YesNo);//, MessageBoxIcon::Question);
						// Console::WriteLine(L"��F {0} �O�_�n�\�Фl�A��J(y)���ܭn�A��J(n)���ܤ��n", initialland[position[*turn]]);
						 storeevent(name + L"��F" + initialland[position[*turn]]);
						
						 if (*result == System::Windows::Forms::DialogResult::Yes) {
							 if (money[*turn] < *houseprice) {
								 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��������", L"�T��");
								 *paidok = 0;
							 }
							 else {
								 money[*turn] -= *houseprice;
								 house[position[*turn]] += 1;
								/* if (house[position[*turn]] < 4) {
									 land[position[*turn]] = initialland[position[*turn]] + house[position[*turn]].ToString();
								 }
								 else if (house[position[*turn]] == 5) {
									 land[position[*turn]] = initialland[position[*turn]] + L"^";
								 }*/
								 drawhouse(house[position[*turn]], position[*turn]);
								 System::Windows::Forms::DialogResult^ result1 = MessageBox::Show(L"�\�Ц��\", L"�T��");
								 storeevent(L"�\�Ц��\");
								 
							 }
							 break;
						 }
						 else if (*result == System::Windows::Forms::DialogResult::No)
							 break;
					 }
				 }
				 else {
					 System::Windows::Forms::DialogResult^ result1 = MessageBox::Show(L"�w�g�L�k�A�\�Фl", L"�T��");
					 storeevent(L"�w�g�L�k�A�\�Фl");
				 }
			 }
			 int^ otherland() {
				 int ^owner = buy[position[*turn]];
				 int ^passmoney = 0;
				 int ^mustsell = 1;
				 int ^eventn = 0;
				 int ^paidok = 0;
				// Console::Write(L"��F{0}�A���g�a��{1}�����a�Ҧ��A�ݤ�I�L���O: ", initialland[position[*turn]], *owner + 1);
				 storeevent(name + L"��F" + initialland[position[*turn]] + L"�ݤ�I�L���O��" + (*owner + 1).ToString() + L"�����a");
				 if (house[position[*turn]] > 0) {
					 if (house[position[*turn]] == 1)
						 *passmoney = landprice[position[*turn]] / 2;
					 else if (house[position[*turn]] == 2)
						 *passmoney = landprice[position[*turn]];
					 else if (house[position[*turn]] == 3)
						 *passmoney = landprice[position[*turn]] / 2 * 3;
					 else if (house[position[*turn]] == 4)
						 *passmoney = landprice[position[*turn]] * 3;
					 else if (house[position[*turn]] == 5)
						 *passmoney = landprice[position[*turn]] * 5;
				 }
				 else
					 *passmoney = landprice[position[*turn]] / 10;
		//		 Console::WriteLine("{0}��", *passmoney);
				 System::Windows::Forms::DialogResult^ result1 = MessageBox::Show(L"��F" + initialland[position[*turn]] + L"���g�a��" + (*owner + 1).ToString() + L"�����a�Ҧ��A�ݤ�I�L���O"+ passmoney->ToString()+L"��", L"�T��");
				 if (money[*turn] >= *passmoney) {
					 money[*turn] -= *passmoney;
					 money[*owner] += *passmoney;
				//	 Console::WriteLine("�w��I");
					 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��I���\", L"�T��");
					 storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
				 }
				 else {
					 //��������
					 System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"��������", L"�T��");
					 *eventn = 1;
					 return eventn;
				 }
				 return eventn;
			 }
			 void otherplayer() {
				 //���n���a
				 int ^eventn = 0;
				 int ^num = 0;
				 while (*turn < *playern) {
					 *lasturn = 0;
					 if (jailn[*turn] > 0) {
						 jailn[*turn] -= 1;
						 storeevent((*turn + 1).ToString() + L"���a���c��");
						 *turn += 1;
						 continue;
					 }
					 rolldice();
					 locate(num);
					 eventn=otherlandevent();
					 refreshlabelmoney();
					 if (*eventn == 3) 
						 break;
					 if (*eventn == 2)
						 jailn[*turn] = 3;
					 *turn += 1;
				}
				 if (otherplayerec[0] != "") {
					 meglabel->Text = otherplayerec[0] + L"\n" + otherplayerec[1] + L"\n" + otherplayerec[2] + L"\n";
				 }
				 if (*eventn == 3) {
					 System::Windows::Forms::DialogResult^ result1 = MessageBox::Show((*turn+1).ToString()+L"�����a�}���C������", L"�T��");
				 }
				 else {
					 *turn = 0;
					 for (int ^i = 0; *i<4; *i += 1)
						 op[*i]->Enabled = true;
				 }
			 }
			 void landcolor(int ^turn) {
				 if(*turn==1)
					labelland[position[*turn]]->BackColor = System::Drawing::Color::Pink;
				 else if (*turn == 2)
					 labelland[position[*turn]]->BackColor = System::Drawing::Color::Green;
				 else if (*turn == 3)
					 labelland[position[*turn]]->BackColor = System::Drawing::Color::Red;
			 }
			 int^ otherlandevent() {
				 String^ choose;
				 int ^mustsell = 0;
				 int ^paidok = 0;
				 int ^eventn = 0;
				 if (position[*turn] != 2 && position[*turn] != 5 && position[*turn] != 12 && position[*turn] != 15 && position[*turn] != 25 && position[*turn] != 28 && position[*turn] != 35 && position[*turn] != 38)
				 {
					 if (landprice[position[*turn]] != -1 && position[*turn] != 0) {
						 if (buy[position[*turn]] == -1) {
							 while (true)
							 {
								 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]]);
								 if (money[*turn] >= landprice[position[*turn]]) {
									 money[*turn] -= landprice[position[*turn]];
									 buy[position[*turn]] = *turn;
									 landcolor(turn);
									 storeevent(L"�ʶR���\");
								 }
								 else {
									 storeevent(L"���ʶR");
								 }
								 break;
							 }
						 }
						 else if (buy[position[*turn]] == *turn) {
							 int ^houseprice = 0;
							 if (house[position[*turn]] <= 4) {
								 if (landprice[position[*turn]] < 3000)
									 *houseprice = 1000;
								 else
									 *houseprice = 2000;
								 if (money[*turn] >= *houseprice) {
									 money[*turn] -= *houseprice;
									 house[position[*turn]] += 1;
									 drawhouse(house[position[*turn]], position[*turn]);
									 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�\�Ц��\");
								 }
								 else {
									
									 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"���\��");
								 }
							 }
							 else {
								 
								 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�w�L�k�A�\�Фl�F");
							 }
						 }
						 else {
							 eventn = anotherland();
							 return eventn;
						 }

					 }
					 else {
						 if (initialland[position[*turn]]->Contains("���c")) {
							 Console::WriteLine("��F{0}", initialland[position[*turn]]);
							 storeevent((*turn + 1).ToString() + L"�����a��F���c");
							 eventn = gotojail();
							 return eventn;
						 }
						 else if (initialland[position[*turn]]->Contains("���|")) {
							 int ^chfa = 1;
							 card(chfa);
							 storeevent((*turn + 1).ToString() + L"�����a��F���|");
						 }
						 else if (initialland[position[*turn]]->Contains("�R�B")) {
							 int ^chfa = 0;
							 card(chfa);
							 storeevent((*turn + 1).ToString() + L"�����a��F�R�B");
						 }
						 else {
							 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]]);
						 }

					 }
				 }
				 else {
					 Console::WriteLine("��F{0}�A��ú��{1}��", initialland[position[*turn]], landprice[position[*turn]]);
					 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]]);
					 if (money[*turn] < landprice[position[*turn]]) {
						 eventn = checkasset(landprice[position[*turn]]);
						 if (*eventn == 1)
							 return *eventn = 3;
						 othersell(landprice[position[*turn]]);
						 storeevent(L"�wú��" + landprice[position[*turn]].ToString() + L"��");
					 }
					 else {
						 money[*turn] -= landprice[position[*turn]];
						 storeevent(L"�wú��" + landprice[position[*turn]].ToString() + L"��");
					 }

				 }
				 return eventn;
			 }
			 int^ anotherland() {
				 int ^owner = buy[position[*turn]];
				 int ^passmoney = 0;
				 int ^mustsell = 1;
				 int ^eventn = 0;
				 int ^paidok = 0;
				 if (*owner == 0)
					 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�ݤ�I�L���O���Ĥ@�쪱�a");
				 else
					 storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�ݤ�I�L���O��" + (*owner + 1).ToString() + L"�����a");
				 if (house[position[*turn]] > 0) {
					 if (house[position[*turn]] == 1)
						 *passmoney = landprice[position[*turn]] / 2;
					 else if (house[position[*turn]] == 2)
						 *passmoney = landprice[position[*turn]];
					 else if (house[position[*turn]] == 3)
						 *passmoney = landprice[position[*turn]] / 2 * 3;
					 else if (house[position[*turn]] == 4)
						 *passmoney = landprice[position[*turn]] * 3;
					 else if (house[position[*turn]] == 5)
						 *passmoney = landprice[position[*turn]] * 5;
				 }
				 else
					 *passmoney = landprice[position[*turn]] / 10;
				 if (money[*turn] >= *passmoney) {
					 money[*turn] -= *passmoney;
					 money[*owner] += *passmoney;
					// Console::WriteLine("�w��I");
					 storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
				 }
				 else {
					 eventn = checkasset(passmoney);
					 if (*eventn == 1)
						 return eventn = 3;
					 othersell(passmoney);
					 money[*owner] += *passmoney;
					 storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
				 }
				 return eventn;
			 }
			 void othersell(int ^price) {
				 int ^i = 0;
				 int ^ok = 0;
				 for (*i = 0; *i <= 39; *i += 1) {
					 if (buy[*i] == *turn&&landprice[*i] >= 3000 && house[*i]>0) {
						 while (house[*i] > 0) {
							 house[*i] -= 1;
							 money[*turn] += 1000;
							 if (money[*turn] > *price) {
								 *ok = 1;
								 break;
							 }
						 }
						drawhouse(house[*i],*i);
					 }
					 if (*ok == 1)
						 break;
				 }
				 if (*ok == 0) {
					 for (*i = 0; *i <= 39; *i += 1) {
						 if (buy[*i] == *turn && house[*i]>0) {
							 while (house[*i] > 0) {
								 house[*i] -= 1;
								 money[*turn] += 500;
								 if (money[*turn] > *price) {
									 *ok = 1;
									 break;
								 }
							 }
							drawhouse(house[*i], *i);
						 }
						 if (*ok == 1)
							 break;
					 }
				 }
				 if (*ok == 0) {
					 for (*i = 0; *i <= 39; *i += 1) {
						 if (buy[*i] == *turn&&landprice[*i] >= 3000) {
							 buy[*i] = -1;
							 labelland[*i]->BackColor=System::Drawing::SystemColors::Window;
							 money[*turn] += landprice[*i] / 2;
							 if (money[*turn] > *price) {
								 *ok = 1;
								 break;
							 }
						 }
					 }
				 }
				 if (*ok == 0) {
					 for (*i = 0; *i <= 39; *i += 1) {
						 if (buy[*i] == *turn) {
							 buy[*i] = -1;
							 labelland[*i]->BackColor = System::Drawing::SystemColors::Window;
							 money[*turn] += landprice[*i] / 2;
							 if (money[*turn] > *price) {
								 *ok = 1;
								 break;
							 }
						 }
					 }
				 }
				// Console::WriteLine(L"�I�M");
				 money[*turn] -= *price;
			 }
			 void refreshlabelmoney() {
				 for (int ^i = 0; *i < *playern; *i += 1) {
					 labelmoney[*i]->Text = L"�{������: " + money[*i].ToString();
				 }
			 }
	};
}
