// ConsoleApplication1.cpp: �D�n�M���ɡC
/********
4105056019 �\���� �Ĥ����@�~12/19
*********/
#include "stdafx.h"
#include "MyForm.h"
using namespace System;
using namespace ConsoleApplication1;
[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
   // Console::WriteLine(L"Hello World");
	Application::Run(gcnew MyForm());
    return 0;
}
