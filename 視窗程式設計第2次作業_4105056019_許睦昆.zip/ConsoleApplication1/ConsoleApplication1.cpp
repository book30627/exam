// ConsoleApplication1.cpp: �D�n�M���ɡC
/***************************
4105056019 �\���� �ĤG���@�~10/24
 ***/
#include "stdafx.h"

using namespace System;
using namespace System::IO;
using namespace System::Text;
void initialload(array<int>^, array<String^>^);
int^ load(int ^, array<String^>^, array<int>^, array<int>^, array<int>^, array<int>^, array<String^>^);
void store(array<int>^, array<int>^, array<int>^, array<int>^, array<String^>^, int ^, String^);
void storeevent(String ^);
void showevent();
void map(array<int>^, array<String^>^,String^,array<int>^, array<String^>^, array<int>^,int^);
void topdown(int ^, int ^);
void topdownLR(int ^, int ^,int^, array<int>^, array<String^>^);
void leftright(int ^, int^, array<int>^, array<String^>^);
void printcountry(int ^, array<String^>^);
void printspace();
void printprice(int ^, array<int>^);
void location(int ^, int ^, int ^, int^,array<String^>^,array<String^>^, array<String^>^, array<int>^, array<int>^, array<int>^);
void rolldice(int^,int^);
void checkenter();
int^ otherlandevent(int ^, array<int>^, array<int>^, array<int>^, array<int>^, array<int>^, array<String^>^, array<String^>^);
void othersell(int ^, int ^, array<int>^, array<int>^, array<int>^, array<int>^, array<String^>^, array<String^>^);
int^ anotherland(int ^, array<int>^, array<int>^, array<int>^, array<int>^ , array<int>^, array<String^>^, array<String^>^);
int^ landevent(int ^,array<int>^, array<int>^, array<int>^, array<int>^, array<int>^ ,array<String^>^, array<String^>^,int^,String^);
int^ otherland(int ^, array<int>^, array<int>^, array<int>^ , array<int>^, array<int>^, array<String^>^,array<String^>^, int ^, String ^);
void card(int^, int ^, array<int>^, array<int>^, array<String^>^);
int^ sell(int ^, int ^, int ^, array<int>^, array<int>^, array<int>^ , array<int>^ , array<int>^ , array<String^>^ , array<String^>^,int^,String^);
void build(int ^, array<int>^, array<int>^, array<int>^, array<int>^, array<int>^ , array<String^>^, array<String^>^,int^,String ^);
int^ gotojail(int ^, array<int>^, array<String^>^, array<String^>^);
int^ checkasset(int ^,int ^, array<int>^, array<int>^, array<int>^, array<int>^, array<int>^);
void sellhouse(int ^, array<int>^, array<int>^, array<int>^ , array<int>^, array<int>^, array<String^>^, array<String^>^,int^,String^);
void sellland(int ^, array<int>^, array<int>^, array<int>^, array<int>^, array<int>^, array<String^>^, array<String^>^,int^,String^);
int^ checkeint();
String^ checkecharlength();
int main(array<System::String ^> ^args)
{
	Console::WriteLine(L"�j�I�ιC��");
	Console::WriteLine("�q����l���B��20000���A���a�i�ۦ�]�w��l���B�ΦW��");
	Console::WriteLine(L"�ϧθѻ�:");
	Console::WriteLine(L"���a :* �B�q��1(2�����a):+ �B�q��2(3�����a):- �B�q��3(4�����a):/ ");
	Console::WriteLine(L"�Фl:�b�g�a��H�Ʀr�Щ�1~4�Cex : ���ƿ�1�A�N�����ƿ����@�ɩФl�A���]�h�O ^ ex : ���ƿ�^");
	Console::WriteLine(L"�Y�h�H�b�P�@���g�a�W�ȷ|��ܤ@�H���аO�Aex: * �M + �P�ɦb���ƿ��A���ƿ�1*�A��*���}�A��ܹ��ƿ�1+");
	Console::WriteLine();
	array<String^>^ land = gcnew array<String^>(40);
	array<String^>^ initialland = gcnew array<String^>(40);
	array<String^>^ alt = gcnew array<String^>(2);
	array<int>^ landprice = gcnew array<int>(40);
	array<int>^ house = gcnew array<int>(40) ;
	array<int>^ money = gcnew array<int>(4) {20000,20000,20000,20000};
	array<int>^ position = gcnew array<int>(4);
	array<String^>^ role = {"*","+","-","/"};
	array<int>^ buy = gcnew array<int>(40);
	array<int>^ jailn = gcnew array<int>(4);
	for (int ^i = 0; *i < 40; *i+=1) {
		buy[*i]=-1;
	}	
	int ^num = 0;
	int ^dice = 0;
	int ^playern = 0;
	int ^playturn = 0;
	int ^eventn = 0;//0:�L�� 1:�ۤv��F 2:�i�ʺ� 3:�q����F
	int^ok = 0;
	String ^option;
	String^name ;
	String^tempmoney;
	int ^choose=-1;
	while (true) {
		Console::WriteLine(L"���J���e���C���Ы�0�A���s�}�l�Ы�1");
		choose = checkeint();
		if (*choose == 0) {
			initialload(landprice, initialland);
			ok=load(choose,land, position, money,buy, house, alt);
			if (*ok == 1) {
				name = alt[0];
				playern = Int32::Parse(alt[1]);
				break;
			}

		//		
		}
		else if (*choose == 1) {
			initialload(landprice,initialland);
			load(choose, land, position, money, buy, house,alt);
			Console::WriteLine(L"�п�J���a�W��");
			name = Console::ReadLine();
			do {
				Console::WriteLine(L"�п�J��l���B(�j��0)�A���঳�B�I�ơA��Ƴ̦h��9���)");
				tempmoney = Console::ReadLine();
				if (tempmoney->Length > 9)
					continue;
				else 
					money[0] = Int32::Parse(tempmoney);
			} while (money[0] <= 0);
			while (true)
			{
				Console::WriteLine(L"�п�J���a���ƶq2~4");
				playern = checkeint();
				if (*playern > 4 || *playern < 2)
					continue;
				else
					break;
			}
			break;
		}
		
	}
	location(num, playturn, dice, playern, role, land, initialland, house, position, money);
	map(landprice, land,name,money,initialland,buy,playern);
	while (true)
	{
		if (*playturn >= *playern)
			*playturn = 0;
		if (jailn[*playturn] > 0) {
			*num = 1;
			if (*playturn == 0) {
				Console::WriteLine(L"���Y��");
				checkenter();
				rolldice(dice,playturn);
			}
			else 
				rolldice(dice,playturn);
			jailn[*playturn] -= 1;
			if (jailn[*playturn] == 0&&*playturn==0)
				Console::WriteLine(L"�X��");
			else if(*playturn==0)
				Console::WriteLine(L"�٦�{0}�^�X",jailn[*playturn]);
			if(*playturn ==0)
			checkenter();
			map(landprice, land, name, money, initialland, buy,playern);
			*playturn += 1;
			continue;
		}
		if (*playturn == 0) {
			Console::WriteLine(L"�Y��l��J:y�A�s�ɿ�J:s�A���v����:h�A���}��J:q");
			option = checkecharlength();
			if (option == "y") {
				rolldice(dice, playturn);
				*num = 0;
				location(num, playturn, dice, playern, role, land, initialland, house, position, money);
				map(landprice, land, name, money, initialland, buy,playern);
				eventn = landevent(playturn, position, money, landprice, buy, house, initialland, land, playern, name);
				if (*eventn == 1)
					break;
				if (*eventn == 2)
					jailn[*playturn] = 3;
				*num = 1;
				location(num, playturn, dice, playern, role, land, initialland, house, position, money);
				map(landprice, land, name, money, initialland, buy,playern);
				*playturn += 1;
			}
			else if (option == "s") {
				store(position, money, buy, house, land, playern, name);
				Console::WriteLine("�s�ɦ��\");
			}	
			else if (option == "h")
				showevent();
			else if (option == "q")
				break;
		}
		else {
			rolldice(dice,playturn);
			*num = 0;
			location(num, playturn, dice, playern, role,  land, initialland, house, position, money);
			map(landprice, land, name, money, initialland,buy,playern);
			eventn = otherlandevent(playturn, position, money, landprice, buy, house, initialland, land);
			if (*eventn == 3)
				break;
			if (*eventn == 2)
				jailn[*playturn] = 3;
			*num = 1;
			location(num, playturn, dice, playern, role, land, initialland, house, position, money);
			map(landprice, land, name, money, initialland,buy,playern);
			*playturn += 1;
		}
		eventn = 0;
	}
	if(*eventn==1)
		Console::WriteLine(L"Game Over");
	else if (*eventn == 3) {
		*playturn += 1;
		Console::WriteLine(L"{0}�����a��F", *playturn);
		storeevent(playturn->ToString() + L"�����a��F");
	}
		
    return 0;
}
void store(array<int>^ position, array<int>^ money, array<int>^buy, array<int>^ house, array<String^>^ land, int ^playern, String^name) {
	int ^i = 0;
	StreamWriter^ pos = gcnew StreamWriter("position.txt");
	for (*i = 0; *i < *playern; *i += 1) {
		if (*i == *playern - 1)
			pos->Write(position[*i].ToString());
		else
		pos->WriteLine(position[*i].ToString());
	}
	pos->Close();
	StreamWriter^ mon = gcnew StreamWriter("money.txt");
	for (*i = 0; *i < *playern; *i += 1) {
		if (*i == *playern - 1)
			mon->Write(money[*i].ToString());
		else
			mon->WriteLine(money[*i].ToString());
	}
	mon->Close();
	StreamWriter^ by = gcnew StreamWriter("buy.txt");
	for (*i = 0; *i < 40; *i += 1) {
		if (*i ==39)
			by->Write(buy[*i].ToString());
		else
			by->WriteLine(buy[*i].ToString());
	}
	by->Close();
	StreamWriter^ hou = gcnew StreamWriter("house.txt");
	for (*i = 0; *i < 40; *i += 1) {
		if (*i == 39)
			hou->Write(house[*i].ToString());
		else
			hou->WriteLine(house[*i].ToString());
	}
	hou->Close();
	StreamWriter^ lan = gcnew StreamWriter("land.txt");
	for (*i = 0; *i < 40; *i += 1) {
		if (*i == 39)
			lan->Write(land[*i]);
		else
			lan->WriteLine(land[*i]);
	}
	lan->Close();
	StreamWriter^ infor = gcnew StreamWriter("infor.txt");
			infor->WriteLine(name);
			infor->Write(playern);
	infor->Close();
}
void storeevent(String ^line) {
	StreamWriter^ sw = gcnew StreamWriter("����.txt", 1);
	sw->WriteLine(line);
	sw->Write(" ");
	sw->Close();
}
void showevent() {
	StreamReader^ ld = gcnew StreamReader("����.txt");
	String^ line;
	while ((line = ld->ReadLine()) != nullptr)
	{
		Console::WriteLine(line);
	}
	ld->Close();
}
void initialload(array<int>^landprice, array<String^>^ initialland){
	StreamReader^ ld = gcnew StreamReader("��l�Ƥg�a.txt");
	String^ line;
	int ^i = 0;
	while ((line = ld->ReadLine()) != nullptr)
	{
		initialland[*i] = line;
		*i += 1;
	}
	ld->Close();
	StreamReader^ ldp = gcnew StreamReader("��l�ƻ���.txt");
	*i = 0;
	int ^num = 0;
	while ((line = ldp->ReadLine()) != nullptr)
	{
		//line2 = L"" + line;
		num = Int32::Parse(line);
		landprice[*i] = *num;
		//Console::WriteLine(landprice[*i]);
		*i += 1;
	}
	ldp->Close();
}
int^ load(int ^choose,array<String^>^ land,array<int>^ position, array<int>^ money,array<int>^buy, array<int>^ house, array<String^>^ alt) {
	int ^ok = 0;
	if (*choose == 0) {
		if (File::Exists("land.txt")) {
			StreamReader^ infor = gcnew StreamReader("infor.txt");
			String^ line;
			int ^i = 0;
			while ((line = infor->ReadLine()) != nullptr)
			{
				alt[*i] = line;
				*i += 1;
			}
			infor->Close();
			*i = 0;
			StreamReader^ hou = gcnew StreamReader("house.txt");
			while ((line = hou->ReadLine()) != nullptr)
			{
				house[*i] = Int32::Parse(line);
				*i += 1;
			}
			hou->Close();
			*i = 0;
			StreamReader^ by = gcnew StreamReader("buy.txt");
			while ((line = by->ReadLine()) != nullptr)
			{
				buy[*i] = Int32::Parse(line);
				*i += 1;
			}
			by->Close();
			*i = 0;
			StreamReader^ ld = gcnew StreamReader("land.txt");
			while ((line = ld->ReadLine()) != nullptr)
			{
				land[*i] = line;
				*i += 1;
			}
			ld->Close();
			*i = 0;
			StreamReader^ mon = gcnew StreamReader("money.txt");
			while ((line = mon->ReadLine()) != nullptr)
			{
				money[*i] = Int32::Parse(line);
				*i += 1;
			}
			mon->Close();
			*i = 0;
			StreamReader^ pos = gcnew StreamReader("position.txt");
			while ((line = pos->ReadLine()) != nullptr)
			{
				position[*i] = Int32::Parse(line);
				*i += 1;
			}
			pos->Close();
			*ok = 1;
		}
		else
		{
			Console::WriteLine(L"�d�L����");
			*ok = 0;
		}
	}
	else if (*choose == 1) {
		int^i = 0;
		String ^line;
		StreamReader^ ld = gcnew StreamReader("��l�Ƥg�a.txt");
		while ((line = ld->ReadLine()) != nullptr)
		{
			land[*i] = line;
			*i += 1;
		}
		ld->Close();
		File::Delete("buy.txt");
		File::Delete("house.txt");
		File::Delete("infor.txt");
		File::Delete("land.txt");
		File::Delete("money.txt");
		File::Delete("position.txt");
		*ok = 1;
	}
	return ok;
}
void checkenter() {
	Console::WriteLine(L"�п�Jenter���ܽT�{");
	Console::ReadLine();
}
int^ checkeint() {
	String ^ch;
	while (true)
	{
		ch = Console::ReadLine();
		if (ch->Length ==0||ch->Length > 1 || ch[0] > '9' || ch[0] < '0')
			Console::WriteLine(L"�п�J�Ʀr");
		else
			break;
	}
	return Int32::Parse(ch);
}
String^ checkecharlength() {
	String ^ch;
	while (true)
	{
		ch = Console::ReadLine();
		if (ch->Length == 0 || ch->Length > 1 )
			Console::WriteLine(L"�Э��s��J");
		else
			break;
	}
	return ch;
}
void rolldice(int ^dice,int ^turn) {
	*dice = 0;
	Random ^generator = gcnew Random;
	*dice=generator->Next(2,12);
	Console::WriteLine(L"��l�Ʀr��:{0}", *dice);
	if(*turn==0)
	checkenter();
}
void location(int ^num, int ^ turn, int ^dice,int ^playern , array<String^>^ role, array<String^>^ land, array<String^>^ initialland, array<int>^ house, array<int>^ position, array<int>^money ) {
	int ^same = -1;
	
	if (house[position[*turn]] > 0) {
		if (house[position[*turn]] <= 4) {
			String ^housenum = house[position[*turn]].ToString();
			land[position[*turn]] = initialland[position[*turn]]+housenum;
		}
		else if (house[position[*turn]] == 5)
			land[position[*turn]] = initialland[position[*turn]] + L"^";
		for (int ^i = 0; *i < *playern; *i += 1) {
			if (position[*turn] == position[*i] && *i != *turn) {
				*same = *i;
				break;
			}
		}
		if (*same != -1)
			land[position[*turn]] += role[*same];
	}
	else {
		for (int ^i = 0; *i < *playern; *i += 1) {
			if (position[*turn] == position[*i] && *i != *turn) {
				*same = *i;
				break;
			}
		}
		if (*same !=-1) {
			land[position[*turn]] = initialland[position[*turn]]+role[*same];
		}
		else
		land[position[*turn]] = initialland[position[*turn]];
	}
	//�H�U�O��ܷs��m	
	if (*num == 0)
		position[*turn] += *dice;
	if (position[*turn]> 39) {
		position[*turn] -= 40;
		if (position[*turn] != 0)
			money[*turn] += 2000;
	}
	*same = -1;
	if (role[*turn] == "*") {
		for (int ^i = 0; *i < *playern; *i += 1) {
			if (position[*turn] == position[*i] && *i != *turn) {
				*same = *i;
				land[position[*turn]] = land[position[*turn]]->Replace(role[*i], role[*turn]);
				break;
			}
		}
	}
	else {
		for (int ^i = 0; *i < *playern; *i += 1) {
			if (position[*turn] == position[*i] && *i != *turn) {
				*same = *i;
				break;
			}
		}
	}
	if (*same == -1) 
		land[position[*turn]] += role[*turn];
}
int^ otherlandevent(int ^ turn, array<int>^ position, array<int>^ money, array<int>^ landprice, array<int>^buy, array<int>^ house, array<String^>^ initialland, array<String^>^ land) {
	String^ choose;
	int ^mustsell = 0;
	int ^paidok = 0;
	int ^eventn = 0;
	if (position[*turn] != 2 && position[*turn] != 5 && position[*turn] != 12 && position[*turn] != 15 && position[*turn] != 25 && position[*turn] != 28 && position[*turn] != 35 && position[*turn] != 38)
	{
		if (landprice[position[*turn]] != -1 && position[*turn] != 0) {
			if (buy[position[*turn]] == -1) {
				while (true)
				{
					Console::WriteLine(L"��F{0}", initialland[position[*turn]]);
					storeevent((*turn+1).ToString()+L"�����a��F" + initialland[position[*turn]]);
					if (money[*turn] >= landprice[position[*turn]]) {
						money[*turn] -= landprice[position[*turn]];
						buy[position[*turn]] = *turn;
						Console::WriteLine(L"�ʶR���\");
						storeevent(L"�ʶR���\");
					}
					else {
						Console::WriteLine(L"���ʶR");
						storeevent(L"���ʶR");
					}
					break;
				}
			}
			else if (buy[position[*turn]] == *turn) {
				int ^houseprice = 0;
				if (house[position[*turn]] <= 4) {
					if (landprice[position[*turn]] < 3000)
						*houseprice = 1000;
					else
						*houseprice = 2000;
					if (money[*turn] >= *houseprice) {
						money[*turn] -= *houseprice;
						house[position[*turn]] += 1;
						if (house[position[*turn]] < 4) {
							land[position[*turn]] = initialland[position[*turn]] + house[position[*turn]].ToString();
						}
						else if (house[position[*turn]] == 5) {
							land[position[*turn]] = initialland[position[*turn]] + L"^";
						}
						Console::WriteLine(L"�\�Ц��\");
						storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]]+L"�\�Ц��\");
					}
					else {
						Console::WriteLine(L"���\��");
						storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"���\��");
					}
				}
				else {
					Console::WriteLine(L"�w�g�L�k�A�\�Фl");
					storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�w�L�k�A�\�Фl�F");
				}
			}
			else {
				eventn=anotherland(turn,money,buy,position,landprice,house,initialland,land);
				return eventn;
			}
				
		}
		else {
			if (initialland[position[*turn]]->Contains("���c")) {
				Console::WriteLine("��F{0}", initialland[position[*turn]]);
				storeevent((*turn + 1).ToString() + L"�����a��F���c");
				eventn = gotojail(turn, position, initialland, land);
				return eventn;
			}
			else if (initialland[position[*turn]]->Contains("���|")) {
				int ^chfa = 1;
				card(chfa, turn, money, position, initialland);
				storeevent((*turn + 1).ToString() + L"�����a��F���|");
			}
			else if (initialland[position[*turn]]->Contains("�R�B")) {
				int ^chfa = 0;
				card(chfa, turn, money, position, initialland);
				storeevent((*turn + 1).ToString() + L"�����a��F�R�B");
			}
			else {
				Console::WriteLine("��F{0}", initialland[position[*turn]]);
				storeevent((*turn + 1).ToString() + L"�����a��F"+ initialland[position[*turn]]);
			}

		}
	}
	else {
		Console::WriteLine("��F{0}�A��ú��{1}��", initialland[position[*turn]], landprice[position[*turn]]);
		storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]]);
		if (money[*turn] < landprice[position[*turn]]) {
			eventn = checkasset(landprice[position[*turn]],turn, position, money, landprice, buy, house);
			if (*eventn == 1)
				return *eventn=3;
			othersell(landprice[position[*turn]], turn, money, buy, landprice, house,initialland,land);
			storeevent(L"�wú��" + landprice[position[*turn]].ToString()+L"��");
		}
		else {
			money[*turn] -= landprice[position[*turn]];
			storeevent(L"�wú��" + landprice[position[*turn]].ToString() + L"��");
		}
			
	}
	return eventn;
}
void othersell(int ^price, int ^turn, array<int>^money, array<int>^buy, array<int>^ landprice, array<int>^ house, array<String^>^ initialland, array<String^>^ land) {
	int ^i = 0;
	int ^ok = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		if (buy[*i] == *turn&&landprice[*i]>=3000&&house[*i]>0) {
			while (house[*i] > 0) {
				house[*i] -= 1;
				money[*turn] += 1000;
				if (money[*turn] > *price) {
					*ok = 1;
						break;
				}
			}
			if (house[*i] > 0)
				land[*i] = initialland[*i] + house[*i].ToString();
			else
				land[*i] = initialland[*i];
		}
		if (*ok == 1)
			break;
	}
	if (*ok == 0) {
		for (*i = 0; *i <= 39; *i += 1) {
			if (buy[*i] == *turn && house[*i]>0) {
				while (house[*i] > 0) {
					house[*i] -= 1;
					money[*turn] += 500;
					if (money[*turn] > *price) {
						*ok = 1;
						break;
					}
				}
				if (house[*i] > 0)
					land[*i] = initialland[*i] + house[*i].ToString();
				else
					land[*i] = initialland[*i];
			}
			if (*ok == 1)
				break;
		}
	}
	if (*ok == 0) {
		for (*i = 0; *i <= 39; *i += 1) {
			if (buy[*i] == *turn&&landprice[*i] >= 3000) {
					buy[*i] = -1;
					money[*turn] +=landprice[*i]/2;
					if (money[*turn] > *price) {
						*ok = 1;
						break;
					}
			}
		}
	}
	if (*ok == 0) {
		for (*i = 0; *i <= 39; *i += 1) {
			if (buy[*i] == *turn) {
				buy[*i] = -1;
				money[*turn] += landprice[*i] / 2;
				if (money[*turn] > *price) {
					*ok = 1;
					break;
				}
			}
		}
	}
	Console::WriteLine(L"�I�M");
	money[*turn] -= *price;
}
int^ anotherland(int ^turn, array<int>^money, array<int>^buy, array<int>^ position, array<int>^ landprice, array<int>^ house, array<String^>^ initialland, array<String^>^ land) {
	int ^owner = buy[position[*turn]];
	int ^passmoney = 0;
	int ^mustsell = 1;
	int ^eventn = 0;
	int ^paidok = 0;
	if(*owner==0)
		storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�ݤ�I�L���O���Ĥ@�쪱�a");
	else
		storeevent((*turn + 1).ToString() + L"�����a��F" + initialland[position[*turn]] + L"�ݤ�I�L���O��" + (*owner + 1).ToString() + L"�����a");
	if (house[position[*turn]] > 0) {
		if (house[position[*turn]] == 1)
			*passmoney = landprice[position[*turn]] / 2;
		else if (house[position[*turn]] == 2)
			*passmoney = landprice[position[*turn]];
		else if (house[position[*turn]] == 3)
			*passmoney = landprice[position[*turn]] / 2 * 3;
		else if (house[position[*turn]] == 4)
			*passmoney = landprice[position[*turn]] * 3;
		else if (house[position[*turn]] == 5)
			*passmoney = landprice[position[*turn]] * 5;
	}
	else
		*passmoney = landprice[position[*turn]] / 10;
	if (money[*turn] >= *passmoney) {
		money[*turn] -= *passmoney;
		money[*owner] += *passmoney;
		Console::WriteLine("�w��I");
		storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
	}
	else {
		eventn = checkasset(passmoney, turn, position, money, landprice, buy, house);
		if (*eventn == 1)
			return eventn=3;
		othersell(passmoney, turn, money, buy, landprice, house,initialland,land);
		money[*owner] += *passmoney;
		storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
	}
	return eventn;
}
int^ landevent(int ^ turn,array<int>^ position, array<int>^ money,array<int>^ landprice, array<int>^buy, array<int>^ house,array<String^>^ initialland, array<String^>^ land, int ^playern,String^name) {
	String^ choose;
	int ^mustsell = 0;
	int ^paidok = 0;
	int ^eventn = 0;
	if (position[*turn] != 2 && position[*turn] != 5 && position[*turn] != 12 && position[*turn] != 15 && position[*turn] != 25 && position[*turn] != 28 && position[*turn] != 35 && position[*turn] != 38)
	{
		if (landprice[position[*turn]] != -1 && position[*turn] != 0) {
			if (buy[position[*turn]] == -1) {
				while (true)
				{
					Console::WriteLine("��F{0}�O�_�n�R�U���g�a�A��J(y)���ܭn�A��J(n)���ܤ��n", initialland[position[*turn]]);
					storeevent(name+L"��F"+ initialland[position[*turn]]);
					choose = checkecharlength();
					if (choose == "y") {
						if (money[*turn] < landprice[position[*turn]]) {
							Console::WriteLine(L"�ѩ���������ݶi����");
							paidok = sell(landprice[position[*turn]], mustsell, turn, money, buy, position, landprice, house, initialland, land, playern, name);
							if (*paidok == 1) {
								buy[position[*turn]] = *turn;
								Console::WriteLine(L"�ʶR���\");
								storeevent(L"�ʶR���\");
								checkenter();
							}
							*paidok = 0;
						}
						else {
							money[*turn] -= landprice[position[*turn]];
							buy[position[*turn]] = *turn;
							Console::WriteLine(L"�ʶR���\");
							storeevent(L"�ʶR���\");
							checkenter();
						}
						break;
					}
					else if (choose == "n") {
						storeevent(L"���ʶR");
						break;
					}
						
				}
			}
			else if (buy[position[*turn]] == *turn)
				build(turn, position, money, landprice, buy, house, initialland, land, playern, name);
			else {
				eventn = otherland(turn, money, buy, position, landprice, house, initialland, land, playern, name);
				return eventn;
			}
		}
		else {
			if (initialland[position[*turn]]->Contains ("���c")) {
				Console::WriteLine("��F{0}", initialland[position[*turn]]);
				storeevent(name+L"��F���c");
				eventn=gotojail(turn, position, initialland,land);
				return eventn;
			}
			else if (initialland[position[*turn]]->Contains("���|")) {
				int ^chfa = 1;
				card(chfa, turn, money, position, initialland);
				storeevent(name+L"��F���|");
				checkenter();
			}
			else if (initialland[position[*turn]]->Contains("�R�B")) {
				int ^chfa = 0;
				card(chfa, turn, money, position, initialland);
				storeevent(name+L"��F�R�B");
				checkenter();
			}
			else {
				Console::WriteLine("��F{0}", initialland[position[*turn]]);
				checkenter();
				storeevent(name+L"��F"+ initialland[position[*turn]]);
			}

		}
	}
	else {
		Console::WriteLine("��F{0}�A��ú��{1}��", initialland[position[*turn]],landprice[position[*turn]]);
		storeevent(name+L"��F" + initialland[position[*turn]]);
		checkenter();
		if (money[*turn] < landprice[position[*turn]]) {
			eventn = checkasset(landprice[position[*turn]],turn, position, money, landprice, buy, house);
			if (*eventn == 1)
				return *eventn;
			mustsell = 1;
			sell(landprice[position[*turn]], mustsell, turn, money, buy, position, landprice, house, initialland, land,playern,name);
			Console::WriteLine("�w�v��");
			checkenter();
			storeevent(L"�wú��" + landprice[position[*turn]].ToString() + L"��");
		}
		else {
			money[*turn] -= landprice[position[*turn]];
			storeevent(L"�wú��" + landprice[position[*turn]].ToString()+L"��");
		}
			
	}
	return eventn;
}
int^ otherland(int ^turn, array<int>^money, array<int>^buy, array<int>^ position, array<int>^ landprice, array<int>^ house, array<String^>^ initialland, array<String^>^ land, int ^playern, String ^name) {
	int ^owner = buy[position[*turn]];
	int ^passmoney=0;
	int ^mustsell = 1;
	int ^eventn = 0;
	int ^paidok = 0;
	Console::Write(L"��F{0}�A���g�a��{1}�����a�Ҧ��A�ݤ�I�L���O: ", initialland[position[*turn]], *owner+1);
	storeevent(name+L"��F" + initialland[position[*turn]]+L"�ݤ�I�L���O��"+(*owner+1).ToString()+L"�����a");
	if (house[position[*turn]] > 0) {
		if (house[position[*turn]] == 1)
			*passmoney = landprice[position[*turn]] / 2;
		else if (house[position[*turn]] == 2)
			*passmoney = landprice[position[*turn]];
		else if (house[position[*turn]] == 3)
			*passmoney = landprice[position[*turn]] / 2 * 3;
		else if (house[position[*turn]] == 4)
			*passmoney = landprice[position[*turn]] * 3;
		else if (house[position[*turn]] == 5)
			*passmoney = landprice[position[*turn]] * 5;
	}
	else
		*passmoney = landprice[position[*turn]] / 10;
	Console::WriteLine("{0}��", *passmoney);
	checkenter();
	if (money[*turn] >= *passmoney) {
		money[*turn] -= *passmoney;
		money[*owner] += *passmoney;
		Console::WriteLine("�w��I");
		storeevent(L"�w��I" + passmoney->ToString()+L"���L���O");
		checkenter();
	}
	else {
		eventn = checkasset(passmoney, turn, position, money, landprice, buy, house);
		if (*eventn == 1)
			return eventn;
		paidok=sell(passmoney, mustsell, turn, money, buy, position, landprice, house, initialland, land, playern, name);
			money[*owner] += *passmoney;
			storeevent(L"�w��I" + passmoney->ToString() + L"���L���O");
	}
	return eventn;
}
void card(int ^chfa,int ^turn, array<int>^money, array<int>^ position, array<String^>^ initialland) {
	Console::WriteLine("��F{0}", initialland[position[*turn]]);
	int ^num = 0;
	array<int>^cardcash = { 2000,1500,1000,2000,500,3000,1000,4000 };
	Random ^generator = gcnew Random;
	*num = generator->Next(0, 7);
	if (*chfa == 1) {
		array<String^>^cword = { L"�B�ʸ����a�x",L"�Ȧ�I�A�Q��",L"�g��p���ͷN",L"���ͷN���\",L"�����B��",L"���U�ѤH",L"��{�}�n����",L"���ֳz" };
		Console::WriteLine("���{0}�A�o��{1}��", cword[*num], cardcash[*num]);
	}	
	else {
		array<String^>^cword = { L"����������",L"������ɱo�a�x",L"�u�@�V�O",L"�O�I�z��",L"�o��j�Ǽ��Ǫ�",L"�Ѳ�����",L"�a���ϧU��",L"�q�v���ɱo�a�x" };
		Console::WriteLine("���{0}�A�o��{1}��", cword[*num], cardcash[*num]);
	}
	money[*turn] += cardcash[*num];
}
int ^ sell(int ^price,int ^mustsell,int ^turn, array<int>^money,array<int>^buy, array<int>^ position, array<int>^ landprice ,array<int>^ house, array<String^>^ initialland, array<String^>^ land,int ^playern,String ^name) {
	int ^i = 0;
	int ^num = 0;
	String^ choose;
	int ^paidok = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		if (buy[*i] == *turn) {
			*num = 1;
			break;
		}
	}
	if (*num == 0) {
		Console::WriteLine(L"�L����F�����i����");
		checkenter();
		return *paidok = 0;
	}
	while (true)
	{
		Console::WriteLine("�ѩ���������ݭn�i����A�ЫΡB�g�a���N����Ӫ��@�b");
		if (*mustsell == 1)
			Console::WriteLine(L"���ﶵ:�Фl:1�B�g�a:2");
		else if (*mustsell == 0)
			Console::WriteLine(L"���ﶵ:�Фl:1�B�g�a:2�B���}:q");
		choose = checkecharlength();
			if (choose == "1") {
				sellhouse(turn,position, money,  landprice, buy,  house, initialland, land,playern,name);
			}
			else if (choose == "2")
			{
				 sellland(turn,position,  money, landprice, buy,  house, initialland, land,playern,name);
			}
			if (*mustsell == 0 && choose == "q")
				break;
			if (money[*turn] >= *price) {
				Console::WriteLine(L"�I�M");
				money[*turn] -= *price;
				*paidok=1;
				break;
			}
	}
	return paidok;
}
void sellhouse(int ^ turn, array<int>^ position, array<int>^ money, array<int>^ landprice, array<int>^buy, array<int>^ house, array<String^>^ initialland, array<String^>^ land,int ^playern,String^name) {
	String ^choose;
	int ^island = 0;
	int ^i = 0;
	while (true)
	{
		Console::WriteLine(L"�п�J�Q�c��Фl���g�a�W�١A���}�Ы�q");
		choose = Console::ReadLine();
		if (choose->Length == 1) {
			if (choose == "q")
				break;
		}
		else {
			for (*i = 0; *i <= 39; *i += 1) {
				if (initialland[*i] == choose) {
					*island = 1;
					if (buy[*i] == *turn) {
						if (house[*i] > 0) {
							while (true) {
								Console::WriteLine(L"�п�J�Q�c��Фl���ƶq�A���}�Ы�q");
								choose = checkecharlength();
									int ^housenum = 0;
									if ( choose[0] > '0'&&choose[0] < '9') {
										housenum = Int32::Parse(choose);
										if (*housenum > house[*i])
											Console::WriteLine(L"�Ыμƶq����");
										else if (*housenum > 0 && *housenum <= house[*i]) {
											Console::WriteLine(L"�w�c��{0}�ɩФl", *housenum);
											storeevent(L"�w�c���b"+initialland[*i]+L"��" + housenum->ToString() + L"�ɩФl");
											house[*i] -= *housenum;
											if (landprice[*i] >= 3000)
												money[*turn] += *housenum * 1000;
											else
												money[*turn] += *housenum * 500;
											if (house[*i] > 0) {
												land[*i] = initialland[*i] + house[*i].ToString();
											}
											else if (house[*i] == 0)
												land[*i] = initialland[*i];
											int ^num = 1;
											int ^dice = 0;
											array<String^>^ role = { "*","+","-","/" };
											location(num,turn, dice,playern ,role, land, initialland, house, position, money);
											map(landprice, land, name, money, initialland,buy,playern);
										}
										else if (*housenum == 0)
											Console::WriteLine(L"�L�c�����Фl");
									}
									else if (choose == "q")
										break;
							}
						}
						else
							Console::WriteLine(L"���g�a�õL�Фl");
					}
					else
						Console::WriteLine(L"���g�a�ä��O�A�֦���");
					break;
				}
			}
			if (*island == 0)
				Console::WriteLine(L"�L���g�a");
		}
	}
}
void sellland(int ^ turn, array<int>^ position, array<int>^ money, array<int>^ landprice, array<int>^buy, array<int>^ house, array<String^>^ initialland, array<String^>^ land,int^ playern,String ^name) {
	String ^choose;
	int ^island =0;
	int ^i =0;
	while (true)
	{
		Console::WriteLine(L"�п�J�Q�c�檺�g�a�W�١A���}�Ы�q");
		choose = Console::ReadLine();
		if (choose->Length == 1) {
			if (choose == "q")
				break;
		}
		else {
			for (*i = 0; *i <= 39; *i += 1) {
				if (initialland[*i] == choose) {
					*island = 1;
					if (buy[*i] == *turn) {
						if (house[*i] > 0)
							Console::WriteLine(L"���g�a�W���Фl�A�Х��槹�Фl�A��g�a");
						else if (house[*i] == 0) {
							buy[*i] = -1;
							Console::WriteLine(L"�w��X");
							storeevent(L"�w�c��" + initialland[*i]);
							checkenter();
							money[*turn] += landprice[*i] / 2;
							int ^num = 1;
							int ^dice = 0;
							array<String^>^ role = { "*","+","-","/" };
							location(num, turn, dice,playern, role, land, initialland, house, position, money);
							map(landprice, land, name, money, initialland,buy,playern);
						}
					}
					else
						Console::WriteLine(L"���g�a�ä��A�֦���");
					break;
				}
			}
			if (*island == 0)
				Console::WriteLine(L"�õL���g�a");
		}

	}
}
void build(int ^ turn, array<int>^ position, array<int>^ money, array<int>^ landprice, array<int>^buy,array<int>^ house,array<String^>^ initialland, array<String^>^ land ,int ^playern,String ^name) {
	String ^choose;
	int ^houseprice = 0;
	int ^mustsell = 0;
	int ^paidok = 0;
	if (house[position[*turn]] <= 4) {
		while (true)
		{
			Console::Write(L"�Ыλ���: ");
			if (landprice[position[*turn]] < 3000) 
				*houseprice = 1000;
			else 
				*houseprice =2000;
			Console::WriteLine(*houseprice);
			Console::WriteLine(L"��F {0} �O�_�n�\�Фl�A��J(y)���ܭn�A��J(n)���ܤ��n", initialland[position[*turn]]);
			storeevent(name+L"��F" + initialland[position[*turn]]);
			choose=checkecharlength();
				if (choose == "y") {
					if (money[*turn] < *houseprice) {
						Console::WriteLine(L"�ѩ���������ݶi����");
						paidok= sell(houseprice, mustsell, turn, money, buy, position, landprice, house, initialland, land,playern,name);
						if (*paidok == 1) {
							house[position[*turn]] += 1;
							if (house[position[*turn]] < 4) {
								land[position[*turn]] = initialland[position[*turn]] + house[position[*turn]].ToString();
							}
							else if (house[position[*turn]] == 5) {
								land[position[*turn]] = initialland[position[*turn]] + L"^";
							}
							Console::WriteLine(L"�\�Ц��\");
							storeevent(L"�\�Ц��\");
							checkenter();
						}
						*paidok = 0;
					}
					else {
						money[*turn] -= *houseprice;
						house[position[*turn]] += 1;
						if (house[position[*turn]] < 4) {
							land[position[*turn]] = initialland[position[*turn]] + house[position[*turn]].ToString();
						}
						else if (house[position[*turn]] == 5) {
							land[position[*turn]] = initialland[position[*turn]] + L"^";
						}
						Console::WriteLine(L"�\�Ц��\");
						storeevent(L"�\�Ц��\");
						checkenter();
					}
					break;
				}
				else if (choose == "n")
					break;
		}
	}
	else {
		Console::WriteLine(L"�w�g�L�k�A�\�Фl");
		storeevent(L"�w�g�L�k�A�\�Фl");
		checkenter();
	}
}
int^ gotojail(int ^ turn, array<int>^ position, array<String^>^ initialland, array<String^>^ land) {
	int ^eventn = 2;//0:n,1:over,2:jail
	Console::WriteLine(L"���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����");
	storeevent(L"���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����");
	if (*turn == 0)
	checkenter();
	land[position[*turn]] = initialland [position[*turn]];
	position[*turn] = 10;
	return eventn;
}
int^ checkasset(int ^price,int ^ turn, array<int>^ position, array<int>^ money, array<int>^ landprice, array<int>^buy, array<int>^ house) {
	int ^i = 0;
	int ^asset = 0;
	int ^eventn = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		if (buy[*i] == *turn) {
			if (house[*i] > 0) {
				if (landprice[*i]>= 3000)
					*asset += 1000 * house[*i];
				else
					*asset +=500 * house[*i];
			}
			*asset += landprice[*i] / 2;
		}
	}
	*asset+= money[*turn];
	if (*asset < *price) {
		Console::WriteLine(L"�ثe�]���`�B�p���ú����B�A�}��  �C������");
		storeevent(L"�ثe�]���`�B�p���ú����B�A�}��  �C������");
		checkenter();
		*eventn = 1;
		return eventn;
	}
	return eventn;
}
void map(array<int>^landprice, array<String^>^land,String ^name,array<int>^money, array<String^>^initialland, array<int>^buy,int ^playern) {
	Console::Clear();
	int ^begin = 20;
	int ^end = 30;
	int ^turn =1;
	topdown(begin, end);
	topdownLR(begin, end, turn, landprice, land);
	*turn = 2;
	topdownLR(begin, end, turn, landprice, land);
	topdown(begin, end);
	*begin = 19;
	*end = 11;
	leftright(begin, end, landprice, land);
	*begin = 10;
	*end = 0;
	topdown(end, begin);
	*turn = 3;
	topdownLR(begin, end, turn, landprice, land);
	*turn = 4;
	topdownLR(begin, end, turn, landprice, land);
	topdown(end, begin);
	Console::WriteLine();
	Console::WriteLine(L"����W: {0} �{������: {1}",name,money[0]);
	Console::Write(L"�{���g�a: ");
	int ^i = 0;
	for (*i = 0; *i <= 39; *i += 1) {
		if (buy[*i] == 0)
			Console::Write(L"  {0}", initialland[*i]);
	}
	Console::WriteLine();
	int ^j = 0;
	for (*i = 1; *i < *playern; *i += 1) {
	Console::WriteLine(L"����W: {0}�����a �{������: {1}", *i+1,money[*i]);
	Console::Write(L"�{���g�a: ");
	for (*j = 0; *j <= 39; *j += 1) {
		if (buy[*j] == *i)
			Console::Write(L"  {0}", initialland[*j]);
	}
	Console::WriteLine();
	}
}
void topdown(int ^begin, int ^end) {
	int ^i = 0;
	Console::Write("{0}", L"�@");
	for (*i = *begin; *i <= *end+1; *i += 1) {
		Console::Write("{0}", L"�@�@�@�@");
	}
	Console::Write("{0}", L"�@");
	Console::WriteLine();
}
void topdownLR(int ^begin, int ^end, int ^turn, array<int>^landprice, array<String^>^land) {
	int ^i = 0;
	if (*turn == 1 || *turn == 2) {
		for (*i = *begin; *i <= *end; *i += 1) {
			Console::Write(L"|");
			if (*turn == 1) {
					Console::Write("{0,-5}", land[*i]);
					if (land[*i]->Contains(L"���c") || land[*i]->Contains(L"���|"))
						Console::Write(L" ");
			}
			else if (*turn == 2) {
				if (landprice[*i] == -1)
					Console::Write("{0,4}", "    ");
				else
					Console::Write("{0,4}", landprice[*i]);
				Console::Write("{0}", "    ");
			}
			if (*i == 30)
				Console::Write(L"|");
		}
	}
	else if (*turn == 3 || *turn == 4) {
		for (*i = *begin; *i >= *end; *i -= 1) {
		Console::Write(L"|");
		if (*turn == 3) {
			Console::Write("{0,-5}", land[*i]);
			if (land[*i]->Contains(L"�R�B") || land[*i]->Contains(L"���|")|| land[*i]->Contains(L"�c��"))
				Console::Write(L" ");
		}
		else if (*turn == 4) {
			if (landprice[*i] == -1)
				Console::Write("{0,4}", "    ");
			else
				Console::Write("{0,4}", landprice[*i]);
			Console::Write("{0}", "    ");
		}
		if (*i == 0)
			Console::Write(L"|");
		}
	}
	Console::WriteLine();
}
void leftright(int ^begin, int ^end, array<int>^landprice, array<String^>^land) {
	int ^i = 0;
	int ^difference = 12;//20,32
	int ^temp = 0;
	for (*i = *begin; *i >= *end; *i -= 1) {
		*temp = *i + *difference;
		printcountry(i, land);
		printspace();
		printcountry(temp,land);
		Console::WriteLine();
		printprice(i, landprice);
		printspace();
		printprice(temp, landprice);
		Console::WriteLine();
		if (*i == *end)
			break;
		Console::Write(L"�@�@�@�@�@");
		printspace();
		Console::Write(L"�@�@�@�@�@");
		Console::WriteLine();
		*difference += 2;
	}
}
void printcountry(int ^index, array<String^>^land) {
	Console::Write("|");
	Console::Write("{0,-5}",land[*index]);
	if(land[*index]->Contains(L"�R�B")|| land[*index]->Contains(L"���|"))
		Console::Write(L" ");
	Console::Write("|");
}
void printspace() {
	int ^i = 0;
	for (*i = 0; *i < 9; *i += 1) {
		if (*i == 8)
			Console::Write("        ");
		else
			Console::Write("         ");
	}
}
void printprice(int ^index, array<int>^landprice) {
	Console::Write( "|");
	if (landprice[*index] != -1) {
		Console::Write("{0,-5}", landprice[*index]);
		Console::Write("{0,-3}",L"   ");
	}
	else
		Console::Write(L"        ");
	Console::Write("|");
}
