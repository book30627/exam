#pragma once
#define _USE_MATH_DEFINES
#include<math.h>


namespace ConsoleApplication1form {
	
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// MyForm ���K�n
	/// </summary>
	/*ref class calculator {
	public:
	int numclick = 0;
	MyForm^ f = gcnew MyForm();
	void operato() {
	if (numclick == 1 ||  == 0) {
	label1->Text += textBox1->Text;
	numclick = 0;
	}
	else
	label1->Text = label1->Text->Remove(label1->Text->Length - 1, 1);
	textBox1->Text = "0";
	label1->Text += "-";
	}
	};*/
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public://EXP numclick=0 ���N 1 ���F�� -1���L
		int ^numclick = 0;
		int ^countl = 0;
		int ^ablecover = 0;
		int ^upcnt = 0;
		//String ^buffer;
		int ^entermulti = 0;
		int ^exit = 0;
		int ^FEbutton = 0;
		String ^memoryc="";
		wchar_t ^startbracket = gcnew wchar_t;
		wchar_t ^endbracket = gcnew wchar_t;
	private: System::Windows::Forms::Button^  button42;
	private: System::Windows::Forms::Button^  button43;
	private: System::Windows::Forms::Button^  button44;
	private: System::Windows::Forms::Button^  button45;
	private: System::Windows::Forms::Button^  button46;
	private: System::Windows::Forms::Button^  button47;
	private: System::Windows::Forms::Button^  button48;
	private: System::Windows::Forms::Button^  button49;
	private: System::Windows::Forms::Button^  button50;
	private: System::Windows::Forms::Button^  button51;
	private: System::Windows::Forms::Button^  button52;
	private: System::Windows::Forms::Button^  button53;
	private: System::Windows::Forms::Button^  button54;
	private: System::Windows::Forms::Button^  button55;
	private: System::Windows::Forms::Button^  button56;
	private: System::Windows::Forms::Button^  button57;
	private: System::Windows::Forms::Button^  button58;
	private: System::Windows::Forms::Button^  button59;
	private: System::Windows::Forms::ToolStripMenuItem^  �ɮ׿�JToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  �O����ToolStripMenuItem;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Button^  button60;


	public:

	public:









			 //int ^aconnect = 0;
		String^ tmptextbox;
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected:
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  �ϧΤ���ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  ��JToolStripMenuItem;

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button9;
	private: System::Windows::Forms::Button^  button10;
	private: System::Windows::Forms::Button^  button11;
	private: System::Windows::Forms::Button^  button12;
	private: System::Windows::Forms::Button^  button8;
	private: System::Windows::Forms::Button^  button13;
	private: System::Windows::Forms::Button^  button14;
	private: System::Windows::Forms::Button^  button15;
	private: System::Windows::Forms::Button^  button16;
	private: System::Windows::Forms::Button^  button17;
	private: System::Windows::Forms::Button^  button18;
	private: System::Windows::Forms::Button^  button19;
	private: System::Windows::Forms::Button^  button20;
	private: System::Windows::Forms::Button^  button21;
	private: System::Windows::Forms::Button^  button22;
	private: System::Windows::Forms::Button^  button23;
	private: System::Windows::Forms::Button^  button24;
	private: System::Windows::Forms::Button^  button25;
	private: System::Windows::Forms::Button^  button26;
	private: System::Windows::Forms::Button^  button27;
	private: System::Windows::Forms::Button^  button28;
	private: System::Windows::Forms::Button^  button29;
	private: System::Windows::Forms::Button^  button30;
	private: System::Windows::Forms::Button^  button31;
	private: System::Windows::Forms::Button^  button32;
	private: System::Windows::Forms::Button^  button33;
	private: System::Windows::Forms::Button^  button34;
	private: System::Windows::Forms::Button^  button35;
	private: System::Windows::Forms::Button^  button36;
	private: System::Windows::Forms::Button^  button37;
	private: System::Windows::Forms::Button^  button38;
	private: System::Windows::Forms::Button^  button39;
	private: System::Windows::Forms::Button^  button40;
	private: System::Windows::Forms::Button^  button41;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::Button^  button4;
	private: System::Windows::Forms::Button^  button5;
	private: System::Windows::Forms::Button^  button6;
	private: System::Windows::Forms::Button^  button7;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label1;








	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�ϧΤ���ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->��JToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�ɮ׿�JToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->�O����ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->button12 = (gcnew System::Windows::Forms::Button());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button13 = (gcnew System::Windows::Forms::Button());
			this->button14 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->button16 = (gcnew System::Windows::Forms::Button());
			this->button17 = (gcnew System::Windows::Forms::Button());
			this->button18 = (gcnew System::Windows::Forms::Button());
			this->button19 = (gcnew System::Windows::Forms::Button());
			this->button20 = (gcnew System::Windows::Forms::Button());
			this->button21 = (gcnew System::Windows::Forms::Button());
			this->button22 = (gcnew System::Windows::Forms::Button());
			this->button23 = (gcnew System::Windows::Forms::Button());
			this->button24 = (gcnew System::Windows::Forms::Button());
			this->button25 = (gcnew System::Windows::Forms::Button());
			this->button26 = (gcnew System::Windows::Forms::Button());
			this->button27 = (gcnew System::Windows::Forms::Button());
			this->button28 = (gcnew System::Windows::Forms::Button());
			this->button29 = (gcnew System::Windows::Forms::Button());
			this->button30 = (gcnew System::Windows::Forms::Button());
			this->button31 = (gcnew System::Windows::Forms::Button());
			this->button32 = (gcnew System::Windows::Forms::Button());
			this->button33 = (gcnew System::Windows::Forms::Button());
			this->button34 = (gcnew System::Windows::Forms::Button());
			this->button35 = (gcnew System::Windows::Forms::Button());
			this->button36 = (gcnew System::Windows::Forms::Button());
			this->button37 = (gcnew System::Windows::Forms::Button());
			this->button38 = (gcnew System::Windows::Forms::Button());
			this->button39 = (gcnew System::Windows::Forms::Button());
			this->button40 = (gcnew System::Windows::Forms::Button());
			this->button41 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->button42 = (gcnew System::Windows::Forms::Button());
			this->button43 = (gcnew System::Windows::Forms::Button());
			this->button44 = (gcnew System::Windows::Forms::Button());
			this->button45 = (gcnew System::Windows::Forms::Button());
			this->button46 = (gcnew System::Windows::Forms::Button());
			this->button47 = (gcnew System::Windows::Forms::Button());
			this->button48 = (gcnew System::Windows::Forms::Button());
			this->button49 = (gcnew System::Windows::Forms::Button());
			this->button50 = (gcnew System::Windows::Forms::Button());
			this->button51 = (gcnew System::Windows::Forms::Button());
			this->button52 = (gcnew System::Windows::Forms::Button());
			this->button53 = (gcnew System::Windows::Forms::Button());
			this->button54 = (gcnew System::Windows::Forms::Button());
			this->button55 = (gcnew System::Windows::Forms::Button());
			this->button56 = (gcnew System::Windows::Forms::Button());
			this->button57 = (gcnew System::Windows::Forms::Button());
			this->button58 = (gcnew System::Windows::Forms::Button());
			this->button59 = (gcnew System::Windows::Forms::Button());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->button60 = (gcnew System::Windows::Forms::Button());
			this->menuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->ImageScalingSize = System::Drawing::Size(20, 20);
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->fileToolStripMenuItem });
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(506, 28);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {
				this->�ϧΤ���ToolStripMenuItem,
					this->��JToolStripMenuItem, this->�ɮ׿�JToolStripMenuItem, this->�O����ToolStripMenuItem
			});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(45, 24);
			this->fileToolStripMenuItem->Text = L"File";
			// 
			// �ϧΤ���ToolStripMenuItem
			// 
			this->�ϧΤ���ToolStripMenuItem->Name = L"�ϧΤ���ToolStripMenuItem";
			this->�ϧΤ���ToolStripMenuItem->Size = System::Drawing::Size(181, 26);
			this->�ϧΤ���ToolStripMenuItem->Text = L"�ϧΤ���";
			this->�ϧΤ���ToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::�ϧΤ���ToolStripMenuItem_Click);
			// 
			// ��JToolStripMenuItem
			// 
			this->��JToolStripMenuItem->Name = L"��JToolStripMenuItem";
			this->��JToolStripMenuItem->Size = System::Drawing::Size(181, 26);
			this->��JToolStripMenuItem->Text = L"��g��J";
			this->��JToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::��JToolStripMenuItem_Click);
			// 
			// �ɮ׿�JToolStripMenuItem
			// 
			this->�ɮ׿�JToolStripMenuItem->Name = L"�ɮ׿�JToolStripMenuItem";
			this->�ɮ׿�JToolStripMenuItem->Size = System::Drawing::Size(181, 26);
			this->�ɮ׿�JToolStripMenuItem->Text = L"�ɮ׿�J";
			this->�ɮ׿�JToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::�ɮ׿�JToolStripMenuItem_Click);
			// 
			// �O����ToolStripMenuItem
			// 
			this->�O����ToolStripMenuItem->Name = L"�O����ToolStripMenuItem";
			this->�O����ToolStripMenuItem->Size = System::Drawing::Size(181, 26);
			this->�O����ToolStripMenuItem->Text = L"�O����";
			this->�O����ToolStripMenuItem->Click += gcnew System::EventHandler(this, &MyForm::�O����ToolStripMenuItem_Click);
			// 
			// button1
			// 
			this->button1->Enabled = false;
			this->button1->Location = System::Drawing::Point(0, 115);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(72, 34);
			this->button1->TabIndex = 1;
			this->button1->Text = L"MC";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(0, 155);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(86, 46);
			this->button2->TabIndex = 2;
			this->button2->Text = L"X^2";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// button9
			// 
			this->button9->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button9->Location = System::Drawing::Point(326, 155);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(86, 46);
			this->button9->TabIndex = 9;
			this->button9->Text = L"tan";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &MyForm::button9_Click);
			// 
			// button10
			// 
			this->button10->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button10->Location = System::Drawing::Point(246, 155);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(86, 46);
			this->button10->TabIndex = 10;
			this->button10->Text = L"cos";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &MyForm::button10_Click);
			// 
			// button11
			// 
			this->button11->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button11->Location = System::Drawing::Point(163, 155);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(86, 46);
			this->button11->TabIndex = 11;
			this->button11->Text = L"sin";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &MyForm::button11_Click);
			// 
			// button12
			// 
			this->button12->Location = System::Drawing::Point(81, 155);
			this->button12->Name = L"button12";
			this->button12->Size = System::Drawing::Size(86, 46);
			this->button12->TabIndex = 12;
			this->button12->Text = L"X^Y";
			this->button12->UseVisualStyleBackColor = true;
			this->button12->Click += gcnew System::EventHandler(this, &MyForm::button12_Click);
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(81, 197);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(86, 46);
			this->button8->TabIndex = 17;
			this->button8->Text = L"10^X";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &MyForm::button8_Click);
			// 
			// button13
			// 
			this->button13->Location = System::Drawing::Point(163, 197);
			this->button13->Name = L"button13";
			this->button13->Size = System::Drawing::Size(86, 46);
			this->button13->TabIndex = 16;
			this->button13->Text = L"log";
			this->button13->UseVisualStyleBackColor = true;
			this->button13->Click += gcnew System::EventHandler(this, &MyForm::button13_Click);
			// 
			// button14
			// 
			this->button14->Location = System::Drawing::Point(246, 197);
			this->button14->Name = L"button14";
			this->button14->Size = System::Drawing::Size(86, 46);
			this->button14->TabIndex = 15;
			this->button14->Text = L"EXP";
			this->button14->UseVisualStyleBackColor = true;
			this->button14->Click += gcnew System::EventHandler(this, &MyForm::button14_Click);
			// 
			// button15
			// 
			this->button15->Location = System::Drawing::Point(326, 197);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(86, 46);
			this->button15->TabIndex = 14;
			this->button15->Text = L"%";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &MyForm::button15_Click);
			// 
			// button16
			// 
			this->button16->Location = System::Drawing::Point(0, 197);
			this->button16->Name = L"button16";
			this->button16->Size = System::Drawing::Size(86, 46);
			this->button16->TabIndex = 13;
			this->button16->Text = L"��";
			this->button16->UseVisualStyleBackColor = true;
			this->button16->Click += gcnew System::EventHandler(this, &MyForm::button16_Click);
			// 
			// button17
			// 
			this->button17->Location = System::Drawing::Point(81, 242);
			this->button17->Name = L"button17";
			this->button17->Size = System::Drawing::Size(86, 46);
			this->button17->TabIndex = 22;
			this->button17->Text = L"CE";
			this->button17->UseVisualStyleBackColor = true;
			this->button17->Click += gcnew System::EventHandler(this, &MyForm::button17_Click);
			// 
			// button18
			// 
			this->button18->Location = System::Drawing::Point(163, 242);
			this->button18->Name = L"button18";
			this->button18->Size = System::Drawing::Size(86, 46);
			this->button18->TabIndex = 21;
			this->button18->Text = L"C";
			this->button18->UseVisualStyleBackColor = true;
			this->button18->Click += gcnew System::EventHandler(this, &MyForm::button18_Click);
			// 
			// button19
			// 
			this->button19->Font = (gcnew System::Drawing::Font(L"Wingdings", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(2)));
			this->button19->Location = System::Drawing::Point(246, 242);
			this->button19->Name = L"button19";
			this->button19->Size = System::Drawing::Size(86, 46);
			this->button19->TabIndex = 20;
			this->button19->Text = L"��";
			this->button19->UseVisualStyleBackColor = true;
			this->button19->Click += gcnew System::EventHandler(this, &MyForm::button19_Click);
			// 
			// button20
			// 
			this->button20->Location = System::Drawing::Point(326, 242);
			this->button20->Name = L"button20";
			this->button20->Size = System::Drawing::Size(86, 46);
			this->button20->TabIndex = 19;
			this->button20->Text = L"/";
			this->button20->UseVisualStyleBackColor = true;
			this->button20->Click += gcnew System::EventHandler(this, &MyForm::button20_Click);
			// 
			// button21
			// 
			this->button21->Location = System::Drawing::Point(0, 242);
			this->button21->Name = L"button21";
			this->button21->Size = System::Drawing::Size(86, 46);
			this->button21->TabIndex = 18;
			this->button21->Text = L"��";
			this->button21->UseVisualStyleBackColor = true;
			this->button21->Click += gcnew System::EventHandler(this, &MyForm::button21_Click);
			// 
			// button22
			// 
			this->button22->Location = System::Drawing::Point(81, 284);
			this->button22->Name = L"button22";
			this->button22->Size = System::Drawing::Size(86, 46);
			this->button22->TabIndex = 27;
			this->button22->Text = L"7";
			this->button22->UseVisualStyleBackColor = true;
			this->button22->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button23
			// 
			this->button23->Location = System::Drawing::Point(163, 284);
			this->button23->Name = L"button23";
			this->button23->Size = System::Drawing::Size(86, 46);
			this->button23->TabIndex = 26;
			this->button23->Text = L"8";
			this->button23->UseVisualStyleBackColor = true;
			this->button23->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button24
			// 
			this->button24->Location = System::Drawing::Point(246, 284);
			this->button24->Name = L"button24";
			this->button24->Size = System::Drawing::Size(86, 46);
			this->button24->TabIndex = 25;
			this->button24->Text = L"9";
			this->button24->UseVisualStyleBackColor = true;
			this->button24->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button25
			// 
			this->button25->Location = System::Drawing::Point(326, 284);
			this->button25->Name = L"button25";
			this->button25->Size = System::Drawing::Size(86, 46);
			this->button25->TabIndex = 24;
			this->button25->Text = L"*";
			this->button25->UseVisualStyleBackColor = true;
			this->button25->Click += gcnew System::EventHandler(this, &MyForm::button25_Click);
			// 
			// button26
			// 
			this->button26->Location = System::Drawing::Point(0, 284);
			this->button26->Name = L"button26";
			this->button26->Size = System::Drawing::Size(86, 46);
			this->button26->TabIndex = 23;
			this->button26->Text = L"�k";
			this->button26->UseVisualStyleBackColor = true;
			this->button26->Click += gcnew System::EventHandler(this, &MyForm::button26_Click);
			// 
			// button27
			// 
			this->button27->Location = System::Drawing::Point(81, 326);
			this->button27->Name = L"button27";
			this->button27->Size = System::Drawing::Size(86, 46);
			this->button27->TabIndex = 32;
			this->button27->Text = L"4";
			this->button27->UseVisualStyleBackColor = true;
			this->button27->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button28
			// 
			this->button28->Location = System::Drawing::Point(163, 326);
			this->button28->Name = L"button28";
			this->button28->Size = System::Drawing::Size(86, 46);
			this->button28->TabIndex = 31;
			this->button28->Text = L"5";
			this->button28->UseVisualStyleBackColor = true;
			this->button28->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button29
			// 
			this->button29->Location = System::Drawing::Point(246, 326);
			this->button29->Name = L"button29";
			this->button29->Size = System::Drawing::Size(86, 46);
			this->button29->TabIndex = 30;
			this->button29->Text = L"6";
			this->button29->UseVisualStyleBackColor = true;
			this->button29->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button30
			// 
			this->button30->Location = System::Drawing::Point(326, 326);
			this->button30->Name = L"button30";
			this->button30->Size = System::Drawing::Size(86, 46);
			this->button30->TabIndex = 29;
			this->button30->Text = L"-";
			this->button30->UseVisualStyleBackColor = true;
			this->button30->Click += gcnew System::EventHandler(this, &MyForm::button30_Click);
			// 
			// button31
			// 
			this->button31->Location = System::Drawing::Point(0, 326);
			this->button31->Name = L"button31";
			this->button31->Size = System::Drawing::Size(86, 46);
			this->button31->TabIndex = 28;
			this->button31->Text = L"n!";
			this->button31->UseVisualStyleBackColor = true;
			this->button31->Click += gcnew System::EventHandler(this, &MyForm::button31_Click);
			// 
			// button32
			// 
			this->button32->Location = System::Drawing::Point(81, 369);
			this->button32->Name = L"button32";
			this->button32->Size = System::Drawing::Size(86, 46);
			this->button32->TabIndex = 37;
			this->button32->Text = L"1";
			this->button32->UseVisualStyleBackColor = true;
			this->button32->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button33
			// 
			this->button33->Location = System::Drawing::Point(163, 369);
			this->button33->Name = L"button33";
			this->button33->Size = System::Drawing::Size(86, 46);
			this->button33->TabIndex = 36;
			this->button33->Text = L"2";
			this->button33->UseVisualStyleBackColor = true;
			this->button33->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button34
			// 
			this->button34->Location = System::Drawing::Point(246, 369);
			this->button34->Name = L"button34";
			this->button34->Size = System::Drawing::Size(86, 46);
			this->button34->TabIndex = 35;
			this->button34->Text = L"3";
			this->button34->UseVisualStyleBackColor = true;
			this->button34->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button35
			// 
			this->button35->Location = System::Drawing::Point(326, 369);
			this->button35->Name = L"button35";
			this->button35->Size = System::Drawing::Size(86, 46);
			this->button35->TabIndex = 34;
			this->button35->Text = L"+";
			this->button35->UseVisualStyleBackColor = true;
			this->button35->Click += gcnew System::EventHandler(this, &MyForm::button35_Click);
			// 
			// button36
			// 
			this->button36->Location = System::Drawing::Point(0, 369);
			this->button36->Name = L"button36";
			this->button36->Size = System::Drawing::Size(86, 46);
			this->button36->TabIndex = 33;
			this->button36->Text = L"��";
			this->button36->UseVisualStyleBackColor = true;
			this->button36->Click += gcnew System::EventHandler(this, &MyForm::button36_Click);
			// 
			// button37
			// 
			this->button37->Location = System::Drawing::Point(81, 407);
			this->button37->Name = L"button37";
			this->button37->Size = System::Drawing::Size(86, 46);
			this->button37->TabIndex = 42;
			this->button37->Text = L")";
			this->button37->UseVisualStyleBackColor = true;
			this->button37->Click += gcnew System::EventHandler(this, &MyForm::button37_Click);
			// 
			// button38
			// 
			this->button38->Location = System::Drawing::Point(163, 407);
			this->button38->Name = L"button38";
			this->button38->Size = System::Drawing::Size(86, 46);
			this->button38->TabIndex = 41;
			this->button38->Text = L"0";
			this->button38->UseVisualStyleBackColor = true;
			this->button38->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// button39
			// 
			this->button39->Location = System::Drawing::Point(246, 407);
			this->button39->Name = L"button39";
			this->button39->Size = System::Drawing::Size(86, 46);
			this->button39->TabIndex = 40;
			this->button39->Text = L".";
			this->button39->UseVisualStyleBackColor = true;
			this->button39->Click += gcnew System::EventHandler(this, &MyForm::button39_Click);
			// 
			// button40
			// 
			this->button40->Location = System::Drawing::Point(326, 407);
			this->button40->Name = L"button40";
			this->button40->Size = System::Drawing::Size(86, 46);
			this->button40->TabIndex = 39;
			this->button40->Text = L"=";
			this->button40->UseVisualStyleBackColor = true;
			this->button40->Click += gcnew System::EventHandler(this, &MyForm::button40_Click);
			// 
			// button41
			// 
			this->button41->Location = System::Drawing::Point(0, 407);
			this->button41->Name = L"button41";
			this->button41->Size = System::Drawing::Size(86, 46);
			this->button41->TabIndex = 38;
			this->button41->Text = L"(";
			this->button41->UseVisualStyleBackColor = true;
			this->button41->Click += gcnew System::EventHandler(this, &MyForm::button41_Click);
			// 
			// button3
			// 
			this->button3->Enabled = false;
			this->button3->Location = System::Drawing::Point(326, 115);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(86, 34);
			this->button3->TabIndex = 43;
			this->button3->Text = L"M*";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(262, 115);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(72, 34);
			this->button4->TabIndex = 44;
			this->button4->Text = L"MS";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(199, 115);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(72, 34);
			this->button5->TabIndex = 45;
			this->button5->Text = L"M-";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(133, 115);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(72, 34);
			this->button6->TabIndex = 46;
			this->button6->Text = L"M+";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// button7
			// 
			this->button7->Enabled = false;
			this->button7->Location = System::Drawing::Point(67, 115);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(72, 34);
			this->button7->TabIndex = 47;
			this->button7->Text = L"MR";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// textBox1
			// 
			this->textBox1->Enabled = false;
			this->textBox1->Font = (gcnew System::Drawing::Font(L"�s�ө���", 19.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->textBox1->Location = System::Drawing::Point(0, 62);
			this->textBox1->Name = L"textBox1";
			this->textBox1->ReadOnly = true;
			this->textBox1->Size = System::Drawing::Size(494, 47);
			this->textBox1->TabIndex = 48;
			this->textBox1->Text = L"0";
			this->textBox1->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox1->Click += gcnew System::EventHandler(this, &MyForm::number);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 27);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(0, 15);
			this->label1->TabIndex = 49;
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// button42
			// 
			this->button42->Enabled = false;
			this->button42->Location = System::Drawing::Point(0, 155);
			this->button42->Name = L"button42";
			this->button42->Size = System::Drawing::Size(86, 46);
			this->button42->TabIndex = 50;
			this->button42->Text = L"X^3";
			this->button42->UseVisualStyleBackColor = true;
			this->button42->Visible = false;
			this->button42->Click += gcnew System::EventHandler(this, &MyForm::button42_Click);
			// 
			// button43
			// 
			this->button43->Enabled = false;
			this->button43->Location = System::Drawing::Point(248, 197);
			this->button43->Name = L"button43";
			this->button43->Size = System::Drawing::Size(86, 46);
			this->button43->TabIndex = 51;
			this->button43->Text = L"dms";
			this->button43->UseVisualStyleBackColor = true;
			this->button43->Visible = false;
			this->button43->Click += gcnew System::EventHandler(this, &MyForm::button43_Click);
			// 
			// button44
			// 
			this->button44->Enabled = false;
			this->button44->Location = System::Drawing::Point(326, 197);
			this->button44->Name = L"button44";
			this->button44->Size = System::Drawing::Size(86, 46);
			this->button44->TabIndex = 52;
			this->button44->Text = L"deg";
			this->button44->UseVisualStyleBackColor = true;
			this->button44->Visible = false;
			this->button44->Click += gcnew System::EventHandler(this, &MyForm::button44_Click);
			// 
			// button45
			// 
			this->button45->Enabled = false;
			this->button45->Location = System::Drawing::Point(81, 197);
			this->button45->Name = L"button45";
			this->button45->Size = System::Drawing::Size(86, 46);
			this->button45->TabIndex = 53;
			this->button45->Text = L"e^X";
			this->button45->UseVisualStyleBackColor = true;
			this->button45->Visible = false;
			this->button45->Click += gcnew System::EventHandler(this, &MyForm::button45_Click);
			// 
			// button46
			// 
			this->button46->Enabled = false;
			this->button46->Location = System::Drawing::Point(0, 197);
			this->button46->Name = L"button46";
			this->button46->Size = System::Drawing::Size(86, 46);
			this->button46->TabIndex = 54;
			this->button46->Text = L"1/X";
			this->button46->UseVisualStyleBackColor = true;
			this->button46->Visible = false;
			this->button46->Click += gcnew System::EventHandler(this, &MyForm::button46_Click);
			// 
			// button47
			// 
			this->button47->Enabled = false;
			this->button47->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button47->Location = System::Drawing::Point(326, 155);
			this->button47->Name = L"button47";
			this->button47->Size = System::Drawing::Size(86, 46);
			this->button47->TabIndex = 55;
			this->button47->Text = L"atan";
			this->button47->UseVisualStyleBackColor = true;
			this->button47->Visible = false;
			this->button47->Click += gcnew System::EventHandler(this, &MyForm::button47_Click);
			// 
			// button48
			// 
			this->button48->Enabled = false;
			this->button48->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button48->Location = System::Drawing::Point(246, 155);
			this->button48->Name = L"button48";
			this->button48->Size = System::Drawing::Size(86, 46);
			this->button48->TabIndex = 56;
			this->button48->Text = L"acos";
			this->button48->UseVisualStyleBackColor = true;
			this->button48->Visible = false;
			this->button48->Click += gcnew System::EventHandler(this, &MyForm::button48_Click);
			// 
			// button49
			// 
			this->button49->Enabled = false;
			this->button49->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button49->Location = System::Drawing::Point(163, 155);
			this->button49->Name = L"button49";
			this->button49->Size = System::Drawing::Size(86, 46);
			this->button49->TabIndex = 57;
			this->button49->Text = L"asin";
			this->button49->UseVisualStyleBackColor = true;
			this->button49->Visible = false;
			this->button49->Click += gcnew System::EventHandler(this, &MyForm::button49_Click);
			// 
			// button50
			// 
			this->button50->Enabled = false;
			this->button50->Location = System::Drawing::Point(81, 155);
			this->button50->Name = L"button50";
			this->button50->Size = System::Drawing::Size(86, 46);
			this->button50->TabIndex = 58;
			this->button50->Text = L"X^(1/y)";
			this->button50->UseVisualStyleBackColor = true;
			this->button50->Visible = false;
			this->button50->Click += gcnew System::EventHandler(this, &MyForm::button50_Click);
			// 
			// button51
			// 
			this->button51->Enabled = false;
			this->button51->Location = System::Drawing::Point(163, 197);
			this->button51->Name = L"button51";
			this->button51->Size = System::Drawing::Size(86, 46);
			this->button51->TabIndex = 59;
			this->button51->Text = L"ln";
			this->button51->UseVisualStyleBackColor = true;
			this->button51->Visible = false;
			this->button51->Click += gcnew System::EventHandler(this, &MyForm::button51_Click);
			// 
			// button52
			// 
			this->button52->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button52->Location = System::Drawing::Point(408, 407);
			this->button52->Name = L"button52";
			this->button52->Size = System::Drawing::Size(86, 46);
			this->button52->TabIndex = 60;
			this->button52->Text = L"atanh";
			this->button52->UseVisualStyleBackColor = true;
			this->button52->Click += gcnew System::EventHandler(this, &MyForm::button52_Click);
			// 
			// button53
			// 
			this->button53->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button53->Location = System::Drawing::Point(408, 369);
			this->button53->Name = L"button53";
			this->button53->Size = System::Drawing::Size(86, 46);
			this->button53->TabIndex = 61;
			this->button53->Text = L"acosh";
			this->button53->UseVisualStyleBackColor = true;
			this->button53->Click += gcnew System::EventHandler(this, &MyForm::button53_Click);
			// 
			// button54
			// 
			this->button54->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button54->Location = System::Drawing::Point(408, 326);
			this->button54->Name = L"button54";
			this->button54->Size = System::Drawing::Size(86, 46);
			this->button54->TabIndex = 62;
			this->button54->Text = L"asinh";
			this->button54->UseVisualStyleBackColor = true;
			this->button54->Click += gcnew System::EventHandler(this, &MyForm::button54_Click);
			// 
			// button55
			// 
			this->button55->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button55->Location = System::Drawing::Point(408, 284);
			this->button55->Name = L"button55";
			this->button55->Size = System::Drawing::Size(86, 46);
			this->button55->TabIndex = 63;
			this->button55->Text = L"tanh";
			this->button55->UseVisualStyleBackColor = true;
			this->button55->Click += gcnew System::EventHandler(this, &MyForm::button55_Click);
			// 
			// button56
			// 
			this->button56->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button56->Location = System::Drawing::Point(408, 242);
			this->button56->Name = L"button56";
			this->button56->Size = System::Drawing::Size(86, 46);
			this->button56->TabIndex = 64;
			this->button56->Text = L"cosh";
			this->button56->UseVisualStyleBackColor = true;
			this->button56->Click += gcnew System::EventHandler(this, &MyForm::button56_Click);
			// 
			// button57
			// 
			this->button57->Font = (gcnew System::Drawing::Font(L"�s�ө���", 10.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->button57->Location = System::Drawing::Point(408, 197);
			this->button57->Name = L"button57";
			this->button57->Size = System::Drawing::Size(86, 46);
			this->button57->TabIndex = 65;
			this->button57->Text = L"sinh";
			this->button57->UseVisualStyleBackColor = true;
			this->button57->Click += gcnew System::EventHandler(this, &MyForm::button57_Click);
			// 
			// button58
			// 
			this->button58->Location = System::Drawing::Point(408, 155);
			this->button58->Name = L"button58";
			this->button58->Size = System::Drawing::Size(86, 46);
			this->button58->TabIndex = 66;
			this->button58->Text = L"DEG";
			this->button58->UseVisualStyleBackColor = true;
			this->button58->Click += gcnew System::EventHandler(this, &MyForm::button58_Click);
			// 
			// button59
			// 
			this->button59->Location = System::Drawing::Point(408, 115);
			this->button59->Name = L"button59";
			this->button59->Size = System::Drawing::Size(86, 34);
			this->button59->TabIndex = 67;
			this->button59->Text = L"F-E";
			this->button59->UseVisualStyleBackColor = true;
			this->button59->Click += gcnew System::EventHandler(this, &MyForm::button59_Click);
			// 
			// textBox2
			// 
			this->textBox2->BackColor = System::Drawing::SystemColors::MenuBar;
			this->textBox2->Enabled = false;
			this->textBox2->Font = (gcnew System::Drawing::Font(L"�s�ө���", 19.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(136)));
			this->textBox2->Location = System::Drawing::Point(0, 62);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(494, 47);
			this->textBox2->TabIndex = 68;
			this->textBox2->TextAlign = System::Windows::Forms::HorizontalAlignment::Right;
			this->textBox2->Visible = false;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox2_TextChanged);
			this->textBox2->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &MyForm::textBox2_KeyDown);
			// 
			// button60
			// 
			this->button60->Enabled = false;
			this->button60->Location = System::Drawing::Point(177, 207);
			this->button60->Name = L"button60";
			this->button60->Size = System::Drawing::Size(143, 59);
			this->button60->TabIndex = 69;
			this->button60->Text = L"�ɮ׶}��";
			this->button60->UseVisualStyleBackColor = true;
			this->button60->Visible = false;
			this->button60->Click += gcnew System::EventHandler(this, &MyForm::button60_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(506, 453);
			this->Controls->Add(this->button60);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->button59);
			this->Controls->Add(this->button58);
			this->Controls->Add(this->button57);
			this->Controls->Add(this->button56);
			this->Controls->Add(this->button55);
			this->Controls->Add(this->button54);
			this->Controls->Add(this->button53);
			this->Controls->Add(this->button52);
			this->Controls->Add(this->button51);
			this->Controls->Add(this->button50);
			this->Controls->Add(this->button49);
			this->Controls->Add(this->button48);
			this->Controls->Add(this->button47);
			this->Controls->Add(this->button46);
			this->Controls->Add(this->button45);
			this->Controls->Add(this->button44);
			this->Controls->Add(this->button43);
			this->Controls->Add(this->button42);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->button7);
			this->Controls->Add(this->button6);
			this->Controls->Add(this->button5);
			this->Controls->Add(this->button4);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button37);
			this->Controls->Add(this->button38);
			this->Controls->Add(this->button39);
			this->Controls->Add(this->button40);
			this->Controls->Add(this->button41);
			this->Controls->Add(this->button32);
			this->Controls->Add(this->button33);
			this->Controls->Add(this->button34);
			this->Controls->Add(this->button35);
			this->Controls->Add(this->button36);
			this->Controls->Add(this->button27);
			this->Controls->Add(this->button28);
			this->Controls->Add(this->button29);
			this->Controls->Add(this->button30);
			this->Controls->Add(this->button31);
			this->Controls->Add(this->button22);
			this->Controls->Add(this->button23);
			this->Controls->Add(this->button24);
			this->Controls->Add(this->button25);
			this->Controls->Add(this->button26);
			this->Controls->Add(this->button17);
			this->Controls->Add(this->button18);
			this->Controls->Add(this->button19);
			this->Controls->Add(this->button20);
			this->Controls->Add(this->button21);
			this->Controls->Add(this->button8);
			this->Controls->Add(this->button13);
			this->Controls->Add(this->button14);
			this->Controls->Add(this->button15);
			this->Controls->Add(this->button16);
			this->Controls->Add(this->button12);
			this->Controls->Add(this->button11);
			this->Controls->Add(this->button10);
			this->Controls->Add(this->button9);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		
	private: System::Void �ϧΤ���ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		// 1�ϧ�
		textBox2->Visible = false;
		textBox2->Enabled = false;
		for each(Control^ ctrl in this->Controls) {
			if (ctrl->Name->Contains("button")) {
				//label1->Text += ctrl->Name;
				if (ctrl->Name!="button42"&&ctrl->Name != "button43"&&ctrl->Name != "button44"&&ctrl->Name != "button45"&&ctrl->Name != "button46"&&ctrl->Name != "button47"&&ctrl->Name != "button48"&&ctrl->Name != "button49"&&ctrl->Name != "button50"&&ctrl->Name != "button51") {
					ctrl->Visible = true;
					if(ctrl->Text!="MC"&&ctrl->Text != "MR"&&ctrl->Text != "M*")
					ctrl->Enabled = true;
				}
				
			}
			else if (ctrl->Name == "textBox1" || ctrl->Name == "label1")
			{
				ctrl->Visible = true;
				if(ctrl->Name == "label1")
				ctrl->Enabled = true;
			}
		}
		if (memoryc->Length != 0) {
			button1->Enabled = true;
			button7->Enabled = true;
		}
		button60->Visible = false;
		button60->Enabled = false;
	}	

private: System::Void pictureBox1_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void number(System::Object^  sender, System::EventArgs^  e) {
	//�Ʀr��
	Button^ num = safe_cast<Button ^>(sender);
	if (textBox1->Text->Length < 25&&*numclick!=-2) {
		if (*ablecover == 1 || textBox1->Text == "0" || textBox1->Text->Contains("�k") || textBox1->Text->Contains("!"))
		{
			textBox1->Text = num->Text;
			*ablecover = 0;
		}
		else
			textBox1->Text += num->Text;
		*numclick = 1;
	}
}
private: System::Void button17_Click(System::Object^  sender, System::EventArgs^  e) {
	//CE
	textBox1->Text = "0";
	*numclick = 0;
	*FEbutton = 0;
}
private: System::Void button19_Click(System::Object^  sender, System::EventArgs^  e) {
	//�R����
	if (textBox1->Text->Length == 1)
		textBox1->Text = "0";
	else if (textBox1->Text[textBox1->Text->Length - 1] == '+'&&textBox1->Text[textBox1->Text->Length - 2] == 'e') {
		 //String ^a= textBox1->Text[textBox1->Text->Length - 1].ToString() +textBox1->Text[textBox1->Text->Length - 2];
		textBox1->Text = textBox1->Text->Replace("e+", "");
		 //textBox1->Text= (textBox1->Text->Length - 1).ToString();
		*numclick = 1;
	}
	else {
		textBox1->Text = textBox1->Text->Remove(textBox1->Text->Length - 1, 1);
		if(textBox1->Text[textBox1->Text->Length-1]=='+'&&textBox1->Text[textBox1->Text->Length - 2] == 'e'){
			*numclick = -1;
		}

	}
		
}
private: System::Void button18_Click(System::Object^  sender, System::EventArgs^  e) {
	//C
	textBox1->Text = "0";
	label1->Text = "";
	*numclick = 0;
	*FEbutton = 0;
}
private: System::Void button39_Click(System::Object^  sender, System::EventArgs^  e) {
	//�p���I
	if (!textBox1->Text->Contains(".") && textBox1->Text!= "�k"&&textBox1->Text[textBox1->Text->Length - 1] != ')'&& textBox1->Text[textBox1->Text->Length - 1] != '!') {
		textBox1->Text += ".";
		*ablecover = 0;
	}
		
}
private: System::Void button36_Click(System::Object^  sender, System::EventArgs^  e) {
	//���t��
	if (textBox1->Text->Contains("e+")&&!textBox1->Text->Contains("(")&&!textBox1->Text->Contains("!")) {
		textBox1->Text = textBox1->Text->Replace("e+", "e-");
	}
	else if (textBox1->Text->Contains("e-")&&!textBox1->Text->Contains("(")&& !textBox1->Text->Contains("!")) {
		textBox1->Text = textBox1->Text->Replace("e-", "e+");
	}
	else
	{
		if (textBox1->Text != "0") {
			if (textBox1->Text[0]=='-')
				textBox1->Text = textBox1->Text->Remove(0, 1);
			else
				textBox1->Text = "-(" + textBox1->Text+")";
		}
	}
}
private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
}

private: System::Void button20_Click(System::Object^  sender, System::EventArgs^  e) {
	//��
	if (label1->Text->Length == 0)
		operato();
	else if(label1->Text[label1->Text->Length-1]!='(')
		operato();
		if (*numclick != -1&& label1->Text[label1->Text->Length - 1] != '(') {
			if (label1->Text->Length == 0)
				label1->Text = "0";
			label1->Text += "/";
			*numclick = 0;
		}
			
}
private: System::Void button25_Click(System::Object^  sender, System::EventArgs^  e) {
	//��
	if (label1->Text->Length==0)
		operato();
	else if(label1->Text[label1->Text->Length - 1] != '(')
		operato();
		if (*numclick != -1&& label1->Text[label1->Text->Length - 1] != '(') {
			if (label1->Text->Length == 0)
				label1->Text = "0";
			label1->Text += "*";
			*numclick = 0;
		}
}
private: System::Void button30_Click(System::Object^  sender, System::EventArgs^  e) {
	//��
	if (label1->Text->Length == 0)
		operato();
	else if(label1->Text[label1->Text->Length - 1] != '(')
		operato();
		if (*numclick != -1&& label1->Text[label1->Text->Length - 1] != '(') {
			if (label1->Text->Length == 0)
				label1->Text = "0";
			label1->Text += "-";
			*numclick = 0;
		}
}
private: System::Void button35_Click(System::Object^  sender, System::EventArgs^  e) {
	//�[
	if (label1->Text->Length == 0)
		operato();
	else if(label1->Text[label1->Text->Length - 1] != '(')
		operato();
		if (*numclick != -1&& label1->Text[label1->Text->Length - 1] != '(') {
			if (label1->Text->Length == 0)
				label1->Text = "0";
			label1->Text += "+";
			*numclick = 0;
		}
}
	void operato() {
		//�B��
		//textBox1->Text = numclick->ToString();
		if (*numclick == 1) {
			if (textBox1->Text[textBox1->Text->Length - 1] == '.')
				textBox1->Text = textBox1->Text->Remove(textBox1->Text->Length - 1, 1);
			label1->Text += textBox1->Text;
			*numclick = 0;
		}
		else if (*numclick == 0&&label1->Text->Length!=0)
			label1->Text = label1->Text->Remove(label1->Text->Length - 1, 1);
		else if (*numclick == -1)
			return;
			
		textBox1->Text = "0";
}
private: System::Void button26_Click(System::Object^  sender, System::EventArgs^  e) {
	//��P�v
	if (*numclick != -2) {
		textBox1->Text = "�k";
		*numclick = 1;
		*ablecover = 1;
	}
}
private: System::Void button15_Click(System::Object^  sender, System::EventArgs^  e) {
	//���l��
	if (label1->Text->Length == 0)
		operato();
	else if(label1->Text[label1->Text->Length - 1] != '(')
		operato();
		if (*numclick != -1&& label1->Text[label1->Text->Length - 1] != '(') {
			if (label1->Text->Length == 0)
				label1->Text = "0";
			label1->Text += "%";
			*numclick = 0;
		}
}
private: System::Void button31_Click(System::Object^  sender, System::EventArgs^  e) {
	//���h
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			textBox1->Text += "!";
			*numclick = 1;
			*ablecover = 1;
		}
	}
	else {
		label1->Text += "!";
	}
}
private: System::Void button14_Click(System::Object^  sender, System::EventArgs^  e) {
	//EXP numclick=0 ���N 1 ���F�� -1���L
	int ^ok = 1;
	for (int ^i = 0; *i < textBox1->Text->Length; *i += 1) {
		if (*i == 0 && textBox1->Text[*i] == '-')
			continue;
		if (*i == 1 && textBox1->Text[*i] == '(')
			continue;
		if (*i == textBox1->Text->Length-1 && textBox1->Text[*i] == ')')
			continue;
		if (textBox1->Text[*i] - '0' <0 || textBox1->Text[*i] - '0' > 9) {
			*ok = 0;
			break;
		}
	}
	if (*ok==1&&*numclick!=-2) {
		*numclick = -1;
		textBox1->Text += "e+";
	}
}
private: System::Void button13_Click(System::Object^  sender, System::EventArgs^  e) {
	//log
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "log(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("log(");
	}
}
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e) {
	//10^X
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "10^(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("10^(");
	}
		
}
private: System::Void button9_Click(System::Object^  sender, System::EventArgs^  e) {
	//tan
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "tand(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "tanr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "tang(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("tand(");
		else if (button58->Text == "RAD")
			findrigth("tanr(");
		else if (button58->Text == "GRAD")
			findrigth("tang(");
	}
		
}
private: System::Void button10_Click(System::Object^  sender, System::EventArgs^  e) {
	//cos
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "cosd(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "cosr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "cosg(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("cosd(");
		else if (button58->Text == "RAD")
			findrigth("cosr(");
		else if (button58->Text == "GRAD")
			findrigth("cosg(");
	}
		
}
private: System::Void button11_Click(System::Object^  sender, System::EventArgs^  e) {
	//sin
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "sind(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "sinr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "sing(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("sind(");
		else if (button58->Text == "RAD")
			findrigth("sinr(");
		else if (button58->Text == "GRAD")
			findrigth("sing(");
	}
}
private: System::Void button16_Click(System::Object^  sender, System::EventArgs^  e) {
	//sqrt
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "��(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("��(");
	}
}
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
	//X^2
	if (*numclick != -2) {
	if (*numclick == 1 || textBox1->Text == "0") {
		*numclick = 1;
		textBox1->Text = "(" + textBox1->Text + ")^2";
		*ablecover = 1;
	}
	}
	else {
		label1->Text += "^2";
	}
}
private: System::Void button12_Click(System::Object^  sender, System::EventArgs^  e) {
	//X^Y
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			textBox1->Text = "(" + textBox1->Text + ")^";
			label1->Text += textBox1->Text;
			textBox1->Text = "0";
			*numclick = 0;
		}
	}
	else {
		label1->Text += "^";
		*numclick = -1;
	}
}
private: System::Void button44_Click(System::Object^  sender, System::EventArgs^  e) {
	//deg
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "deg(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("deg(");
	}
}
private: System::Void button41_Click(System::Object^  sender, System::EventArgs^  e) {
	//( �A����
	if (*numclick != -2) {
		*countl += 1;
		label1->Text += "(";

	}
	
}

private: System::Void button37_Click(System::Object^  sender, System::EventArgs^  e) {
	//) �k�A��
	if (*countl > 0 && *numclick == -2) {
		*countl -= 1;
		label1->Text += ")";
	}
	else if (*countl > 0&&*numclick==1) {
		*countl -= 1;
		textBox1->Text += ")";
		label1->Text += textBox1->Text;
		textBox1->Text = "0";
		*numclick = -2;
	}
}
private: System::Void button50_Click(System::Object^  sender, System::EventArgs^  e) {
	//X^(1/y)
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			textBox1->Text = "(" + textBox1->Text + ")yroot";
			label1->Text += textBox1->Text;
			textBox1->Text = "0";
			*numclick = 0;
		}
	}
	else
	{
		label1->Text +="yroot";
		*numclick = -1;
	}
}
private: System::Void button21_Click(System::Object^  sender, System::EventArgs^  e) {
	//�V�W��
	if (*upcnt == 0) {
	button2->Enabled = false; button2->Visible = false;
	button9->Enabled = false; button9->Visible = false;
	button10->Enabled = false; button10->Visible = false;
	button11->Enabled = false; button11->Visible = false;
	button12->Enabled = false; button12->Visible = false;
	button13->Enabled = false; button13->Visible = false;
	button14->Enabled = false; button14->Visible = false;
	button15->Enabled = false; button15->Visible = false;
	button16->Enabled = false; button16->Visible = false;
	button8->Enabled = false; button8->Visible = false;

	button42->Enabled = true; button42->Visible = true;
	button43->Enabled = true; button43->Visible = true;
	button44->Enabled = true; button44->Visible = true;
	button45->Enabled = true; button45->Visible = true;
	button46->Enabled = true; button46->Visible = true;
	button47->Enabled = true; button47->Visible = true;
	button48->Enabled = true; button48->Visible = true;
	button49->Enabled = true; button49->Visible = true;
	button50->Enabled = true; button50->Visible = true;
	button51->Enabled = true; button51->Visible = true;
	*upcnt = 1;
	}
	else
	{
		*upcnt = 0;
		button2->Enabled = true; button2->Visible = true;
		button9->Enabled = true; button9->Visible = true;
		button10->Enabled = true; button10->Visible = true;
		button11->Enabled = true; button11->Visible = true;
		button12->Enabled = true; button12->Visible = true;
		button13->Enabled = true; button13->Visible = true;
		button14->Enabled = true; button14->Visible = true;
		button15->Enabled = true; button15->Visible = true;
		button16->Enabled = true; button16->Visible = true;
		button8->Enabled = true; button8->Visible = true;

		button42->Enabled = false; button42->Visible = false;
		button43->Enabled = false; button43->Visible = false;
		button44->Enabled = false; button44->Visible = false;
		button45->Enabled = false; button45->Visible = false;
		button46->Enabled = false; button46->Visible = false;
		button47->Enabled = false; button47->Visible = false;
		button48->Enabled = false; button48->Visible = false;
		button49->Enabled = false; button49->Visible = false;
		button50->Enabled = false; button50->Visible = false;
		button51->Enabled = false; button51->Visible = false;
	}
}
private: System::Void button43_Click(System::Object^  sender, System::EventArgs^  e) {
	//dms
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "dms(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("dms(");
	}
}
private: System::Void button51_Click(System::Object^  sender, System::EventArgs^  e) {
	//ln
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "ln(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("ln(");
	}
}
private: System::Void button45_Click(System::Object^  sender, System::EventArgs^  e) {
	//e^X
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "e^(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("e^(");
	}
}
private: System::Void button46_Click(System::Object^  sender, System::EventArgs^  e) {
	//1/X
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "1/(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("1/(");
	}
}
private: System::Void button47_Click(System::Object^  sender, System::EventArgs^  e) {
	//atan
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "atand(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "atanr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "atang(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("atand(");
		else if (button58->Text == "RAD")
			findrigth("atanr(");
		else if (button58->Text == "GRAD")
			findrigth("atang(");
	}
}
private: System::Void button48_Click(System::Object^  sender, System::EventArgs^  e) {
	//acos
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "acosd(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "aocsr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "acosg(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("acosd(");
		else if (button58->Text == "RAD")
			findrigth("acosr(");
		else if (button58->Text == "GRAD")
			findrigth("acosg(");
	}
		
}
private: System::Void button49_Click(System::Object^  sender, System::EventArgs^  e) {
	//asin
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			if (button58->Text == "DEG")
				textBox1->Text = "asind(" + textBox1->Text + ")";
			else if (button58->Text == "RAD")
				textBox1->Text = "asinr(" + textBox1->Text + ")";
			else if (button58->Text == "GRAD")
				textBox1->Text = "asing(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		if (button58->Text == "DEG")
			findrigth("asind(");
		else if (button58->Text == "RAD")
			findrigth("asinr(");
		else if (button58->Text == "GRAD")
			findrigth("asing(");
	}
}
		 void  findrigth(String ^nb) {
			 //��k��
			 int ^i = 0;
			 int ^pos = 0;
			 int ^count = 0;
			 int ^put = 0;
			 int ^start = label1->Text->Length - 1;
			 if (label1->Text[label1->Text->Length - 1] == '!') {
				 *start=*start - 1;
			 }
			 for (*i = *start; *i >= 0; *i -= 1) {
				 if (label1->Text[*i] == ')')
					 *count += 1;
				 else if (label1->Text[*i] == '(') {
					 if (*count == 1) {
						 *put = 1;
					 }
					 else
						 *count -= 1;
				 }
				 if (*put == 1) {
					 if (*i==0||label1->Text[*i - 1] == '+' || label1->Text[*i - 1] == '-' || label1->Text[*i - 1] == '/' || label1->Text[*i - 1] == '%' || label1->Text[*i - 1] == '*') {
						 if (*i == 0)
							 *pos = 0;
						 else
							*pos = *i+1;
						 break;
					 }
				 }
			 }
			 label1->Text = label1->Text->Insert(*pos, nb);
			 label1->Text += ")";
		 }
private: System::Void button42_Click(System::Object^  sender, System::EventArgs^  e) {
	//X^3
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "(" + textBox1->Text + ")^3";
			*ablecover = 1;
		}
	}
	else {
			label1->Text += "^3";
		}
}
private: System::Void button40_Click(System::Object^  sender, System::EventArgs^  e) {
//����
	textBox1->Text=textBox1->Text->Replace(" ","");
	label1->Text = label1->Text->Replace(" ", "");
	textBox1->Text = textBox1->Text->Replace("��", "sqrt");
	label1->Text = label1->Text->Replace("��", "sqrt");
	double ^ pi = M_PI;
	textBox1->Text = textBox1->Text->Replace("�k",pi->ToString());
	label1->Text = label1->Text->Replace("�k", pi->ToString());
	//if (label1->Text->Length != 0) {
		String ^buffer;
		if (label1->Text->Length >=2&& label1->Text[label1->Text->Length - 2] == ')'&& label1->Text[label1->Text->Length - 1] == '!')
			buffer = label1->Text;
		else if (label1->Text->Length != 0&&label1->Text[label1->Text->Length - 1] == ')')
			buffer = label1->Text;
		else if(label1->Text->Length!=0)
			buffer = label1->Text+ textBox1->Text;
		else if (label1->Text->Length == 0) {
			buffer = textBox1->Text;

		}
		//textBox1->Text = buffer;
		buffer += "@";
		label1->Text = "";
		double ^c = expr(buffer);
		if (*exit != 1) {
			if (*FEbutton == 1) {
				countFE(c);
			}
			else
			textBox1->Text=c->ToString();
		}
		else {
			*exit = 0;
			textBox1->Text="�L�k���";
			//MessageBox::Show("�L�k���");
		/*	msg->Show("�L�k���");*/
			//this->ShowDialog();
		}
		*numclick = 1;
		*ablecover = 1;
	//	textBox1->Text = numclick->ToString();
	//}
}
		 double ^expr(String ^buffer) {
			 double ^value = 0.0;
			 int ^index = 0;
			 double ^temp = 0.0;
			 if (*exit == 1)
			 {
				 *value = -1;
				 return *value;
			 }
			 value = term(buffer, index);
			 while (true) {
				 if (buffer[*index] == '+') {
					 *index += 1;
					 temp = term(buffer, index);
					 *value += *temp;
				 }
				 else if (buffer[*index] == '-') {
					 *index += 1;
					 temp = term(buffer, index);
					 *value -= *temp;
				 }
				 else if (buffer[*index] == '@') {
					 return value;
				 }
				 else if (buffer[*index] == '+' || buffer[*index] == '-' || buffer[*index] != '@') {
					 Console::WriteLine(L"�⦡�����~");
					 *value = -1;
					 *exit = 1;
					 return value;
				 }
			 }
		 }
		 double^ term(String ^buffer, int ^index) {
			 double ^value = 0.0;
			 double ^temp = 0.0;
			 if (*exit == 1)
			 {
				 *value = -1;
				 return value;

			 }
			 value = number(buffer, index);
			 while (true) {
				 if (buffer[*index] == '*') {
					 *index += 1;
					 temp = number(buffer, index);
					 *value *= *temp;
				 }
				 else if (buffer[*index] == '/') {
					 *index += 1;
					 temp = number(buffer, index);
					 if (*temp == 0) {
						 *exit = 1;
						 *value = -1;
						 return value;
					 }
					 *value /= *temp;
				 }
				 else if (buffer[*index] == '%') {
					 *index += 1;
					 temp = number(buffer, index);
					 if ((*value - (int)*value) > 0 || (*temp - (int)*temp) > 0) {
						 double ^fac = 0.0;
						 *fac = *value / *temp;
						 *value = *value - (int)*fac**temp;
					 }
					 else {
						 if (*temp == 0) {
							 *exit = 1;
							 *value = -1;
							 return value;
						 }
						 *value = (int)*value % (int)*temp;
					 }

				 }
				 else if ((buffer[*index] == '^') || (buffer[*index] == 'e'&&buffer[*index + 1] == '+') || buffer[*index] == '!' || (buffer[*index] == 'y'&&buffer[*index + 1] == 'r'&&buffer[*index + 2] == 'o'&&buffer[*index + 3] == 'o'&&buffer[*index + 4] == 't')) {
					 int ^f = 0;
					 if (*value - int(*value) != 0)
						 *f = 1;
					 getvalue(buffer, index, value, f);
				 }
				 else
					 break;
			 }
			 return value;
		 }
		 double^ number(String ^buffer, int ^index) {
			 double ^value = 0.0;
			 int ^isneg = 0;
			 if (*exit == 1)
			 {
				 *value = -1;
				 return value;

			 }
			 if (buffer[*index] == '-') {
				 *index += 1;
				 value = multioperator(buffer, index);
				 *value *= -1;
				 *isneg = 1;
			 }
			 else
				 value = multioperator(buffer, index);
			 if (*entermulti == 1) {
				 *entermulti = 0;
				 return value;
			 }
			 if (buffer[*index] - '0'<0 || buffer[*index] - '0'>9) {
				 *exit = 1;
				 *value = -1;
				 return *value;
			 }
			 while (buffer[*index] - '0' >= 0 && buffer[*index] - '0' <= 9) {
				 *value = *value * 10 + (buffer[*index] - '0');
				 *index += 1;
			 }
			 if (buffer[*index] != '.') {
				 int ^f = 0;
				 value = getvalue(buffer, index, value, f);
				 if (*isneg == 1)
					 *value *= -1;
				 return value;
			 }
			 double ^factor = 1.0;
			 *index += 1;
			 while (buffer[*index] - '0' >= 0 && buffer[*index] - '0' <= 9) {
				 *factor *= 0.1;
				 *value = *value + (buffer[*index] - '0')**factor;
				 *index += 1;
			 }
			 int ^f = 1;
			 value = getvalue(buffer, index, value, f);
			 if (*isneg == 1)
				 *value *= -1;
			 return value;
		 }
		 double^ getvalue(String ^buffer, int ^index, double ^value, int ^f) {
			 if (buffer[*index] == '@')
				 return value;
			 while (true) {
				 if (buffer[*index] == '^') {
					 *index += 1;
					 double ^temp = 0.0;
					 temp = number(buffer, index);
					 *value = pow(*value, *temp);
				 }
				 else if (buffer[*index] == 'e'&&buffer[*index + 1] == '+') {
					 *index += 2;
					 double ^temp = 0.0;
					 temp = number(buffer, index);
					 *value *= pow(10, *temp);
				 }
				 else if (buffer[*index] == 'e'&&buffer[*index + 1] == '-') {
					 *index += 2;
					 double ^temp = 0.0;
					 temp = number(buffer, index);
					 *value *= pow(0.1, *temp);
				 }
				 else if (buffer[*index] == '!'&&*f == 0) {
					 //Console::WriteLine(*value);
					 *index += 1;
					 if (*value == 1 || *value == 0)
						 *value = 1;
					 else {
						 int ^i = 0;
						 int ^tempvalue = 1;
						 for (*i = 1; *i <= *value; *i += 1) {
							 *tempvalue *= *i;
							 if (*tempvalue <= 0) {
								 *exit = 1;
								 *value = -1;
								 return value;
							 }
						 }
						 *value = *tempvalue;
					 }
				 }
				 else if (buffer[*index] == '!'&&*f == 1) {
					 *exit = 1;
					 *value = -1;
					 return *value;
				 }
				 else if (buffer[*index] == 'y'&&buffer[*index + 1] == 'r'&&buffer[*index + 2] == 'o'&&buffer[*index + 3] == 'o'&&buffer[*index + 4] == 't') {
					 *index += 5;
					 double ^temp = 0.0;
					 temp = number(buffer, index);
					 if (*temp == 0) {
						 *exit = 1;
						 *value = -1;
						 return value;
					 }
					 *value = pow(*value, 1 / (*temp));
				 }
				 else if (buffer[*index] == '@' || buffer[*index] == '%' || buffer[*index] == '/' || buffer[*index] == '*' || (buffer[*index] - '0' >= 0 && buffer[*index] - '0' <= 9) || buffer[*index] == '+' || buffer[*index] == '-')
					 break;
			 }
			 return value;
		 }
		 double^ multioperator(String ^buffer, int ^index) {
			 double ^value = 0.0;
			 String^ nbuffer;
			 if (*exit == 1)
			 {
				 *value = -1;
				 return value;
			 }
			 if (buffer[*index] == '(') {
				 *startbracket = '(';
				 *endbracket = ')';
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == '[') {
				 *startbracket = '[';
				 *endbracket = ']';
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == '{') {
				 *startbracket = '{';
				 *endbracket = '}';
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *entermulti = 1;
				 return value;
			 }
			/* else if (buffer[*index] == '�k') {
				 *index += 1;
				 *value = M_PI;
				 *entermulti = 1;
				 return value;
			 }*/
			 else if (buffer[*index] == 'e'&&buffer[*index + 1] == '^') {
				 *index += 2;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = exp(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'd'&&buffer[*index + 1] == 'm'&&buffer[*index + 2] == 's') {
				 *index += 3;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 //Console::WriteLine(*value);
				 double ^tempvalue = *value - (int)*value;
				 *tempvalue *= 60;
				 int ^cent = (int)*tempvalue;
				 //	Console::WriteLine(*cent/100);
				 *tempvalue = *tempvalue - (int)*tempvalue;
				 *tempvalue *= 60;
				 *value = (int)*value + (double)*cent / 100 + *tempvalue / 10000;
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'd'&&buffer[*index + 1] == 'e'&&buffer[*index + 2] == 'g') {
				 *index += 3;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 double ^tempvalue = *value - (int)*value;
				 *tempvalue *= 100;
				 int ^t = (int)*tempvalue;
				 double^ cent = (double)*t / 60;
				 *tempvalue = *tempvalue - (int)*tempvalue;
				 *tempvalue *= 100;
				 *tempvalue /= 3600;
				 *value = (int)*value + *cent + *tempvalue;
				 //Console::WriteLine(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 's'&&buffer[*index + 1] == 'i'&&buffer[*index + 2] == 'n'&&buffer[*index + 3] == 'h') {
				 *index += 4;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = sinh(*value);// *(M_PI / 180);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'c'&&buffer[*index + 1] == 'o'&&buffer[*index + 2] == 's'&&buffer[*index + 3] == 'h') {
				 *index += 4;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = cosh(*value);
				 //Console::WriteLine(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 't'&&buffer[*index + 1] == 'a'&&buffer[*index + 2] == 'n'&&buffer[*index + 3] == 'h') {
				 *index += 4;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = tanh(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 's'&&buffer[*index + 2] == 'i'&&buffer[*index + 3] == 'n'&&buffer[*index + 4] == 'h') {
				 *index += 5;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = asinh(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 'c'&&buffer[*index + 2] == 'o'&&buffer[*index + 3] == 's'&&buffer[*index + 4] == 'h') {
				 *index += 5;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = acosh(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 't'&&buffer[*index + 2] == 'a'&&buffer[*index + 3] == 'n'&&buffer[*index + 4] == 'h') {
				 *index += 5;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = atanh(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 's'&&buffer[*index + 1] == 'i'&&buffer[*index + 2] == 'n') {
				 *index += 3;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
				 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if(buffer[*index] == 'g'|| buffer[*index] == 'r'|| buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG")
					 *value = sin(*value*M_PI / 180);
				 else if (triple == "RAD")
					 *value = sin(*value);
				 else if (triple == "GRAD")
					 *value = sin(*value*0.9*M_PI / 180);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'c'&&buffer[*index + 1] == 'o'&&buffer[*index + 2] == 's') {
				 *index += 3;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
					 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if (buffer[*index] == 'g' || buffer[*index] == 'r' || buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG")
					 *value = cos(*value*M_PI / 180);
				 else if (triple == "RAD")
					 *value = cos(*value);
				 else if (triple == "GRAD")
					 *value = cos(*value*0.9*M_PI / 180);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 't'&&buffer[*index + 1] == 'a'&&buffer[*index + 2] == 'n') {
				 *index += 3;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
					 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if (buffer[*index] == 'g' || buffer[*index] == 'r' || buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG") {
					 if (*value==90|| *value == -90)
						 *exit = 1;
					 *value = tan(*value*M_PI / 180);
				 }
				 else if (triple == "RAD")
					 *value = tan(*value);
				 else if (triple == "GRAD") {
					 if (*value == 100 || *value == 300)
						 *exit = 1;
					 *value = tan(*value*0.9*M_PI / 180);
				 } 
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 't'&&buffer[*index + 2] == 'a'&&buffer[*index + 3] == 'n') {
				 *index += 4;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
					 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if (buffer[*index] == 'g' || buffer[*index] == 'r' || buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG")
					 *value = atan(*value) * 180 / M_PI;
				 else if (triple == "RAD")
					 *value = atan(*value);
				 else if (triple == "GRAD")
					 *value = (atan(*value) * 180 / M_PI) * 10 / 9;
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 'c'&&buffer[*index + 2] == 'o'&&buffer[*index + 3] == 's') {
				 *index += 4;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
					 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if (buffer[*index] == 'g' || buffer[*index] == 'r' || buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG")
					 *value = acos(*value) * 180 / M_PI;
				 else if (triple == "RAD")
					 *value = acos(*value);
				 else if (triple == "GRAD")
					 *value = (acos(*value) * 180 / M_PI) * 10 / 9;
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'a'&&buffer[*index + 1] == 's'&&buffer[*index + 2] == 'i'&&buffer[*index + 3] == 'n') {
				 *index += 4;
				 String ^triple;
				 if (buffer[*index] == 'd')
					 triple = "DEG";
				 else if (buffer[*index] == 'r')
					 triple = "RAD";
				 else if (buffer[*index] == 'g')
					 triple = "GRAD";
				 if (buffer[*index] == '(')
					 triple = "RAD";
				 else if (buffer[*index] == 'g' || buffer[*index] == 'r' || buffer[*index] == 'd')
					 *index += 1;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 if (triple == "DEG")
					 *value = asin(*value) * 180 / M_PI;
				 else if (triple == "RAD")
					 *value = asin(*value);
				 else if (triple == "GRAD")
					 *value = (asin(*value) * 180 / M_PI) * 10 / 9;
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 's'&&buffer[*index + 1] == 'q'&&buffer[*index + 2] == 'r'&&buffer[*index + 3] == 't') {
				 *index += 4;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = sqrt(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'l'&&buffer[*index + 1] == 'o'&&buffer[*index + 2] == 'g'&&buffer[*index + 3] == '1'&&buffer[*index + 4] == '0') {
				 *index += 5;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = log10(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'l'&&buffer[*index + 1] == 'o'&&buffer[*index + 2] == 'g') {
				 *index += 3;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = log10(*value);
				 *entermulti = 1;
				 return value;
			 }
			 else if (buffer[*index] == 'l'&&buffer[*index + 1] == 'n') {
				 *index += 2;
				 checkbracket(buffer, index);
				 nbuffer = extract(buffer, index, startbracket, endbracket);
				 value = expr(nbuffer);
				 *value = log(*value);
				 *entermulti = 1;
				 return value;
			 }
			 return value;
		 }
		 void checkbracket(String ^buffer, int ^index) {
			 if (buffer[*index] == '(') {
				 *startbracket = '(';
				 *endbracket = ')';
			 }
			 else if (buffer[*index] == '[') {
				 *startbracket = '[';
				 *endbracket = ']';
			 }
			 else if (buffer[*index] == '{') {
				 *startbracket = '{';
				 *endbracket = '}';
			 }
			 else 
				 *exit = 1;
		 }
		 String^ extract(String ^buffer, int ^index, wchar_t ^startbracket, wchar_t ^endbracket) {
			 if (*exit == 1)
				 return buffer;
			 *index += 1;
			 String ^nbuffer;
			 int ^count = 0;
			 do {
				 nbuffer += buffer[*index];
				 //	Console::WriteLine(buffer[*index]);
				 if (buffer[*index] == *startbracket)
					 *count += 1;
				 else if (buffer[*index] == *endbracket) {
					 if (*count == 0) {
						 if (nbuffer->Length == 1) {
							 *exit = 1;
							 return nbuffer;
						 }
						 nbuffer = nbuffer->Remove(nbuffer->Length - 1, 1);
						 nbuffer += "@";
						 *index += 1;
						 return nbuffer;
					 }
					 else
						 *count -= 1;
				 }
				 if (buffer[*index] == '@')
					 break;
				 *index += 1;

			 } while (buffer[*index] != '@');
			 *exit = 1;
			 return nbuffer;
		 }
private: System::Void button58_Click(System::Object^  sender, System::EventArgs^  e) {
	if (button58->Text == "DEG")
		button58->Text = "RAD";
	else if(button58->Text == "RAD")
		button58->Text = "GRAD";
	else if (button58->Text == "GRAD")
		button58->Text = "DEG";
}
private: System::Void button57_Click(System::Object^  sender, System::EventArgs^  e) {
	//sinh
	if (*numclick != -2){
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "sinh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else
	{
		findrigth("sinh(");
	}
}
private: System::Void button56_Click(System::Object^  sender, System::EventArgs^  e) {
	//cosh
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "cosh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("cosh(");
	}
}
private: System::Void button55_Click(System::Object^  sender, System::EventArgs^  e) {
	//tanh
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "tanh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("tanh(");
	}
}
private: System::Void button54_Click(System::Object^  sender, System::EventArgs^  e) {
	//asinh
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "asinh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("asinh(");
	}
}
private: System::Void button53_Click(System::Object^  sender, System::EventArgs^  e) {
	//acosh
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "acosh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else {
		findrigth("acosh(");
	}
}
private: System::Void button52_Click(System::Object^  sender, System::EventArgs^  e) {
	//atanh
	if (*numclick != -2) {
		if (*numclick == 1 || textBox1->Text == "0") {
			*numclick = 1;
			textBox1->Text = "atanh(" + textBox1->Text + ")";
			*ablecover = 1;
		}
	}
	else
	{
		findrigth("atanh(");
	}
}
private: System::Void button59_Click(System::Object^  sender, System::EventArgs^  e) {
	// F-E
	if (*FEbutton == 0)
		*FEbutton = 1;
	else if(*FEbutton == 1)
		*FEbutton = 0;
	if(*numclick!=-1)
	if (!textBox1->Text->Contains("e+")&& !textBox1->Text->Contains("e-")&& *FEbutton == 1) {
		int ^ok = 1;
		for (int ^i = 0; *i < textBox1->Text->Length; *i += 1) {
			if (*i == 0 && textBox1->Text[*i] == '-') {
				continue;
			}
			if (*i == 1 && textBox1->Text[*i] == '(')
				continue;
			if (*i == textBox1->Text->Length - 1 && textBox1->Text[*i] == ')')
				continue;
			if (textBox1->Text[*i] - '0' < 0 || textBox1->Text[*i] - '0' > 9) {
				if (textBox1->Text[*i] != '.') {
					*ok = 0;
					break;
				}
			}
		}
		if(*ok==1){
			if(*numclick!=-2)
			*numclick = 1;
			*ablecover = 1;
			double ^value = 0.0;
			double ^factor = 1.0;
			int ^dpos = -1;
			for (int ^i = 0; *i < textBox1->Text->Length; *i += 1) {
				if(textBox1->Text[*i] - '0' >= 0 && textBox1->Text[*i] - '0' <= 9) {
					*value = *value * 10 + (textBox1->Text[*i] - '0');
				}
				else if (textBox1->Text[*i] == '.') {
					dpos = *i;
					if (*dpos == textBox1->Text->Length - 1) {
						textBox1->Text = textBox1->Text->Remove(textBox1->Text->Length - 1, 1);
						*dpos = -1;
					}
					break;
				}
			}
			if (*dpos>0) {
				for (int ^i = *dpos; *i < textBox1->Text->Length; *i += 1) {
					if (textBox1->Text[*i] - '0' >= 0 && textBox1->Text[*i] - '0' <= 9) {
						*factor *= 0.1;
						*value = *value + (textBox1->Text[*i] - '0')**factor;
					}
				}	
			}
			int ^count = 0;
			double ^tempvalue = *value;
			if (*value < 1&&*value>0) {
				while (*value < 1) {
					*value *= 10;
					*count += 1;
				}
				textBox1->Text = textBox1->Text->Replace(tempvalue->ToString(), value->ToString() + "e-" + count->ToString());
			}
			else if (*value >= 10) {
				while (*value >=10) {
					*value /= 10;
					*count += 1;
				}
				textBox1->Text = textBox1->Text->Replace(tempvalue->ToString(), value->ToString()+"e+"+count->ToString());
			}
			else if (*value < 10 && *value >= 1||*value==0) {
				textBox1->Text = textBox1->Text->Replace(tempvalue->ToString(), value->ToString() + "e+0");
			}
		}
	}
	else if((textBox1->Text->Contains("e+")|| textBox1->Text->Contains("e-"))&&*FEbutton == 0){
		if (textBox1->Text->Contains("e+")) {
		//	int ^isneg = 0;
			int ^ok = 1;
			for (int ^i = 0; *i < textBox1->Text->Length; *i += 1) {
				if (*i == 0 && textBox1->Text[*i] == '-') {
					continue;
				}
				if (*i == 1 && textBox1->Text[*i] == '(')
					continue;
				if (*i == textBox1->Text->Length - 1 && textBox1->Text[*i] == ')')
					continue;
				if (textBox1->Text[*i] - '0' < 0 || textBox1->Text[*i] - '0' > 9) {
					if (textBox1->Text[*i] !='.'&&textBox1->Text[*i] != 'e' && textBox1->Text[*i] != '+') {
						*ok = 0;
						break;
					}
				}
			}
			if (*ok == 1 && *numclick != -2) {
				*numclick = 1;
				*ablecover=1;
				String ^buffer;
				buffer = textBox1->Text;
				buffer += "@";
				double ^c = expr(buffer);
				if (*exit != 1) {
					textBox1->Text = c->ToString();
				}
			}
		}
		else if (textBox1->Text->Contains("e-")) {
			int ^ok = 1;
			for (int ^i = 0; *i < textBox1->Text->Length; *i += 1) {
				if (*i == 0 && textBox1->Text[*i] == '-') {
					continue;
				}
				if (*i == 1 && textBox1->Text[*i] == '(')
					continue;
				if (*i == textBox1->Text->Length - 1 && textBox1->Text[*i] == ')')
					continue;
				if (textBox1->Text[*i] - '0' < 0 || textBox1->Text[*i] - '0' > 9) {
					if (textBox1->Text[*i] != '.'&&textBox1->Text[*i] != 'e' && textBox1->Text[*i] != '-') {
						*ok = 0;
						break;
					}
				}
			}
			if (*ok == 1 && *numclick != -2) {
				*numclick = 1;
				*ablecover = 1;
				String ^buffer;
				buffer = textBox1->Text;
				buffer += "@";
				double ^c = expr(buffer);
				if (*exit != 1) {
					textBox1->Text = c->ToString();
				}
			}
		}
	}
}
		void countFE(double ^value) {
			int ^count = 0;
			double ^tempvalue = *value;
			if (*value < 1 && *value>0) {
				while (*value < 1) {
					*value *= 10;
					*count += 1;
				}
				textBox1->Text =value->ToString() + "e-" + count->ToString();
			}
			else if (*value >= 10) {
				while (*value >= 10) {
					*value /= 10;
					*count += 1;
				}
				textBox1->Text = value->ToString() + "e+" + count->ToString();
			}
			else if (*value < 10 && *value >= 1 || *value == 0) {
				textBox1->Text =value->ToString() + "e+0";
			}
}
private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) {
	// Memorysave
	String ^buffer;
	buffer = textBox1->Text;
	buffer += "@";
	double ^c = expr(buffer);
	if (*exit != 1) {
		memoryc = c->ToString();
		button7->Enabled = true;
		button1->Enabled = true;
	}
}
private: System::Void button5_Click(System::Object^  sender, System::EventArgs^  e) {
	// Memoryminus
	if (memoryc->Length == 0) {
		String ^buffer;
		buffer = textBox1->Text;
		buffer += "@";
		double ^c = expr(buffer);
		if (*exit != 1) {
			*c = 0 - *c;
			memoryc = c->ToString();
			button7->Enabled = true;
			button1->Enabled = true;
		}
	}
	else {
		String ^buffer;
		buffer = textBox1->Text;
		buffer += "@";
		double ^c = expr(buffer);
		if (*exit != 1) {
			double ^m = Double::Parse(memoryc);
			*m -= *c;
			memoryc = m->ToString();
			button7->Enabled = true;
			button1->Enabled = true;
		}
	}
}
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {
	// Memoryplus
	if (memoryc->Length == 0) {
		String ^buffer;
		buffer = textBox1->Text;
		buffer += "@";
		double ^c = expr(buffer);
		if (*exit != 1) {
			*c = 0 + *c;
			memoryc = c->ToString();
			button7->Enabled = true;
			button1->Enabled = true;
		}
	}
	else {
		String ^buffer;
		buffer = textBox1->Text;
		buffer += "@";
		double ^c = expr(buffer);
		if (*exit != 1) {
			double ^m = Double::Parse(memoryc);
			*m += *c;
			memoryc = m->ToString();
			button7->Enabled = true;
			button1->Enabled = true;
		}
	}
}
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
	// Memoryshow
	textBox1->Text = memoryc;
	*ablecover = 1;
	if (*numclick != -2)
		*numclick = 1;
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	// Memoryclear
	memoryc = "";
	button7->Enabled = false;
	button1->Enabled = false;
}
private: System::Void ��JToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	for each(Control^ ctrl in this->Controls) {
		if (ctrl->Name->Contains("button")){
			//label1->Text += ctrl->Name;
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
		else if(ctrl->Name=="textBox1"||ctrl->Name=="label1")
		{
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
	}
	textBox2->Visible = true;
	textBox2->Enabled = true;
	textBox2->ReadOnly = false;
	textBox2->Text = "";
}
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {

}
private: System::Void textBox2_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
	if (e->KeyCode == Keys::Enter) {
		String ^buffer;
		buffer = textBox2->Text;
		buffer += "@";
		double ^c = expr(buffer);
		if (*exit != 1) {
			textBox2->Text = c->ToString();
		}
		else {
			*exit = 0;
			textBox2->Text = "�L�k���";
		}
	}
}
private: System::Void �ɮ׿�JToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	for each(Control^ ctrl in this->Controls) {
		if (ctrl->Name->Contains("button")) {
			//label1->Text += ctrl->Name;
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
		else if (ctrl->Name == "textBox1" || ctrl->Name == "label1")
		{
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
	}
	button60->Visible = true;
	button60->Enabled = true;
	textBox2->Visible = true;
	textBox2->Enabled = false;
	textBox2->ReadOnly = true;
	textBox2->Text = "";
}
		 OpenFileDialog ^opd = gcnew OpenFileDialog;
private: System::Void button60_Click(System::Object^  sender, System::EventArgs^  e) {
	if (opd->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
		StreamReader^ expline = gcnew StreamReader(opd->FileName);
		String^ line;
		int ^i = 0;
		while ((line = expline->ReadLine()) != nullptr)
		{
			line+= "@";
			double ^c = expr(line);
			if (*exit != 1) {
				textBox2->Text = c->ToString();
			}
			else {
				*exit = 0;
				textBox2->Text = "�L�k���";
			}
		}
		expline->Close();
	}
}
private: System::Void �O����ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
	for each(Control^ ctrl in this->Controls) {
		if (ctrl->Name->Contains("button")) {
			//label1->Text += ctrl->Name;
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
		else if (ctrl->Name == "textBox1" || ctrl->Name == "label1")
		{
			ctrl->Visible = false;
			ctrl->Enabled = false;
		}
	}
	textBox2->Visible = true;
	textBox2->Enabled = false;
	textBox2->ReadOnly = true;
	textBox2->Text = memoryc;
}
};
}
