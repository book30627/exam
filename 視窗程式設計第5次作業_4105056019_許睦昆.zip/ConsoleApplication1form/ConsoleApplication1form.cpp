// ConsoleApplication1form.cpp: �D�n�M���ɡC
/********
4105056019 �\���� �Ĥ����@�~12/5
 *********/
#include "stdafx.h"
#include "MyForm.h"
using namespace System;
using namespace ConsoleApplication1form;
[STAThreadAttribute]
int main(array<System::String ^> ^args)
{
	MyForm^ f = gcnew MyForm();
	f->ShowDialog();
    return 0;
}
