#pragma once

namespace ConsoleApplication1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// MyForm ���K�n
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO:  �b���[�J�غc�禡�{���X
			//
		}

	protected:
		/// <summary>
		/// �M������ϥΤ����귽�C
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:

	protected:

	protected:

	protected:

	protected:
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// �]�p�u��һݪ��ܼơC
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// �����]�p�u��䴩�һݪ���k - �ФŨϥε{���X�s�边�ק�
		/// �o�Ӥ�k�����e�C
		/// </summary>
		void InitializeComponent(void)
		{
			this->SuspendLayout();
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 15);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(282, 253);
			this->DoubleBuffered = true;
			this->Name = L"MyForm";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);

		}
#pragma endregion
		MenuStrip^ gm = gcnew  MenuStrip();
		array<PictureBox^>^ alienpic = gcnew array<PictureBox^>(12);
		array<PictureBox^>^ raserpic = gcnew array<PictureBox^>(12);
		array<PictureBox^>^ thunderpic = gcnew array<PictureBox^>(9);
		array<PictureBox^>^ stonepic = gcnew array<PictureBox^>(3);
		array<PictureBox^>^ lovepic = gcnew array<PictureBox^>(3);
		array<Button^>^ windowbutton = gcnew array<Button^>(4);
		array<Button^>^ losebutton = gcnew array<Button^>(2);
		Button ^nextbutton;
		ProgressBar ^bossblood= gcnew ProgressBar();
		PictureBox^ backg = gcnew PictureBox();//background
		PictureBox^ boss = gcnew PictureBox();
		PictureBox^ player = gcnew PictureBox();
		Label^ life = gcnew Label();
		Label^ gametitle = gcnew Label();
		Label^ Score = gcnew Label();
		Label^ losemsg;
		TextBox^ uploadname;
		Form^ msg;
		Timer ^ time;
		int ^countime = 0;
		int ^endraser = -1;
		int ^blood = 3;
		int ^score = 0;
		int ^maxattack = 0;
		array<int>^ changealien = gcnew array<int>(3);
		array<int>^ notmove = gcnew array<int>(5);
		array<int>^ thundernotmove = gcnew array<int>(3);
		int ^loved = 0;
		int ^enter = 0;
		int ^lifemax = 0;
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
		this->Size = System::Drawing::Size(500, 550);
		this->MaximizeBox = false;
		this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		this->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &MyForm::player_KeyDown);
		gametitle->Text = L"Space Invader";
		gametitle->Font = (gcnew System::Drawing::Font(L"�s�ө���", 36, System::Drawing::FontStyle::Regular));
		gametitle->Location = System::Drawing::Point(120, 80);
		gametitle->Size = System::Drawing::Size(300, 50);
		this->Controls->Add(gametitle);
		int ^startx = 200, ^starty = 150;
		for (int ^i = 0; *i < 4; *i += 1) {
			windowbutton[*i] = gcnew Button();
			windowbutton[*i]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
			windowbutton[*i]->Location = System::Drawing::Point(*startx, *starty);
			windowbutton[*i]->Size = System::Drawing::Size(90, 50);
			windowbutton[*i]->UseVisualStyleBackColor = true;
			if (*i == 0) {
				windowbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::startplay_Click);
				windowbutton[*i]->Text = L"�}�l�C��";
			}
			else if (*i == 1) {
				windowbutton[*i]->Text = L"�W�h";
				windowbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::rule_Click);
			}
			else if (*i == 2) {
				windowbutton[*i]->Text = L"�Ʀ�]";
				windowbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::head_Click);
			}
			else if (*i == 3) {
				windowbutton[*i]->Text = L"���}";
				windowbutton[*i]->Click += gcnew System::EventHandler(this, &MyForm::out_Click);
			}
			*starty += 80;
			this->Controls->Add(windowbutton[*i]);
		}
		array<ToolStripMenuItem^>^  select = gcnew array<ToolStripMenuItem^>(2);
		ToolStripMenuItem^ title = gcnew ToolStripMenuItem();
		title->Text = "�޲z";
		for (int ^i = 0; *i < 2; *i += 1) {
			select[*i] = gcnew ToolStripMenuItem();
			if (*i == 0) {
				select[*i]->Text = L"LifeMAX";
				select[*i]->Click += gcnew System::EventHandler(this, &MyForm::lifemax_Click);
			}
			else if (*i == 1) {
				select[*i]->Text = "���v";
				select[*i]->Click += gcnew System::EventHandler(this, &MyForm::copy_Click);
			}
			title->DropDownItems->Add(select[*i]);
		}
		gm->Items->Add(title);
		this->Controls->Add(gm);
		gm->BringToFront();
	}
	private: System::Void startplay_Click(System::Object^  sender, System::EventArgs^  e) {
		submain();
	}
	private: System::Void rule_Click(System::Object^  sender, System::EventArgs^  e) {
		Form ^rule = gcnew Form();
		rule->MaximizeBox = false;
		rule->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		rule->Size = System::Drawing::Size(300, 300);
		Label ^rl = gcnew Label();
		rl->Text = L"�Q��A�BD�䲾�ʡA�������~�P�H�W�L�̫᪺���u�A�_�h�ͩR-1";
		rl->Font = (gcnew System::Drawing::Font(L"�s�ө���", 16, System::Drawing::FontStyle::Regular));
		rl->Location = System::Drawing::Point(50, 50);
		rl->Size = System::Drawing::Size(200, 100);
		rule->Controls->Add(rl);
		rule->Show();
	}
	private: System::Void head_Click(System::Object^  sender, System::EventArgs^  e) {
		Form ^arrange = gcnew Form();
		arrange->MaximizeBox = false;
		arrange->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
		arrange->Size = System::Drawing::Size(500, 600);
		array<Label^>^ title = gcnew array<Label^>(2);
		array<Label^>^ arrn = gcnew array<Label^>(10);
		array<Label^>^ arrs = gcnew array<Label^>(10);
		array<String ^>^  arrscore = gcnew array<String ^>(10);
		array<String ^>^  arrname = gcnew array<String ^>(10);
		String^ line;
		int ^i = 0;
		StreamReader^ nr = gcnew StreamReader("name.txt");
		while ((line = nr->ReadLine()) != nullptr)
		{
			arrname[*i] = line;
			*i += 1;
		}
		nr->Close();
		*i = 0;
		StreamReader^ sr = gcnew StreamReader("score.txt");
		while ((line = sr->ReadLine()) != nullptr)
		{
			arrscore[*i] =line;
			*i += 1;
		}
		sr->Close();
		int ^startx = 50, ^starty = 25;
		for (int ^k = 0; *k < 2; *k += 1) {
			title[*k] = gcnew Label();
			if(*k==0)
				title[*k]->Text = L"�W��";
			else if(*k==1)
				title[*k]->Text = L"����";
			title[*k]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 18, System::Drawing::FontStyle::Regular));
			title[*k]->Location = System::Drawing::Point(*startx, *starty);
			title[*k]->Size = System::Drawing::Size(200, 50);
			*startx = 300;
			arrange->Controls->Add(title[*k]);
		}
		*startx = 50, *starty = 75;
		for (int ^k = 0; *k < *i; *k += 1) {
			arrn[*k] = gcnew Label();
			arrn[*k]->Text = arrname[*k];
			arrn[*k]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 18, System::Drawing::FontStyle::Regular));
			arrn[*k]->Location = System::Drawing::Point(*startx, *starty);
			arrn[*k]->Size = System::Drawing::Size(200, 50);
			*starty += 50;
			arrange->Controls->Add(arrn[*k]);
		}
		*startx = 300,*starty = 75;
		for (int ^k = 0; *k < *i; *k += 1) {
			arrs[*k] = gcnew Label();
			arrs[*k]->Text = arrscore[*k];
			arrs[*k]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 18, System::Drawing::FontStyle::Regular));
			arrs[*k]->Location = System::Drawing::Point(*startx, *starty);
			arrs[*k]->Size = System::Drawing::Size(200, 50);
			*starty += 50;
			arrange->Controls->Add(arrs[*k]);
		}
		arrange->Show();

	}
	private: System::Void out_Click(System::Object^  sender, System::EventArgs^  e) {
		Application::Exit();
	}
	private: System::Void  uploadscore_Click(System::Object^  sender, System::EventArgs^  e) {
		losemsg->Text = L"�W�Ǧ��\\n"+L"����:" + score->ToString();
		array<int>^  arrscore= gcnew array<int>(11);
		array<String ^>^  arrname = gcnew array<String ^>(11);
		String^ line;
		int ^i = 0;
		StreamReader^ sr = gcnew StreamReader("score.txt");
		while ((line = sr->ReadLine()) != nullptr)
		{
			arrscore[*i+1] = Int32::Parse(line);
			*i += 1;
		}
		sr->Close();
		*i = 0;
		StreamReader^ nr = gcnew StreamReader("name.txt");
		while ((line = nr->ReadLine()) != nullptr)
		{
			arrname[*i+1] = line;
			*i += 1;
		}
		nr->Close();
		if (*i == 0) {
			if (uploadname->Text == ""||*enter == 0)
				uploadname->Text = " ";
			if (*enter == 1)
				*enter == 0;
			StreamWriter^ sw = gcnew StreamWriter("score.txt");
			sw->WriteLine(score->ToString());
			sw->Close();
			StreamWriter^ nw = gcnew StreamWriter("name.txt");
			nw->WriteLine(uploadname->Text);
			nw->Close();
			losebutton[0]->Enabled = false;
		}
		else {
			int ^tempscore = 0;
			String ^tempname;
			arrscore[0] = *score;
			if (uploadname->Text == ""||*enter==0)
				uploadname->Text = " ";
			if (*enter == 1)
				*enter == 0;
			arrname[0] = uploadname->Text;
				for (int ^k =0; *k < *i; *k += 1) {
					if (arrscore[*k] < arrscore[*k+1]) {
						*tempscore = arrscore[*k];
						arrscore[*k] = arrscore[*k+1];
						arrscore[*k+1] = *tempscore;
						tempname = arrname[*k];
						arrname[*k] = arrname[*k+1];
						arrname[*k+1] = tempname;
					}
				}
				StreamWriter^ sw = gcnew StreamWriter("score.txt");
				if (*i < 10)
					*i += 1;
				for (int ^k = 0; *k < *i; *k += 1) {
					sw->WriteLine(arrscore[*k].ToString());
				}
				sw->Close();
				StreamWriter^ nw = gcnew StreamWriter("name.txt");
				for (int ^k = 0; *k < *i; *k += 1) {
					nw->WriteLine(arrname[*k]);
				}
				nw->Close();
				losebutton[0]->Enabled = false;
		}
	}
	private: System::Void  backtomenu_Click(System::Object^  sender, System::EventArgs^  e) {
		for (int ^k = 0; *k < 12; *k += 1) {
		this->Controls->Remove(alienpic[*k]);
		this->Controls->Remove(raserpic[*k]);
			if (*k < 3) {
			changealien[*k]=0;
			thundernotmove[*k] = 0;
			this->Controls->Remove(stonepic[*k]);
			this->Controls->Remove(lovepic[*k]);
			}
			if(*k<4)
				this->Controls->Add(windowbutton[*k]);
			if(*k<5)
				notmove[*k] = 0;
			if(*k<9)
				this->Controls->Remove(thunderpic[*k]);
		}
		array<int>^ changealien = gcnew array<int>(3);
		array<int>^ notmove = gcnew array<int>(5);
		array<int>^ thundernotmove = gcnew array<int>(3);
		this->Controls->Remove(backg);
		this->Controls->Remove(player);
		this->Controls->Remove(life);
		this->Controls->Remove(Score);
		this->Controls->Remove(boss);
		this->Controls->Remove(bossblood);
		this->Controls->Remove(nextbutton);
		this->Controls->Add(gametitle);
		this->Controls->Add(gm);
		*countime = 0;
		*endraser = -1;
		*blood = 3;
		*score = 0;
		*maxattack = 0;
		*loved = 0;
		*enter = 0;
		*lifemax = 0;
		msg->Close();
	}
	private: System::Void  next_Click(System::Object^  sender, System::EventArgs^  e) {
		player->Location = System::Drawing::Point(170, 450);
			for (int ^i = 0; *i < 12; *i += 1) {
				alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien3.png");
				alienpic[*i]->Visible = true;
				raserpic[*i]->Visible = false;
				raserpic[*i]->Location = System::Drawing::Point(player->Location.X + 20, player->Location.Y - 30);
				if (*i < 3) {
					notmove[*i] = 0;
					changealien[*i] = 0;
				}
			}
			*endraser = 0;
			this->Controls->Remove(nextbutton);
			*countime = 500;
			time->Start();
	}
	private: System::Void  enter_Click(System::Object^  sender, System::EventArgs^  e) {
		if (uploadname->Text == L"�п�J�W�r") {
			uploadname->ForeColor = System::Drawing::Color::Black;
			uploadname->Text = "";
			*enter = 1;
		}
	}
	private: System::Void  lifemax_Click(System::Object^  sender, System::EventArgs^  e) {
		System::Windows::Forms::DialogResult^ result = MessageBox::Show(L"�T�{�ϥ�Lifemax", L"�T��", MessageBoxButtons::YesNo);
		if (*result == System::Windows::Forms::DialogResult::Yes) {
			*lifemax = 1;
			*blood = 10000000;
		}
	}
	private: System::Void  copy_Click(System::Object^  sender, System::EventArgs^  e) {
		MessageBox::Show(L"�װ��g\n�\�����@�P�}�o�C", L"���v");
	}
	private: System::Void player_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) 
	{
		if (e->KeyCode == Keys::A&&player->Location.X>0) {
			player->Location = System::Drawing::Point(player->Location.X-8, player->Location.Y);
		}
		else if (e->KeyCode == Keys::D&&player->Location.X<230) {//Keys::Right
			player->Location = System::Drawing::Point(player->Location.X + 8, player->Location.Y);
		}
	}
	private: System::Void time_Tick(System::Object^  sender, System::EventArgs^  e) {
		if (*countime <= 480) {
			alienmove(0, 4, 0);
			if (*countime >= 20) {
				alienmove(4, 8, 1);
			}
			if (*countime >= 40) {
				alienmove(8, 12, 2);
			}
			if (*countime % 4 == 0) {
				if (*endraser <= 10) {
					*endraser += 1;
					raserpic[*endraser]->Location = System::Drawing::Point(player->Location.X + 20, player->Location.Y - 30);
					raserpic[*endraser]->Visible = true;
				}
			}
			rasermove();
			*countime += 1;
			hit();
		}
		else if(*countime==481){
			time->Stop();
			nextbutton = gcnew Button();
			nextbutton->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
			nextbutton->Size = System::Drawing::Size(90, 50);
			nextbutton->UseVisualStyleBackColor = true;
			nextbutton->Click += gcnew System::EventHandler(this, &MyForm::next_Click);
			nextbutton->Text = L"�U�@��";
			nextbutton->Location = System::Drawing::Point(300, 400);
			this->Controls->Add(nextbutton);
		}
		else if(*countime <= 980){
			alienmove2(0, 4, 0);
			if (*countime >= 510) {
				stonemove(0, 1, 3);
			}
			if (*countime >= 520) {
				alienmove2(4, 8, 1);
			}
			if (*countime >= 530) {
				stonemove(1, 2, 3);
			}
			if (*countime >= 540) {
				alienmove2(8, 12, 2);
			}
			if (*countime >= 550) {

				stonemove(2, 3, 3);
			}
			if (*countime >= 610) {

				lovemove(1, 2, 4);
			}
			if (*countime % 4 == 0) {
				if (*endraser <= 10) {
					*endraser += 1;
					raserpic[*endraser]->Location = System::Drawing::Point(player->Location.X + 20, player->Location.Y - 30);
					raserpic[*endraser]->Visible = true;
				}
			}
			rasermove();
			*countime += 1;
			hit();
		}
		else if (*countime<=1035&&*countime > 980) {
			bossmove();
			rasermove();//123
			*countime += 1;
		}
		else {
			rasermove();
			hitboss();
			*countime += 1;
			thundermove(0,3,0);
			if (*countime >= 1055) {
				thundermove(3,6,1);
			}
			if(*countime >= 1075)
			{
				thundermove(6, 9,2);
			}
			sixthunder();
			thunderhit();
		}
	}	
			 void sixthunder() {
				 if ((bossblood->Value <35||bossblood->Value <90)&& thundernotmove[0] == 1 && thundernotmove[1] == 1 && thundernotmove[2] == 1) {
					 for (int ^i = 0; *i < 6; *i += 1) {
						 if (thunderpic[*i]->Location.Y <= 500)
						 {
							 thunderpic[*i]->Location = System::Drawing::Point(thunderpic[*i]->Location.X, thunderpic[*i]->Location.Y + 10);
						 }
						 else {
							 thunderpic[*i]->Location = System::Drawing::Point(thunderpic[*i]->Location.X, -80);
							 if (thunderpic[*i]->Visible == false) {
								 thunderpic[*i]->Visible = true;
							 }
							 thundernotmove[0] = 0;
							 thundernotmove[1] = 0;
							 thundernotmove[2] = 0;
							 *countime = 1036;
							 if(*i==5&&*maxattack==0)
								*maxattack = 1;
							else if (*i == 5 && *maxattack == 1)
								 *maxattack = 2;
						 }
					 }
				 }
			 }
			 void thundermove(int ^start, int ^end,int^index) {
				 for (int ^i = *start; *i < *end; *i += 1) {
					 if (thunderpic[*i]->Location.Y <= 500&& thundernotmove[*index]==0)
					 {
						 thunderpic[*i]->Location = System::Drawing::Point(thunderpic[*i]->Location.X, thunderpic[*i]->Location.Y + 10);
					 }
					 else if (thunderpic[*i]->Location.Y >500 && thundernotmove[*index] == 0) {
						 thunderpic[*i]->Location = System::Drawing::Point(thunderpic[*i]->Location.X, -80);
						 if (thunderpic[*i]->Visible == false) {
							 thunderpic[*i]->Visible = true;
						 }
						 if (bossblood->Value < 110&& *maxattack==0&&*i== *end-1) {
							 thundernotmove[*index] = 1;
						 }
						 if (bossblood->Value <50  && *maxattack == 1 && *i == *end - 1) {
							 thundernotmove[*index] = 1;
						 }
					 }
				 }
			 }
			 void bossmove() {
					 if (boss->Location.Y <= -30)
					 {
						 boss->Location = System::Drawing::Point(boss->Location.X, boss->Location.Y + 10);
					 }
					 else {
						 for (int ^i = 0; *i < 9; *i += 1) {
							 thunderpic[*i]->Visible = true;
						 }
						 bossblood->Location = System::Drawing::Point(0, 0);
						 bossblood->Size = System::Drawing::Size(300, 20);
						 bossblood->Maximum = 180;
						 bossblood->Value = 180;
						 bossblood->Visible = true;;
						 this->Controls->Add(bossblood);
						 bossblood->BringToFront();
					 }
					 //boss->Location = System::Drawing::Point(0, -30);
			 }
			 void alienmove(int ^start,int ^end,int ^index) {//�~�P�H���ʲĤ@��
				 for (int ^i = *start; *i < *end; *i += 1) {
					 if (alienpic[*i]->Location.Y <= 500&&notmove[*index]==0)
					 {
						 alienpic[*i]->Location = System::Drawing::Point(alienpic[*i]->Location.X, alienpic[*i]->Location.Y + 10);
					 }
					 else {
						 alienpic[*i]->Location = System::Drawing::Point(alienpic[*i]->Location.X, -80);
						 if (alienpic[*i]->Visible==false) {
							 alienpic[*i]->Visible = true;
						 }
						 if (*countime >= 400) {
							 notmove[*index] = 1;
							 alienpic[*i]->Visible = false;
						 }
						 if (changealien[*index] == 0 &&*countime >= 180) {
							 alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien1.png");
							 if (*i == *end - 1)
								 changealien[*index] = 1;
						 }
						 if (changealien[*index] == 1&& *countime >= 320) {
							 alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien2.png");
							 if (*i == *end - 1)
								 changealien[*index] = 2;
						 }
					 }
				 }
			 }
			 void alienmove2(int ^start, int ^end, int ^index) {//�~�P�H���ʲĤG��
				 for (int ^i = *start; *i < *end; *i += 1) {
					 if (alienpic[*i]->Location.Y <= 500 && notmove[*index] == 0)
					 {
						 alienpic[*i]->Location = System::Drawing::Point(alienpic[*i]->Location.X, alienpic[*i]->Location.Y + 10);
					 }
					 else {
						 alienpic[*i]->Location = System::Drawing::Point(alienpic[*i]->Location.X, -80);
						 if (alienpic[*i]->Visible == false) {
							 alienpic[*i]->Visible = true;
						 }
						 if (*countime >= 920) {
							 notmove[*index] = 1;
							 alienpic[*i]->Visible = false;
						 }
						 if (changealien[*index] == 0 && *countime >= 680) {
							 alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien4.png");
							 if (*i == *end - 1)
								 changealien[*index] = 1;
						 }
						 if (changealien[*index] == 1 && *countime >= 820) {
							 alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien5.png");
							 if (*i == *end - 1)
								 changealien[*index] = 2;
						 }
					 }
				 }
			 }
			 void stonemove(int ^start, int ^end, int ^index) {//�k�۲���
				 for (int ^i = *start; *i < *end; *i += 1) {
					 if (stonepic[*i]->Location.Y <= 500 && notmove[*index] == 0)
					 {
						 stonepic[*i]->Location = System::Drawing::Point(stonepic[*i]->Location.X, stonepic[*i]->Location.Y + 10);
					 }
					 else {
						 if (*countime >= 920) {
							 stonepic[*i]->Location = System::Drawing::Point(stonepic[*i]->Location.X, 510);
						 }
						 else {
							 stonepic[*i]->Location = System::Drawing::Point(stonepic[*i]->Location.X, -80);
							 if (stonepic[*i]->Visible == false) {
								 stonepic[*i]->Visible = true;
							 }
						 }
					 }
				 }
			 }
			 void lovemove(int ^start, int ^end, int ^index) {//�R�߲���
				 for (int ^i = *start; *i < *end; *i += 1) {
					 if (lovepic[*i]->Location.Y <= 500 && notmove[*index] == 0)
					 {
						 lovepic[*i]->Location = System::Drawing::Point(lovepic[*i]->Location.X, lovepic[*i]->Location.Y + 10);
					 }
					 else {
						 if (*countime >= 920)
							 notmove[*index] = 1;
						 lovepic[*i]->Location = System::Drawing::Point(lovepic[*i]->Location.X, -80);
						 if (lovepic[*i]->Visible == false) {
							 lovepic[*i]->Visible = true;
						 }
					 }
				 }
			 }
			 void rasermove() {//�p�g����
				 for (int ^i = 0; *i <=*endraser; *i += 1) {
					 if (raserpic[*i]->Location.Y >= -30)
					 {
						 raserpic[*i]->Location = System::Drawing::Point(raserpic[*i]->Location.X, raserpic[*i]->Location.Y - 10);
					 }
					 else {
						 raserpic[*i]->Location = System::Drawing::Point(player->Location.X + 25, player->Location.Y - 30);
						 if (raserpic[*i]->Visible == false) {
							 raserpic[*i]->Visible = true;
						 }
					 }
				 }
				
			 }
			 void hit() {
				 for (int^i = 0; *i < 12; *i += 1)
				 {
					 for (int^j = 0; *j < 12; *j += 1)
					 {
						 if (raserpic[*j]->Visible == true && alienpic[*i]->Visible == true) {
							 if ((raserpic[*j]->Location.X+20 - alienpic[*i]->Location.X >= 0 && raserpic[*j]->Location.X+20 - alienpic[*i]->Location.X <= 50) && (raserpic[*j]->Location.Y - alienpic[*i]->Location.Y >= 0 && raserpic[*j]->Location.Y - alienpic[*i]->Location.Y <= 80) ||(raserpic[*j]->Location.X - alienpic[*i]->Location.X >= 0 && raserpic[*j]->Location.X - alienpic[*i]->Location.X <= 50) && (raserpic[*j]->Location.Y - alienpic[*i]->Location.Y >= 0 && raserpic[*j]->Location.Y - alienpic[*i]->Location.Y <= 80))
							 {
								 alienpic[*i]->Visible = false;
								 raserpic[*j]->Visible = false;
								 *score += 1;
								 Score->Text = "Scores: " + score->ToString();
							 }
						 }
					 }
					 if (alienpic[*i]->Location.Y == 500 && alienpic[*i]->Visible == true)
					 {
						 if (*blood > 0) {
							 *blood -= 1;
							 if(*lifemax==0)
								life->Text = "Life: " + blood->ToString();
							 else
								 life->Text = "Life:MAX";
						 }
							
						 if (*blood <= 0) {
							 time->Stop();
							 break;
						 }
					 }
				 }
				 if (*blood > 0) {
					for (int^i = 0; *i < 3; *i += 1)
					{
						if ((player->Location.X + 30 - stonepic[*i]->Location.X >= 0 && player->Location.X + 30 - stonepic[*i]->Location.X <= 50) && (player->Location.Y - stonepic[*i]->Location.Y >= 0 && player->Location.Y - stonepic[*i]->Location.Y <= 60) ||(player->Location.X + 60 - stonepic[*i]->Location.X >= 0 && player->Location.X + 60 - stonepic[*i]->Location.X <= 50) && (player->Location.Y - stonepic[*i]->Location.Y >= 0 && player->Location.Y - stonepic[*i]->Location.Y <= 60) || (player->Location.X - stonepic[*i]->Location.X >= 0 && player->Location.X - stonepic[*i]->Location.X <= 50) && (player->Location.Y - stonepic[*i]->Location.Y >= 0 && player->Location.Y - stonepic[*i]->Location.Y <= 60))
						{
							 if ((*blood > 0) && stonepic[*i]->Visible == true)
							{
								 *blood -= 1;
								stonepic[*i]->Visible = false;
							}
							 if (*blood <= 0) {
								 time->Stop();
								 break;
							} 
							 if (*lifemax == 0)
								 life->Text = "Life: " + blood->ToString();
							 else
								 life->Text = "Life:MAX";
						}
						if ((player->Location.X + 30 - lovepic[*i]->Location.X >= 0 && player->Location.X + 30 - lovepic[*i]->Location.X <= 50) && (player->Location.Y - lovepic[*i]->Location.Y >= 0 && player->Location.Y - lovepic[*i]->Location.Y <= 60) ||(player->Location.X + 60 - lovepic[*i]->Location.X >= 0 && player->Location.X + 60 - lovepic[*i]->Location.X <= 50) && (player->Location.Y - lovepic[*i]->Location.Y >= 0 && player->Location.Y - lovepic[*i]->Location.Y <= 60) || (player->Location.X - lovepic[*i]->Location.X >= 0 && player->Location.X - lovepic[*i]->Location.X <= 50) && (player->Location.Y - lovepic[*i]->Location.Y >= 0 && player->Location.Y - lovepic[*i]->Location.Y <= 60))
						{
							 if (lovepic[*i]->Visible == true)
							{
								 *blood += 1;
								lovepic[*i]->Visible = false;
							}
							 if (*lifemax == 0)
								 life->Text = "Life: " + blood->ToString();
							 else
								 life->Text = "Life:MAX";
						 }
					}
				 }
				 if(*blood<=0) {
					 losefunction(0);
				 }
			 }
			 void hitboss() {
				 if (bossblood->Value > 0) {
					 for (int^j = 0; *j < 12; *j += 1)
					 {
						 if (raserpic[*j]->Visible == true && boss->Visible == true)
						 {
							 if ((raserpic[*j]->Location.X + 20 - boss->Location.X >= 40 && raserpic[*j]->Location.X + 20 - boss->Location.X <= 250) && (raserpic[*j]->Location.Y - boss->Location.Y >= 0 && raserpic[*j]->Location.Y - boss->Location.Y <= 250) || (raserpic[*j]->Location.X - boss->Location.X >= 40 && raserpic[*j]->Location.X - boss->Location.X <= 250) && (raserpic[*j]->Location.Y - boss->Location.Y >= 0 && raserpic[*j]->Location.Y - boss->Location.Y <= 250))
							 {
								 raserpic[*j]->Visible = false;
								 *score += 1;
								 Score->Text = "Scores: " + score->ToString();
								 bossblood->Value -= 1;
								 if (bossblood->Value == 0) {
									 boss->Visible = false;
									 bossblood->Visible = false;
									 time->Stop();
									 break;
								 }

							 }
						 }
					 }
				 }
				 if (bossblood->Value <= 0) {
					 losefunction(1);
				 }
			 }
			 void thunderhit()
			 {
				 for (int^i = 0; *i < 9; *i += 1)
				 {
					 if ((player->Location.X + 30 - thunderpic[*i]->Location.X >= 10 && player->Location.X + 30 - thunderpic[*i]->Location.X <= 40) && (player->Location.Y - thunderpic[*i]->Location.Y >= 10 && player->Location.Y - thunderpic[*i]->Location.Y <= 70) ||(player->Location.X + 60 - thunderpic[*i]->Location.X >= 10 && player->Location.X + 60 - thunderpic[*i]->Location.X <= 40) && (player->Location.Y - thunderpic[*i]->Location.Y >= 10 && player->Location.Y - thunderpic[*i]->Location.Y <= 70) || (player->Location.X - thunderpic[*i]->Location.X >= 10 && player->Location.X - thunderpic[*i]->Location.X <= 40) && (player->Location.Y - thunderpic[*i]->Location.Y >= 10 && player->Location.Y - thunderpic[*i]->Location.Y <= 70))
					 {
						 if ((*blood > 0) && thunderpic[*i]->Visible == true)
						 {
							 *blood -= 1;
							 thunderpic[*i]->Visible = false;
						 }
						 if (*blood <= 0) {
							 time->Stop();
							 break;
						 }
						 if (*lifemax == 0)
							 life->Text = "Life: " + blood->ToString();
						 else
							 life->Text = "Life:MAX";
					 }
				 }
				 if (*blood <= 0) {
					 losefunction(0);
				 }
			 }

			 void losefunction(int ^n) {//0 lose 1 win
				 msg = gcnew Form();
				 losemsg = gcnew Label();
				 uploadname = gcnew TextBox();
				 for (int ^k = 0; *k < 2; *k += 1) {
					 losebutton[*k] = gcnew Button();
					 losebutton[*k]->Font = (gcnew System::Drawing::Font(L"�s�ө���", 13.8F, System::Drawing::FontStyle::Regular));
					 losebutton[*k]->Size = System::Drawing::Size(90, 50);
					 losebutton[*k]->UseVisualStyleBackColor = true;
					 if (*k == 0) {
						 losebutton[*k]->Click += gcnew System::EventHandler(this, &MyForm::uploadscore_Click);
						 losebutton[*k]->Text = L"�W�Ǥ���";
						 losebutton[*k]->Location = System::Drawing::Point(100, 200);
					 }
					 else if (*k == 1) {
						 losebutton[*k]->Click += gcnew System::EventHandler(this, &MyForm::backtomenu_Click);
						 losebutton[*k]->Text = L"�^��D���";
						 losebutton[*k]->Location = System::Drawing::Point(300, 200);
					 }
					 msg->Controls->Add(losebutton[*k]);
				 }
				 msg->MaximizeBox = false;
				 msg->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
				 msg->Size = System::Drawing::Size(500, 600);
				 uploadname->Font = (gcnew System::Drawing::Font(L"�s�ө���", 20, System::Drawing::FontStyle::Regular));
				 uploadname->Location = System::Drawing::Point(150, 150);
				 uploadname->Size = System::Drawing::Size(200, 40);
				 uploadname->Text = L"�п�J�W�r";
				 uploadname->ForeColor = System::Drawing::Color::Gray;
				 msg->Controls->Add(uploadname);
				 uploadname->Click += gcnew System::EventHandler(this, &MyForm::enter_Click);
				 if (*n == 0)
				 losemsg->Text =L"�A��F\n"+ L"����:" + score->ToString();
				 if (*n == 1)
				 losemsg->Text = L"�AĹ�F\n" + L"����:" + score->ToString();
				 losemsg->Font = (gcnew System::Drawing::Font(L"�s�ө���", 28, System::Drawing::FontStyle::Regular));
				 losemsg->Location = System::Drawing::Point(140, 50);
				 losemsg->Size = System::Drawing::Size(400, 80);
				 msg->Controls->Add(losemsg);
				 msg->Show();
			 }
			 void submain() {
				 this->Controls->Remove(windowbutton[0]);
				 this->Controls->Remove(windowbutton[1]);
				 this->Controls->Remove(windowbutton[2]);
				 this->Controls->Remove(windowbutton[3]);
				 this->Controls->Remove(gametitle);
				 this->Controls->Remove(gm);
				 initial();
				 galien();
				 glove();
				 gstone();
				 gthunder();
				 graser();
			 }
			 void initial() {
				 this->components = (gcnew System::ComponentModel::Container());
				 time = (gcnew System::Windows::Forms::Timer(this->components));
				 time->Interval = 50;
				 time->Enabled = true;
				 time->Tick += gcnew System::EventHandler(this, &MyForm::time_Tick);

				 backg->BackgroundImage = System::Drawing::Image::FromFile("background.png");
				 backg->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
				 backg->Location = System::Drawing::Point(0, 0);
				 backg->Size = System::Drawing::Size(300, 800);
				 this->Controls->Add(backg);
				 player->BackgroundImage = System::Drawing::Image::FromFile("spaceship.png");
				 player->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
				 player->Location = System::Drawing::Point(170, 450);
				 player->Size = System::Drawing::Size(60, 50);
				 player->BackColor = System::Drawing::Color::Black;
				 this->Controls->Add(player);
				 boss->Visible = true;
				 boss->BackgroundImage = System::Drawing::Image::FromFile("boss.png");
				 boss->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
				// boss->Location = System::Drawing::Point(0, -30);
				 boss->Location = System::Drawing::Point(0, -400);
				 boss->Size = System::Drawing::Size(300, 300);
				 boss->BackColor = System::Drawing::Color::Black;
				 this->Controls->Add(boss);
				 boss->BringToFront();
				 if(*lifemax==0)
					life->Text = L"Life:3";
				 else
					 life->Text = L"Life:MAX";
				 life->Font = (gcnew System::Drawing::Font(L"�s�ө���", 18, System::Drawing::FontStyle::Regular));
				 life->Location = System::Drawing::Point(300, 100);
				 life->Size = System::Drawing::Size(200, 40);
				 this->Controls->Add(life);
				 Score->Text = L"Scores:0";
				 Score->Font = (gcnew System::Drawing::Font(L"�s�ө���", 18, System::Drawing::FontStyle::Regular));
				 Score->Location = System::Drawing::Point(300, 140);
				 Score->Size = System::Drawing::Size(150, 40);
				 this->Controls->Add(Score);
			 }
			 void galien() {
				 int ^startx = 0,^starty=-80;
				 for (int ^i = 0; *i < 12; *i += 1) {
					 alienpic[*i] = gcnew PictureBox();
					 alienpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("alien0.png");
					 alienpic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 alienpic[*i]->Location = System::Drawing::Point(*startx, *starty);
					 alienpic[*i]->Size = System::Drawing::Size(50, 80);
					 alienpic[*i]->BackColor = System::Drawing::Color::Black;
					 *startx += 75; 
					 if (*i % 4 == 3)
						 *startx = 0;
					 this->Controls->Add(alienpic[*i]);
					 alienpic[*i]->BringToFront();
				 }
				 player->BringToFront();
			 }
			 void gstone() {
				 int ^startx = 0, ^starty = -80;
				 Random ^generator = gcnew Random;
				 array<int>^ repeat = gcnew array<int>(3) { 3, 0, 1 };
				 int ^num1 = 0, ^num2 = 0, ^temp = 0;
				 for (int ^i = 0; *i < 3; *i += 1) {
					 *num1 = generator->Next(0, 3);
					 *num2 = generator->Next(0, 3);
					 *temp = repeat[*num1];
					 repeat[*num1] = repeat[*num2];
					 repeat[*num2] = *temp;
				 }
				 for (int ^i = 0; *i <3; *i += 1) {
					 stonepic[*i] = gcnew PictureBox();
					 stonepic[*i]->BackgroundImage = System::Drawing::Image::FromFile("stone.png");
					 stonepic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 stonepic[*i]->Location = System::Drawing::Point(*startx, *starty);
					 stonepic[*i]->Size = System::Drawing::Size(50, 80);
					 stonepic[*i]->BackColor = System::Drawing::Color::Black;
					 *startx = repeat[*i] * 75;
					 this->Controls->Add(stonepic[*i]);
					 stonepic[*i]->BringToFront();
				 }
				 player->BringToFront();
			 }
			 void glove() {
				 int ^startx = 0, ^starty = -80;
				 for (int ^i = 0; *i <3; *i += 1) {
					 lovepic[*i] = gcnew PictureBox();
					 lovepic[*i]->BackgroundImage = System::Drawing::Image::FromFile("love.png");
					 lovepic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 lovepic[*i]->Location = System::Drawing::Point(*startx, *starty);
					 lovepic[*i]->Size = System::Drawing::Size(50, 80);
					 lovepic[*i]->BackColor = System::Drawing::Color::Black;
					 *startx = 130;
					 this->Controls->Add(lovepic[*i]);
					 lovepic[*i]->BringToFront();
				 }
				 player->BringToFront();
			 }
			 void gthunder() {
				 int ^startx = 0, ^starty =-80;
				 for (int ^i = 0; *i <9; *i += 1) {
					 thunderpic[*i] = gcnew PictureBox();
					 thunderpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("thunder.png");
					 thunderpic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 thunderpic[*i]->Location = System::Drawing::Point(*startx, *starty);
					 thunderpic[*i]->Size = System::Drawing::Size(50, 80);
					 thunderpic[*i]->BackColor = System::Drawing::Color::Black;
					 thunderpic[*i]->Visible = false;
					  *startx += 50;
					  if (*i == 5)
						 *startx = 75;
					 this->Controls->Add(thunderpic[*i]);
					 thunderpic[*i]->BringToFront();
				 }
				 boss->BringToFront();
				 player->BringToFront();
			 }
			 void graser() {
				 int ^startx = 0, ^starty = -80;
				 for (int ^i = 0; *i < 12; *i += 1) {
					 raserpic[*i] = gcnew PictureBox();
					 raserpic[*i]->BackgroundImage = System::Drawing::Image::FromFile("raser0.png");
					 raserpic[*i]->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
					 raserpic[*i]->Location = System::Drawing::Point(player->Location.X+20, player->Location.Y-30);
					 raserpic[*i]->Size = System::Drawing::Size(20, 30);
					 raserpic[*i]->BackColor = System::Drawing::Color::Black;
					 raserpic[*i]->Visible = false;
					 this->Controls->Add(raserpic[*i]);
					 raserpic[*i]->BringToFront();
				 }
				 player->BringToFront();
			 }
};
}
