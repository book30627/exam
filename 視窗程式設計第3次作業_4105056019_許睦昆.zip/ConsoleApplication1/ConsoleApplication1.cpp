// ConsoleApplication1.cpp : �w�q�D���x���ε{�����i�J�I�C
//
/********
4105056019 �\���� �ĤT���@�~10/31
 *********/
#include "stdafx.h"
#include<iostream>
#include<string>
#include<math.h>
#include<fstream>


using namespace std;
void eatspace(char *);
double expr(char *);
double* term(char*, int *);
double* number(char*, int *);
char* extract(char *, int *, char *, char *);
double* multioperator(char *, int *);
void checkbracket(char *, int *, char*, char*);
double* getvalue(char *, int *, double *, int *);
int main()
{
	int *choose = new int(0);
	char *buffer = new char[80];
	string *str = new string;
	while (true) {
		cout << "�п�ܿ�J���Ҧ��A1:expression���Ū�J 2:Console ��J" << endl;
		cin >> *choose;

		if (*choose == 1) {
			ifstream *ifileland = new ifstream("expression.txt", ios::in);
			while (!ifileland->eof()) {
				getline(*ifileland, *str, '\n');
			}
			ifileland->close();
			break;
		}
		else if (*choose == 2) {
			cout << "�п�J�B�⦡" << endl;
			cin >> *str;
			break;
		}
			
	}
	int *length = new int(0);
	*length = str->length();
	*length += 1;
	strcpy_s(buffer, *length,str->c_str());
	eatspace(buffer);
	if (!*(buffer + 0)) {
		delete[]buffer;
		delete str;
		delete length;
		delete choose;
		return 0;
	}
	//cout << buffer;
	cout << "=" << expr(buffer);
	delete choose;
	delete[]buffer;
	delete str;
	delete length;
	return 0;
}
void eatspace(char *buffer) {
	int *i = new int(0);
	int *j = new int(0);
	while ((*(buffer + *j) = *(buffer + *i)) != '\0') {//�������̫�N\0��J�A�G�᭱���ȳ������F
		if (*(buffer + *j) != ' ')
			*j += 1;
		*i += 1;
	}

	delete i;
	delete j;
}
double expr(char *buffer) {
	double *value = new double(0);
	int *index = new int(0);
	double *temp = new double(0);
	value = term(buffer, index);
	//cout << *value;
	while (true) {
		//cout << *value;
		if (*(buffer + *index) == '+') {
			*index += 1;
			temp = term(buffer, index);
			*value += *temp;
		}
		else if (*(buffer + *index) == '-') {
			*index += 1;
			temp = term(buffer, index);
			*value -= *temp;
		}
		else if (*(buffer + *index) == '\0')
			return *value;
		else if (*(buffer + *index) == '+' || *(buffer + *index) == '-' || *(buffer + *index) != '\0') {
			cout << "�⦡�����~" << endl;
			exit(1);
		}

	}
	delete index;
	delete value;
}
double* term(char*buffer, int *index) {
	double *value = new double(0);
	double *temp = new double(0);
	value = number(buffer, index);
	while (true) {
		if (*(buffer + *index) == '*') {
			*index += 1;
			temp = number(buffer, index);
			*value *= *temp;
		}
		else if (*(buffer + *index) == '/') {
			*index += 1;
			temp = number(buffer, index);
			*value /= *temp;
		}
		else if (*(buffer + *index) == '%') {
			*index += 1;
			temp = number(buffer, index);
			if ((*value - (int)*value) > 0 || (*temp - (int)*temp) > 0) {
				cout << "���~�A���p�ƵL�k���l��" << endl;
				exit(1);
			}
			*value = (int)*value % (int)*temp;
		}
		else
			break;
	}
	delete temp;
	return value;
}
double* number(char*buffer, int *index) {
	double *value = new double(0);
	value = multioperator(buffer, index);
	if (*value != 0)
		return value;
	if (!isdigit(*(buffer + *index))) {
		cout << "���B�⦡�O���~��" << endl;
		exit(1);
	}
	while (isdigit(*(buffer + *index))) {
		*value = *value * 10 + (*(buffer + *index) - '0');
		*index += 1;
	}
	if (*(buffer + *index) != '.') {
		int *f = new int(0);
		getvalue(buffer, index, value, f);
		delete f;
		return value;
	}
	double *factor = new double(1.0);
	*index += 1;
	while (isdigit(*(buffer + *index))) {
		*factor *= 0.1;
		*value = *value + (*(buffer + *index) - '0')**factor;
		*index += 1;
	}
	int *f = new int(1);
	getvalue(buffer, index, value, f);
	delete f;
	delete factor;
	return value;
}
double* getvalue(char *buffer, int *index, double *value, int *f) {
	if (*(buffer + *index) == '\0')
		return value;
	while (true) {
		if (*(buffer + *index) == '+'&&*(buffer + *index + 1) == '+') {
			*index += 2;
			*value += 1;
		}
		else if (*(buffer + *index) == '-'&&*(buffer + *index + 1) == '-') {
			*index += 2;
			*value -= 1;
		}
		else if (*(buffer + *index) == '^') {
			*index += 1;
			double *temp = new double(0);
			temp = number(buffer, index);
			*value = pow(*value, *temp);
			delete temp;
		}
		else if (*(buffer + *index) == '!'&&*f == 0) {
			*index += 1;
			if (*value == 1 || *value == 0)
				*value = 1;
			else {
				int *i = new int(0);
				int *tempvalue = new int(1);
				for (*i = 1; *i <= *value; *i += 1)
					*tempvalue *= *i;
				*value = *tempvalue;
				delete tempvalue;
				delete i;
			}
		}
		else if (*(buffer + *index) == '!'&&*f == 1) {
			cout << "�p���I�L�k�i�涥�h�B��" << endl;
			exit(1);
		}
		else if (*(buffer + *index) == '\0' || *(buffer + *index) == '%' || *(buffer + *index) == '/' || *(buffer + *index) == '*' || isdigit(*(buffer + *index)) == 1 || (*(buffer + *index) == '+'&&*(buffer + *index + 1) != '+') || (*(buffer + *index) == '-'&&*(buffer + *index + 1) != '-'))
			break;
	}
	return value;
}
double* multioperator(char *buffer, int *index) {
	double *value = new double(0);
	char *startbracket = new char;
	char *endbracket = new char;
	char* nbuffer(nullptr);
	if (*(buffer + *index) == '(') {
		*startbracket = '(';
		*endbracket = ')';
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == '[') {
		*startbracket = '[';
		*endbracket = ']';
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == '{') {
		*startbracket = '{';
		*endbracket = '}';
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'e'&&*(buffer + *index + 1) == 'x'&&*(buffer + *index + 2) == 'p') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = exp(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 's'&&*(buffer + *index + 1) == 'i'&&*(buffer + *index + 2) == 'n') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = sin(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'c'&&*(buffer + *index + 1) == 'o'&&*(buffer + *index + 2) == 's') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = cos(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 't'&&*(buffer + *index + 1) == 'a'&&*(buffer + *index + 2) == 'n') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = tan(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'c'&&*(buffer + *index + 1) == 'o'&&*(buffer + *index + 2) == 't') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = 1 / tan(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 's'&&*(buffer + *index + 1) == 'e'&&*(buffer + *index + 2) == 'c') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = 1 / cos(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'c'&&*(buffer + *index + 1) == 's'&&*(buffer + *index + 2) == 'c') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = 1 / sin(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 's'&&*(buffer + *index + 1) == 'q'&&*(buffer + *index + 2) == 'r'&&*(buffer + *index + 3) == 't') {
		*index += 4;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = sqrt(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'l'&&*(buffer + *index + 1) == 'o'&&*(buffer + *index + 2) == 'g'&&*(buffer + *index + 3) == '1'&&*(buffer + *index + 4) == '0') {
		*index += 5;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = log10(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'l'&&*(buffer + *index + 1) == 'o'&&*(buffer + *index + 2) == 'g') {
		*index += 3;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = log10(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	else if (*(buffer + *index) == 'l'&&*(buffer + *index + 1) == 'n') {
		*index += 2;
		checkbracket(buffer, index, startbracket, endbracket);
		nbuffer = extract(buffer, index, startbracket, endbracket);
		*value = expr(nbuffer);
		*value = log(*value);
		delete[]nbuffer;
		delete startbracket;
		delete endbracket;
		return value;
	}
	return value;
}
void checkbracket(char *buffer, int *index, char *startbracket, char *endbracket) {
	if (*(buffer + *index) == '(') {
		*startbracket = '(';
		*endbracket = ')';
	}
	else if (*(buffer + *index) == '[') {
		*startbracket = '[';
		*endbracket = ']';
	}
	else if (*(buffer + *index) == '{') {
		*startbracket = '{';
		*endbracket = '}';
	}
}
char* extract(char *buffer, int *index, char *startbracket, char *endbracket) {
	*index += 1;
	char *nbuffer = new char[80];
	char* pstr(nullptr);
	int *count = new int(0);
	int *bufindex = new int(*index);
	do {
		*(nbuffer + (*index - *bufindex)) = *(buffer + *index);
		if (*(buffer + *index) == *startbracket)
			*count += 1;
		else if (*(buffer + *index) == *endbracket) {
			if (*count == 0)
			{
				int *size = new int(0);
				*size = *index - *bufindex;
				*size += 1;
				*(nbuffer + (*index - *bufindex)) = '\0';
				*index += 1;
				pstr = new char[*size];
				strcpy_s(pstr, *size,nbuffer); // Copy substring to new memory
				delete count;
				delete size;
				return pstr;
			}
			else
				*count -= 1;
		}
		*index += 1;

	} while (*(buffer + *index) != '\0');
	cout << "�����~" << endl;
	delete count;
	exit(1);
}
