// ConsoleApplication1.cpp : �w�q�D���x���ε{�����i�J�I�C
//
/********
4105056019 �\���� �ĥ|���@�~11/16
*********/
#include "stdafx.h"
#include<string>
#include<fstream>
#include<iostream>
#include <iomanip>
#include <Windows.h>
using namespace std;
class Clandproperty {
public:
	int *house = new int(0);
	int *buy = new int(-1);
	int *landprice = new int(0);
};
class Crole {
public:
	int *position = new int(0);
	int *money = new int(0);
	int *jailcount = new int(0);
	string *rolesign = new string;
	string *name = new string;
	string *tempevent = new string;
};
class Cdefault {
public :
	string *land = new string;
	string *initialland = new string;
};
class Cstock {
public:
	string *name = new string;
	int *initprice = new int(0);
	int *price = new int(0);
	int *buy = new int[4]{0,0,0,0};
};
class Cfunction {
public:
	Clandproperty *landpy = new Clandproperty[40];
	Crole *role = new Crole[4];
	Cdefault *def = new Cdefault[40];
	Cstock *company = new Cstock[10];
	int *controln = new int(0);
	int *dice = new int(0);
	int *turn = new int(0);
	int *playern = new int(4);
	void start() {
		*(role[0].rolesign) = "*"; *(role[1].rolesign) = "+"; *(role[2].rolesign) = "-"; *(role[3].rolesign) = "/";
		*(role[0].money) = 25000; *(role[1].money) = 25000; *(role[2].money) = 25000; *(role[3].money) = 25000;
		*(role[0].name) = "1"; *(role[1].name) = "2"; *(role[2].name) = "3"; *(role[3].name) = "4";
		char *choose = new char[80];
		int *length = new int(0);
		int *eventn = new int(0);
		string *option = new string;
		int *num = new int(0);
		int *nofound = new int(0);
		cout << "�j�I�ιC��" << endl;
		cout << "�q����l���B��25000���A���a�i�ۦ�]�w��l���B�ΦW��" << endl;
		cout << "�ϧθѻ�:" << endl;
		cout << "1�����a :*  2�����a:+  3�����a:-  4�����a:/ " << endl;
		cout << "�Фl:�b�g�a��H�Ʀr�Щ�1~4�Cex : ���ƿ�1�A�N�����ƿ����@�ɩФl�A���]�h�O ^ ex : ���ƿ�^" << endl;
		cout << "�Y�h�H�b�P�@���g�a�W�ȷ|��ܤ@�H���аO�Aex: * �M + �P�ɦb���ƿ��A���ƿ�1*�A��*���}�A��ܹ��ƿ�1+" << endl;
		cout << "�ѥ��ѻ�:" << endl;
		cout << "�����a�g�L�@��ɡA���ɤ~��i��ѥ����" << endl;
		cout << endl;
		initstock();
		while (true) {
			cout << "���J���e���C���Ы�0�A���s�}�l�Ы�1" << endl;
			getline(cin, *option, '\n');
			if (*option == "0") {
				initialload();
				nofound = load(option);
				if (*nofound == 0)
					break;
			}
			else if (*option == "1") {
				initialload();
				load(option);
				while (true)
				{
					cout << "�п�J���a���ƶq2~4" << endl;
					cin.getline(choose, 80, '\n');
					length = checkecharlength(choose);
					if (*length == 1) {
						if (*(choose + 0) > '4' || *(choose + 0) < '2')
							continue;
						else {
							*playern = *(choose + 0) - '0';
							break;
						}
					}
				}
				while (true)
				{
					cout << "�п�J�n����L�ޱ������a���ƶq1~" << *playern << endl;
					cin.getline(choose, 80, '\n');
					length = checkecharlength(choose);
					if (*length == 1) {
						if ((*(choose + 0) - '0') > *playern || (*(choose + 0) - '0') < 1)
							continue;
						else {
							*controln = *(choose + 0) - '0';
							break;
						}
					}
				}
				int *i = new int(0);
				while (*i < *controln) {
					cout << "�п�J" << (*i + 1) << "�����a�W��(�̤�2�Ӧr)" << endl;
					getline(cin, *option, '\n');
					if (option->length() >= 2) {
						int *j = new int(0);
						for(*j = 0; *j < *i; *j += 1) {
							if (*(role[*j].name) == *option) {
								cout << "�w�g���H���L�o�ӦW�r�A�д��@��" << endl;
								*j = -1;
								break;
							}
						}
						if (*j == -1)
							continue;
						*(role[*i].name) = *option;
						*i += 1;
						delete j;
					}
				}
				*i = 0;
				int *money = new int(0);
				while (*i < *controln) {
					cout << "�п�J" << (*i + 1) << "�����a��l���B(�j��0)�A���঳�B�I�ơA��Ƴ̦h��9���)" << endl;
					cin.getline(choose, 80, '\n');
					money = chartonumber(choose);
					*(role[*i].money) = *money;
					if (*(role[*i].money) <= 0)
						continue;
					else
						*i += 1;
				}
				*i = 0;
				while (*i < *controln) {
					buystock();
					*turn += 1;
					*i += 1;
				}
				*turn = 0;
				delete money, i;
				break;
			}
		}
		location(num);
		map();
		while (true) {
			if (*turn >= *playern) {
				*turn = 0;
				if (*controln != *playern) {
					map();
					int *i = new int(0);
					for (*i = *controln; *i < *playern; *i += 1) {
						cout << *(role[*i].tempevent) << endl;
					}checkenter();
				}
			}
			if (*(role[*turn].jailcount) > 0) {
				*num = 1;
				if (*turn<*controln) {
					cout << (*turn + 1) << "�����a���Y��" << endl;
					checkenter();
					rolldice();
				}
				else
					rolldice();
				*(role[*turn].jailcount) -= 1;
				if (*(role[*turn].jailcount) == 0 && *turn<*controln)
					cout << "�X��" << endl;
				else if (*turn < *controln)
					cout << "�٦�" << *(role[*turn].jailcount) << "�^�X" << endl;
				if (*turn < *controln) {
					checkenter();
					map();
				}
				else
					*(role[*turn].tempevent) = to_string((*turn + 1)) + "�����a���c��";
				*turn += 1;
				continue;
			}
			if (*turn < *controln) {
				cout << (*turn + 1) << "�����a�Y��l��J:y�A�s�ɿ�J:s�A���v����:h�A���}��J:q" << endl;
				getline(cin, *option, '\n');
				if (*option == "y") {
					rolldice();
					*num = 0;
					location(num);
					map();
					eventn = landevent();
					if (*eventn == 1)
						break;
					if (*eventn == 2)
						*(role[*turn].jailcount) = 3;
					*num = 1;
					location(num);
					map();
					*turn += 1;
				}
				else if (*option == "q")
					break;
				else if (*option == "s") {
					store();
					cout << "�s�ɧ���" << endl;
				}
				else if (*option == "h")
					showevent();
			}
			else {
				rolldice();
				*num = 0;
				location(num);
				eventn = otherlandevent();//0:�L�� 1:�ۤv��F 2:�i�ʺ� 3:�q����F
				if (*eventn == 3)
					break;
				if (*eventn == 2)
					*(role[*turn].jailcount) = 3;
				*num = 1;
				location(num);
				*turn += 1;
			}
			*eventn = 0;
		}
		if (*eventn == 3 || *eventn == 1) {
			*turn += 1;
			map();
			cout << *turn << "�����a��F";
			string *eventline = new string;
			*eventline = to_string(*turn) + "�����a��F";
			storeevent(eventline);
			delete eventline;
		}
		delete[]choose, length, eventn, option, num, nofound;
		delete[]landpy; delete[]role; delete[]def; delete[]company, controln, dice, turn; delete[]playern;
	}
	void initstock() {
		int *i = new int(0);
		for (*i = 0; *i < 10; *i += 1) {
			*(company[*i].name) = "���q" + to_string(*i);
		}
		for (*i = 0; *i < 10; *i += 1) {
			*(company[*i].initprice) = *i * 1000 + 1000;
			*(company[*i].price) = *(company[*i].initprice);
		}
		delete i;
	}
	void sellstockc() {
		int *i = new int(0);
		for (*i = 0; *i < 10; *i += 1) {
			if ((company[*i].buy[*turn]) != 0) {
				if (*(company[*i].price) >(1.2)**(company[*i].initprice)) {
					*(role[*turn].money) += (company[*i].buy[*turn])**(company[*i].price);
					(company[*i].buy[*turn]) = 0;
				}
			}
		}
		if (*(role[*turn].money) < 4000) {
			for (*i = 0; *i < 10; *i += 1) {
				if ((company[*i].buy[*turn]) != 0) {
					*(role[*turn].money) += (company[*i].buy[*turn])**(company[*i].price);
					(company[*i].buy[*turn]) = 0;
					if (*(role[*turn].money) >= 4000) {
						*(role[*turn].tempevent) = " ��X" + *(company[*i].name) + "���Ѳ�";
						cout << (*turn + 1) << "�����a��X" << *(company[*i].name) << "���Ѳ�" << endl;
						break;
					}
				}
			}
		}
		delete i;
	}
	void buystockc() {
		int *i = new int(0);
		int *difference = new int(0);
		*difference = *(role[*turn].money) - 16000;
		*difference /= 2;
		for (*i = 9; *i >= 0; *i -= 1) {
			if (*difference >= *(company[*i].price)) {
				(company[*i].buy[*turn]) += 1;
				*(role[*turn].money) -= *(company[*i].price);
				*(role[*turn].tempevent) = " �R�U" + *(company[*i].name) + "���Ѳ�";
				cout << (*turn + 1) << "�����a�R�U" << *(company[*i].name) << "���Ѳ�" << endl;
				break;
			}
		}
		delete i, difference;
	}
	void sellstock() {
		system("CLS");
		int *i = new int(0);
		for (*i = 0; *i < 10; *i += 1) {
			cout << "���q�W��: " << *(company[*i].name) << " �@�i�Ѳ�����: " << *(company[*i].price) << endl;
		}
		cout << "�ثe�Ҿ֦����Ѳ�" << endl;
		for (*i = 0; *i < 10; *i += 1) {
			if ((company[*i].buy[*turn]) != 0)
				cout << *(company[*i].name) << ": " << (company[*i].buy[*turn]) << "�i " << endl;
		}
		string *choose = new string;
		char *num = new char[80];
		int *n = new int(0);
		string *line = new string;
		while (true) {
			cout << (*turn + 1) << "�����a�п�J�Q�c�⪺�Ѳ������q�W�١Aex:���q0�B���q1�A���}�Ы�q" << endl;
			cout << "���a�ثe�֦�������: " << *(role[*turn].money) << endl;
			getline(cin, *choose, '\n');
			if (*choose == "q")
				break;
			for (*i = 0; *i < 10; *i += 1) {
				if (*(company[*i].name) == *choose && (company[*i].buy[*turn]) != 0) {
					while (true) {
						cout << "�п�J�Q�c�⪺�i�ơA���}�Ы�q" << endl;
						cin.getline(num, 80, '\n');
						n = checkecharlength(num);
						if (*n == 1) {
							if (*num == 'q')
								break;
						}
						n = chartonumber(num);
						if ((company[*i].buy[*turn]) >= *n) {
							*(role[*turn].money) += *(company[*i].price)*(*n);
							(company[*i].buy[*turn]) -= (*n);
							cout << "���a�ثe�֦�������: " << *(role[*turn].money) << endl;
							*line = "��X" + *(company[*i].name) + "���Ѳ�";
							storeevent(line);
						}
						else if (*n>(company[*i].buy[*turn]))
							cout << "�õL����h�i�Ѳ�" << endl;
					}
					break;
				}
			}
		}
		delete i, choose, line, num, n;
	}
	void buystock() {
		system("CLS");
		int *i = new int(0);
		for (*i = 0; *i < 10; *i += 1) {
			cout << "���q�W��: " << *(company[*i].name) << " �@�i�Ѳ�����: " << *(company[*i].price) << endl;
		}
		string *choose = new string;
		string *line = new string;
		char *num = new char[80];
		int *n = new int(0);
		while (true) {
			cout << (*turn + 1) << "�����a�п�J�Q�ʶR�Ѳ������q�W�١Aex:���q0�B���q1�A���}�Ы�q" << endl;
			cout << "���a�ثe�֦�������: " << *(role[*turn].money) << endl;
			getline(cin, *choose, '\n');
			if (*choose == "q")
				break;
			for (*i = 0; *i < 10; *i += 1) {
				if (*(company[*i].name) == *choose) {
					while (true) {
						cout << "�п�J�Q�ʶR���i�ơA���}�Ы�q" << endl;
						cin.getline(num, 80, '\n');
						n = checkecharlength(num);
						if (*n == 1) {
							if (*num == 'q')
								break;
						}
						n = chartonumber(num);
						if (*(role[*turn].money) >= *(company[*i].price)*(*n)) {
							*(role[*turn].money) -= *(company[*i].price)*(*n);
							cout << "���a�ثe�Ѿl������: " << *(role[*turn].money) << endl;
							company[*i].buy[*turn] += *n;
							*line = "�ʶR" + *(company[*i].name) + "���Ѳ�";
							storeevent(line);
						}
						else
							cout << "���W���������L�k�i���ʶR" << endl;
					}
					break;
				}
			}
		}
		delete i, choose, line, num, n;
	}
	void stockmarket(int *num, string *line) {
		if (*num == 8) {
			cout << "�ѩ�" << (*turn + 1) << "�����a���" << *line << "�y���ѥ��j��" << endl;
			*line = "���" + *line + "�y���ѥ��j��";
			storeevent(line);
			int *i = new int(0);
			for (*i = 0; *i < 10; *i += 1) {
				*(company[*i].price) *= 1.1;
				cout << "���q�W��: " << *(company[*i].name) << " �@�i�Ѳ�����: " << *(company[*i].price) << endl;
			}
			if (*turn >= *controln)
				checkenter();
			delete i;
		}
		else if (*num == 9) {
			cout << "�ѩ�" << (*turn + 1) << "�����a���" << *line << "�A�M�Ӫѥ����j�^" << endl;
			*line = "���" + *line + "�y���ѥ��j�^";
			storeevent(line);
			int *i = new int(0);
			for (*i = 0; *i < 10; *i += 1) {
				*(company[*i].price) *= 0.9;
				cout << "���q�W��: " << *(company[*i].name) << " �@�i�Ѳ�����: " << *(company[*i].price) << endl;
			}
			if (*turn >= *controln)
				checkenter();
			delete i;
		}
		else {
			srand((unsigned)time(NULL));
			int *pred = new int(0);
			double *percent = new double(0);
			int *add = new int(0);
			int *i = new int(0);
			for (*i = 0; *i < 10; *i += 1) {
				*pred = rand() % 2;
				*percent = rand() % 3;
				*add = rand() % 2;
				if (*pred == 0)
					*(company[*i].price) *= (1 - *percent / 100 - *add / 100);
				else if (*pred == 1)
					*(company[*i].price) *= (1 + *percent / 100 + *add / 100);
			}
			delete i, pred, percent, add;
		}

	}
	void showevent() {
		string *line = new string;
		fstream *ifilerec = new fstream("����.txt", ios::in);
		while (!ifilerec->eof()) {
			getline(*ifilerec, *line, '\n');
			cout << *line << endl;
		}
		ifilerec->close();
		delete line, ifilerec;
	}
	void store() {
		int *i = new int(0);
		fstream * pos = new fstream("position.txt", ios::out);
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				*pos << *(role[*i].position);
			else
				*pos << *(role[*i].position) << endl;
		}
		pos->close();
		fstream * jail = new fstream("jail.txt", ios::out);
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				*pos << *(role[*i].jailcount);
			else
				*pos << *(role[*i].jailcount) << endl;
		}
		pos->close();
		fstream* mon = new fstream("money.txt", ios::out);
		for (*i = 0; *i < *playern; *i += 1) {
			if (*i == *playern - 1)
				*mon << *(role[*i].money);
			else
				*mon << *(role[*i].money) << endl;
		}
		mon->close();
		fstream* by = new fstream("buy.txt", ios::out);
		for (*i = 0; *i < 40; *i += 1) {
			if (*i == 39)
				*by << *(landpy[*i].buy);
			else
				*by << *(landpy[*i].buy) << endl;
		}
		by->close();
		fstream *hou = new fstream("house.txt", ios::out);
		for (*i = 0; *i < 40; *i += 1) {
			if (*i == 39)
				*hou << *(landpy[*i].house);
			else
				*hou << *(landpy[*i].house) << endl;
		}
		hou->close();
		fstream *lan = new fstream("land.txt", ios::out);
		for (*i = 0; *i < 40; *i += 1) {
			if (*i == 39)
				*lan << *(def[*i].land);
			else
				*lan << *(def[*i].land) << endl;
		}
		lan->close();
		fstream *stockp = new fstream("stockprice.txt", ios::out);
		for (*i = 0; *i < 10; *i += 1) {
			if (*i == 9)
				*stockp << *(company[*i].price);
			else
				*stockp << *(company[*i].price) << endl;
		}
		stockp->close();
		int *k = new int(0);
		fstream *stockb = new fstream("stockbuy.txt", ios::out);
		for (*i = 0; *i < 10; *i += 1) {
			for (*k = 0; *k < 4; *k += 1) {
				if (*i == 9 && *k == 3) {
					*stockb << (company[*i].buy[*k]);
					break;
				}
				*stockb << (company[*i].buy[*k]) << endl;
			}

		}
		stockb->close();
		fstream *infor = new fstream("infor.txt", ios::out);
		*infor << *playern << endl;
		*infor << *controln << endl;
		*infor << *turn << endl;
		for (*i = 0; *i < *controln; *i += 1) {
			if (*i == (*controln - 1))
				*infor << *(role[*i].name);
			else
				*infor << *(role[*i].name) << endl;
		}
		infor->close();
		delete  i, pos, jail, hou, infor, stockb, stockp, mon, lan, by;
	}
	void initialload() {
		int *i = new int(0);
		string *line = new string;
		char *intline = new char[80];
		int *intnum = new int(0);
		fstream *ifilelandprice = new fstream("��l�ƻ���.txt", ios::in);
		while (ifilelandprice->getline(intline, 80, '\n')) {
			intnum = chartonumber(intline);
			*(landpy[*i].landprice) = *intnum;
			*i += 1;
		}
		ifilelandprice->close();
		*i = 0;
		fstream *ifileland = new fstream("��l�Ƥg�a.txt", ios::in);
		while (!ifileland->eof()) {
			getline(*ifileland, *(def[*i].initialland), '\n');
			*i += 1;
		}
		ifileland->close();
		delete i, line, intline, intnum, ifilelandprice, ifileland;
	}
	int* load(string *chose) {
		int *i = new int(0);
		int *nofound = new int(0);
		if (*chose == "0") {
			ifstream *ifileland = new ifstream("land.txt", ios::in);
			if (ifileland->is_open()) {
				while (!ifileland->eof()) {
					getline(*ifileland, *(def[*i].land), '\n');
					*i += 1;
				}
				ifileland->close();
				*i = 0;
				ifstream *ifilelandbuy = new ifstream("buy.txt", ios::in);
				char *price = new char[80];
				int *cash = new int(0);
				while (ifilelandbuy->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(landpy[*i].buy) = *cash;
					*i += 1;
				}
				ifilelandbuy->close();
				*i = 0;
				ifstream *ifilehouse = new ifstream("house.txt", ios::in);
				while (ifilehouse->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(landpy[*i].house) = *cash;
					*i += 1;
				}
				ifilehouse->close();
				*i = 0;
				ifstream *ifilemoney = new ifstream("money.txt", ios::in);
				while (ifilemoney->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(role[*i].money) = *cash;
					*i += 1;
				}
				ifilemoney->close();
				*i = 0;
				ifstream *ifilepos = new ifstream("position.txt", ios::in);
				while (ifilepos->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(role[*i].position) = *cash;
					*i += 1;
				}
				ifilepos->close();
				*i = 0;
				ifstream *ifilejail = new ifstream("jail.txt", ios::in);
				while (ifilejail->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(role[*i].jailcount) = *cash;
					*i += 1;
				}
				ifilejail->close();
				*i = 0;
				int *k = new int(0);
				fstream *stockp = new fstream("stockprice.txt", ios::in);
				while (stockp->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					*(company[*i].price) = *cash;
					*i += 1;
				}
				stockp->close();
				*i = 0;
				fstream *stockb = new fstream("stockbuy.txt", ios::in);
				while (stockb->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					(company[*i].buy[*k]) = *cash;
					*k += 1;
					if (*k > 3) {
						*i += 1;
						*k = 0;
					}
					//		cout << endl;
					//	cout << *k << endl;
				}
				stockb->close();
				*k = 0;
				*i = 0;
				ifstream *ifileinfor = new ifstream("infor.txt", ios::in);
				while (ifileinfor->getline(price, 80, '\n')) {
					cash = chartonumber(price);
					if (*i == 0)
						*playern = *cash;
					else if (*i == 1)
						*controln = *cash;
					else if (*i == 2) {
						*turn = *cash;
						break;
					}
					*i += 1;
				}
				ifileinfor->close();
				*i = 0;
				string *name = new string;
				ifstream *ifileinfor2 = new ifstream("infor.txt", ios::in);
				while (!ifileinfor2->eof()) {
					getline(*ifileinfor2, *name, '\n');
					if (*i > 2) {
						*(role[*k].name) = *name;
						*k += 1;
					}
					*i += 1;
				}
				ifileinfor2->close();
				delete price, cash, ifileinfor, ifileinfor2, ifilehouse, ifileland, ifilelandbuy, ifilepos, ifilemoney, ifilejail;
				//	ifilekey2 = NULL; ifilekey1 = NULL; ifilehouse = NULL; ifileland = NULL; ifilelandbuy = NULL; price = NULL; cash = NULL;
			}
			else {
				cout << "�d�L����" << endl;
				*nofound = 1;
				return nofound;
			}

		}
		else if (*chose == "1") {
			ifstream *ifileland = new ifstream("��l�Ƥg�a.txt", ios::in);
			while (!ifileland->eof()) {
				getline(*ifileland, *(def[*i].land), '\n');
				*i += 1;
			}
			ifileland->close();
			remove("stockprice.txt");
			remove("stockbuy.txt");
			remove("land.txt");
			remove("buy.txt");
			remove("house.txt");
			remove("infor.txt");
			remove("money.txt");
			remove("position.txt");
			remove("jail.txt");
			delete ifileland;
			//	ifileland = NULL;
		}
		delete i;
		return nofound;
	}
	void storeevent(string *line) {
		ofstream *affair = new ofstream("����.txt", ios::app);
		*affair << *line << endl;
		*affair << " ";
		affair->close();
		if (*turn >= *controln)
			*(role[*turn].tempevent) = *line;
		delete affair;
	}
	void checkenter() {
		string *enter = new string;
		cout << "�п�Jenter���ܽT�{" << endl;
		getline(cin, *enter, '\n');
		delete enter;
	}
	void rolldice() {
		*dice = 0;
		if (*turn >= *controln)
			Sleep(500);
		srand((unsigned)time(NULL));
		*dice = rand() % 6 + 1;
		*dice += rand() % 6 + 1;
		//*dice = 11;
		if (*turn < *controln) {
			cout << "��l�Ʀr��: " << *dice << endl;
			checkenter();
		}

	}
	int* otherlandevent() {
		string* choose = new string;
		string *eventline = new string;
		int *mustsell = new int(0);
		int *paidok = new int(0);
		int *eventn = new int(0);
		if (*(role[*turn].position) != 2 && *(role[*turn].position) != 5 && *(role[*turn].position) != 12 && *(role[*turn].position) != 15 && *(role[*turn].position) != 25 && *(role[*turn].position) != 28 && *(role[*turn].position) != 35 && *(role[*turn].position) != 38)
		{
			if (*(landpy[*(role[*turn].position)].landprice) != -1 && *(role[*turn].position) != 0) {
				if (*(landpy[*(role[*turn].position)].buy) == -1) {
					while (true)
					{
						//cout<<"��F{0}", initialland[position[*turn]]);
						*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland);
						storeevent(eventline);
						if (*(role[*turn].money) >= *(landpy[*(role[*turn].position)].landprice)) {
							*(role[*turn].money) -= *(landpy[*(role[*turn].position)].landprice);
							*(landpy[*(role[*turn].position)].buy) = *turn;
							//	cout << "�ʶR���\" << endl;
							*eventline += "�ʶR���\";
							storeevent(eventline);
						}
						else {
							//	cout<<"���ʶR");
							*eventline += "���ʶR";
							storeevent(eventline);
						}
						break;
					}
				}
				else if (*(landpy[*(role[*turn].position)].buy) == *turn) {
					int *houseprice = new int(0);
					if (*(landpy[*(role[*turn].position)].house) <= 4) {
						if (*(landpy[*(role[*turn].position)].landprice)< 3000)
							*houseprice = 1000;
						else
							*houseprice = 2000;
						if (*(role[*turn].money) >= *houseprice) {
							*(role[*turn].money) -= *houseprice;
							*(landpy[*(role[*turn].position)].house) += 1;
							if (*(landpy[*(role[*turn].position)].house) < 4) {
								*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + to_string(*(landpy[*(role[*turn].position)].house));
							}
							else if (*(landpy[*(role[*turn].position)].house) == 5) {
								*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + "^";
							}
							//	cout<<"�\�Ц��\");
							*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland) + "�\�Ц��\";
							storeevent(eventline);
						}
						else {
							//cout<<"���\��");
							*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland) + "���\��";
							storeevent(eventline);
						}
					}
					else {
						//cout<<"�w�g�L�k�A�\�Фl");
						*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland) + "�w�L�k�A�\�Фl�F";
						storeevent(eventline);
					}
				}
				else {
					eventn = anotherland();
					return eventn;
				}

			}
			else {
				if (*(def[*(role[*turn].position)].initialland) == "  ���c") {
					//	Console::WriteLine("��F{0}", initialland[position[*turn]]);
					*eventline = to_string((*turn + 1)) + "�����a��F���c";
					storeevent(eventline);
					eventn = gotojail();
					return eventn;
				}
				else if (*(def[*(role[*turn].position)].initialland) == "  ���|") {
					int *chfa = new int(1);
					card(chfa);
					*eventline = to_string((*turn + 1)) + "�����a��F���|";
					storeevent(eventline);
				}
				else if (*(def[*(role[*turn].position)].initialland) == "  �R�B") {
					int *chfa = new int(0);
					card(chfa);
					*eventline = to_string((*turn + 1)) + "�����a��F�R�B";
					storeevent(eventline);
				}
				else {
					//	Console::WriteLine("��F{0}", initialland[position[*turn]]);
					*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland);
					storeevent(eventline);
				}

			}
		}
		else {
			//Console::WriteLine("��F{0}�A��ú��{1}��", initialland[position[*turn]], landprice[position[*turn]]);
			*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland);
			storeevent(eventline);
			if (*(role[*turn].money) <*(landpy[*(role[*turn].position)].landprice)) {
				eventn = checkasset((landpy[*(role[*turn].position)].landprice));
				if (*eventn == 1) {
					*eventn = 3;
					return eventn;
				}
				othersell((landpy[*(role[*turn].position)].landprice));
				*eventline = *eventline + "�wú��" + to_string(*(landpy[*(role[*turn].position)].landprice)) + "��";
				storeevent(eventline);
			}
			else {
				*(role[*turn].money) -= *(landpy[*(role[*turn].position)].landprice);
				*eventline = *eventline + "�wú��" + to_string(*(landpy[*(role[*turn].position)].landprice)) + "��";
				storeevent(eventline);
			}

		}
		delete choose, eventline, mustsell, paidok;
		return eventn;
	}
	void othersell(int *price) {
		int *i = new int(0);
		int *ok = new int(0);
		for (*i = 0; *i <= 39; *i += 1) {
			if (*(landpy[*i].buy) == *turn&&*(landpy[*i].landprice) >= 3000 && *(landpy[*i].house) >0) {
				while (*(landpy[*i].house)> 0) {
					*(landpy[*i].house) -= 1;
					*(role[*turn].money) += 1000;
					if (*(role[*turn].money) > *price) {
						*ok = 1;
						break;
					}
				}
				if (*(landpy[*i].house) > 0)
					*(def[*i].land) = *(def[*i].initialland) + to_string(*(landpy[*i].house));
				else
					*(def[*i].land) = *(def[*i].initialland);
			}
			if (*ok == 1)
				break;
		}
		if (*ok == 0) {
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(landpy[*i].buy) == *turn && *(landpy[*i].house)>0) {
					while (*(landpy[*i].house)> 0) {
						*(landpy[*i].house) -= 1;
						*(role[*turn].money) += 500;
						if (*(role[*turn].money) > *price) {
							*ok = 1;
							break;
						}
					}
					if (*(landpy[*i].house)> 0)
						*(def[*i].land) = *(def[*i].initialland) + to_string(*(landpy[*i].house));
					else
						*(def[*i].land) = *(def[*i].initialland);
				}
				if (*ok == 1)
					break;
			}
		}
		if (*ok == 0) {
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(landpy[*i].buy) == *turn&& *(landpy[*i].landprice) >= 3000) {
					*(landpy[*i].buy) = -1;
					*(role[*turn].money) += *(landpy[*i].landprice) / 2;
					if (*(role[*turn].money) > *price) {
						*ok = 1;
						break;
					}
				}
			}
		}
		if (*ok == 0) {
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(landpy[*i].buy) == *turn) {
					*(landpy[*i].buy) = -1;
					*(role[*turn].money) += *(landpy[*i].landprice) / 2;
					if (*(role[*turn].money) > *price) {
						*ok = 1;
						break;
					}
				}
			}
		}
		//cout<<"�I�M");
		*(role[*turn].money) -= *price;
		delete i, ok;
	}
	int* anotherland() {
		int *owner = new int(*(landpy[*(role[*turn].position)].buy));
		int *passmoney = new int(0);
		int *mustsell = new int(1);
		int *eventn = new int(0);
		int *paidok = new int(0);
		string *eventline = new string;
		*eventline = to_string((*turn + 1)) + "�����a��F" + *(def[*(role[*turn].position)].initialland) + "�ݤ�I�L���O��" + to_string((*owner + 1)) + "�����a";
		storeevent(eventline);
		if (*(landpy[*(role[*turn].position)].house) > 0) {
			if (*(landpy[*(role[*turn].position)].house) == 1)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) / 2;
			else if (*(landpy[*(role[*turn].position)].house) == 2)
				*passmoney = *(landpy[*(role[*turn].position)].landprice);
			else if (*(landpy[*(role[*turn].position)].house) == 3)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) / 2 * 3;
			else if (*(landpy[*(role[*turn].position)].house) == 4)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) * 3;
			else if (*(landpy[*(role[*turn].position)].house) == 5)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) * 5;
		}
		else
			*passmoney = *(landpy[*(role[*turn].position)].landprice) / 10;
		if (*(role[*turn].money) >= *passmoney) {
			*(role[*turn].money) -= *passmoney;
			*(role[*owner].money) += *passmoney;
			//Console::WriteLine("�w��I");
			*eventline = *eventline + "�w��I" + to_string(*passmoney) + "���L���O";
			storeevent(eventline);
		}
		else {
			eventn = checkasset(passmoney);
			if (*eventn == 1) {
				*eventn = 3;
				return eventn;
			}
			othersell(passmoney);
			*(role[*owner].money) += *passmoney;
			*eventline = *eventline + "�w��I" + to_string(*passmoney) + "���L���O";
		}
		delete owner, passmoney, mustsell, eventline, paidok;
		return eventn;
	}
	int* landevent() {
		string *option = new string;
		string *eventline = new string;
		int *mustsell = new int(0);
		int *paidok = new int(0);
		int *eventn = new int(0);
		if (*(role[*turn].position) != 2 && *(role[*turn].position) != 5 && *(role[*turn].position) != 12 && *(role[*turn].position) != 15 && *(role[*turn].position) != 25 && *(role[*turn].position) != 28 && *(role[*turn].position) != 35 && *(role[*turn].position) != 38)
		{
			if (*(landpy[*(role[*turn].position)].landprice) != -1 && *(role[*turn].position) != 0) {
				if (*(landpy[*(role[*turn].position)].buy) == -1) {
					while (true)
					{
						cout << "��F" << *(def[*(role[*turn].position)].initialland) << "�O�_�n�R�U���g�a�A��J(y)���ܭn�A��J(n)���ܤ��n" << endl;
						*eventline = *(role[*turn].name) + "��F" + *(def[*(role[*turn].position)].initialland);
						storeevent(eventline);
						getline(cin, *option, '\n');
						if (*option == "y") {
							if (*(role[*turn].money)< *(landpy[*(role[*turn].position)].landprice)) {
								cout << "�ѩ���������ݶi����" << endl;
								paidok = sell((landpy[*(role[*turn].position)].landprice), mustsell);
								if (*paidok == 1) {
									*(landpy[*(role[*turn].position)].buy) = *turn;
									cout << "�ʶR���\" << endl;
									*eventline = "�ʶR���\";
									storeevent(eventline);
									checkenter();
								}
								*paidok = 0;
							}
							else {
								*(role[*turn].money) -= *(landpy[*(role[*turn].position)].landprice);
								*(landpy[*(role[*turn].position)].buy) = *turn;
								cout << "�ʶR���\" << endl;
								*eventline = "�ʶR���\";
								storeevent(eventline);
								checkenter();
							}
							break;
						}
						else if (*option == "n")
							break;
					}
				}
				else if (*(landpy[*(role[*turn].position)].buy) == *turn)
					build();
				else {
					eventn = otherland();
					return eventn;
				}
			}
			else {
				cout << "��F" << *(def[*(role[*turn].position)].initialland) << endl;
				if (*(def[*(role[*turn].position)].initialland) == "  ���c") {
					*eventline = *(role[*turn].name) + "��F���c";
					storeevent(eventline);
					eventn = gotojail();
					return eventn;
				}
				else if (*(def[*(role[*turn].position)].initialland) == "  ���|") {
					int *chfa = new int(1);
					card(chfa);
					*eventline = *(role[*turn].name) + "��F���|";
					storeevent(eventline);
				}
				else if (*(def[*(role[*turn].position)].initialland) == "  �R�B") {
					int *chfa = new int(0);
					card(chfa);
					*eventline = *(role[*turn].name) + "��F�R�B";
					storeevent(eventline);
				}
				else {
					*eventline = *(role[*turn].name) + "��F" + *(def[*(role[*turn].position)].initialland);
					storeevent(eventline);
				}
				checkenter();
			}
		}
		else {
			cout << "��F" << *(def[*(role[*turn].position)].initialland);
			cout << "�A��ú��" << *(landpy[*(role[*turn].position)].landprice) << "��" << endl;
			*eventline = *(role[*turn].name) + "��F" + *(def[*(role[*turn].position)].initialland);
			storeevent(eventline);
			checkenter();
			if (*(role[*turn].money)< *(landpy[*(role[*turn].position)].landprice)) {
				eventn = checkasset((landpy[*(role[*turn].position)].landprice));
				if (*eventn == 1)
					return eventn;
				*mustsell = 1;
				sell((landpy[*(role[*turn].position)].landprice), mustsell);
				cout << "�w�v��" << endl;
				checkenter();
			}
			else
				*(role[*turn].money) -= *(landpy[*(role[*turn].position)].landprice);
		}
		delete option, eventline, mustsell, paidok;
		return eventn;
	}
	int* otherland() {
		int *owner = new int(*(landpy[*(role[*turn].position)].buy));
		int *passmoney = new int(0);
		int *mustsell = new int(1);
		int *eventn = new int(0);
		int *paidok = new int(0);
		string *eventline = new string;
		cout << "��F" << *(def[*(role[*turn].position)].initialland) << "���g�a��" << *owner + 1 << "�����a�Ҧ��A�ݤ�I�L���O:";
		*eventline = *(role[*turn].name) + "��F" + *(def[*(role[*turn].position)].initialland) + "�ݤ�I�L���O��" + to_string((*owner + 1)) + "�����a";
		storeevent(eventline);
		if (*(landpy[*(role[*turn].position)].house) > 0) {
			if (*(landpy[*(role[*turn].position)].house) == 1)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) / 2;
			else if (*(landpy[*(role[*turn].position)].house) == 2)
				*passmoney = *(landpy[*(role[*turn].position)].landprice);
			else if (*(landpy[*(role[*turn].position)].house) == 3)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) / 2 * 3;
			else if (*(landpy[*(role[*turn].position)].house) == 4)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) * 3;
			else if (*(landpy[*(role[*turn].position)].house) == 5)
				*passmoney = *(landpy[*(role[*turn].position)].landprice) * 5;
		}
		else
			*passmoney = *(landpy[*(role[*turn].position)].landprice) / 10;
		cout << *passmoney << "��" << endl;
		checkenter();
		if (*(role[*turn].money) >= *passmoney) {
			*(role[*turn].money) -= *passmoney;
			*(role[*owner].money) += *passmoney;
			cout << "�w��I" << endl;
			*eventline = "�w��I" + to_string(*passmoney) + "���L���O";
			storeevent(eventline);
			checkenter();
		}
		else {
			eventn = checkasset(passmoney);
			if (*eventn == 1)
				return eventn;
			paidok = sell(passmoney, mustsell);
			*(role[*owner].money) += *passmoney;
			*eventline = "�w��I" + to_string(*passmoney) + "���L���O";
			storeevent(eventline);
		}
		delete owner, passmoney, mustsell, paidok, eventline;
		return eventn;
	}
	int* checkasset(int *price) {
		int *i = new int(0);
		int *asset = new int(0);
		int *eventn = new int(0);
		string *eventline = new string;
		for (*i = 0; *i <= 39; *i += 1) {
			if (*(landpy[*i].buy) == *turn) {
				if (*(landpy[*i].house) > 0) {
					if (*(landpy[*i].landprice) >= 3000)
						*asset += 1000 * *(landpy[*i].house);
					else
						*asset += 500 * *(landpy[*i].house);
				}
				*asset += *(landpy[*i].landprice) / 2;
			}
		}
		*asset += *(role[*turn].money);
		if (*asset < *price) {
			cout << "�ثe�]���`�B�p���ú����B�A�}��  �C������" << endl;
			*eventline = "�ثe�]���`�B�p���ú����B�A�}��  �C������";
			storeevent(eventline);
			checkenter();
			*eventn = 1;
			return eventn;
		}
		delete i, asset, eventline;
		return eventn;
	}
	void card(int *chfa) {
		int *num = new int(0);
		string *line = new string;
		int *cardcash = new int[10]{ 2000,1500,1000,2000,500,3000,1000,4000,5000,2000 };
		srand((unsigned)time(NULL));
		*num = rand() % 10;
		if (*chfa == 1) {
			string *cword = new string[10]{ "�B�ʸ����a�x","�Ȧ�I�A�Q��","�g��p���ͷN","���ͷN���\","�����B��","���U�ѤH","��{�}�n����","���ֳz","�ѥ�����j�n","�ѥ�����C�g�A�F���o���U��" };
			if (*turn<*controln)
				cout << "���" << cword[*num] << "�A�o��" << cardcash[*num] << "��" << endl;
			if (*num == 8 || *num == 9) {
				*line = cword[*num];
				stockmarket(num, line);
			}
			delete[]cword;
		}
		else {
			string *cword = new string[10]{ "����������","������ɱo�a�x","�u�@�V�O","�O�I�z��","�o��j�Ǽ��Ǫ�","�~�פ���","�a���ϧU��","�q�v���ɱo�a�x","���y�T������","���y�T���H�V�A�F������ɧU" };
			if (*turn<*controln)
				cout << "���" << cword[*num] << "�A�o��" << cardcash[*num] << "��" << endl;
			if (*num == 8 || *num == 9) {
				*line = cword[*num];
				stockmarket(num, line);
			}
			delete[]cword;
		}
		*(role[*turn].money) += cardcash[*num];
		delete[]cardcash, num, line;
	}
	int*  sell(int *price, int *mustsell) {
		int *i = new int(0);
		int *num = new int(0);
		string *choose = new string;
		int *paidok = new int(0);
		for (*i = 0; *i <= 39; *i += 1) {
			if (*(landpy[*i].buy) == *turn) {
				*num = 1;
				break;
			}
		}
		if (*num == 0) {
			cout << "�L����F�����i����" << endl;;
			checkenter();
			*paidok = 0;
			return paidok;
		}
		while (true)
		{
			cout << "�ѩ���������ݭn�i����A�ЫΡB�g�a���N����Ӫ��@�b" << endl;
			if (*mustsell == 1)
				cout << "���ﶵ:�Фl:1�B�g�a:2" << endl;
			else if (*mustsell == 0)
				cout << "���ﶵ:�Фl:1�B�g�a:2�B���}:q" << endl;
			getline(cin, *choose, '\n');
			if (*choose == "1") {
				sellhouse();
			}
			else if (*choose == "2")
			{
				sellland();
			}
			if (*mustsell == 0 && *choose == "q")
				break;
			if (*(role[*turn].money) >= *price) {
				cout << "�I�M" << endl;
				*(role[*turn].money) -= *price;
				*paidok = 1;
				break;
			}
		}
		delete i, num, choose;
		return paidok;
	}
	void sellhouse() {
		string *choose = new string;
		string *eventline = new string;
		char *c = new char[80];
		int *island = new int(0);
		int *i = new int(0);
		int *len = new int(0);
		while (true)
		{
			cout << "�п�J�Q�c��Фl���g�a�W�١A���}�Ы�q" << endl;
			getline(cin, *choose, '\n');
			if (*choose == "q")
				break;
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(def[*i].initialland) == *choose) {
					*island = 1;
					if (*(landpy[*i].buy) == *turn) {
						if (*(landpy[*i].house) > 0) {
							while (true) {
								cout << "�п�J�Q�c��Фl���ƶq�A���}�Ы�q" << endl;;
								cin.getline(c, 80, '\n');
								len = checkecharlength(c);
								if (*len == 1) {
									int *housenum = new int(0);
									if (*(c + 0) > '0'&&*(c + 0) < '9') {
										*housenum = *(c + 0) - '0';
										if (*housenum > *(landpy[*i].house))
											cout << "�Ыμƶq����" << endl;
										else if (*housenum > 0 && *housenum <= *(landpy[*i].house)) {
											cout << "�w�c��" << *housenum << "�ɩФl" << endl;
											*eventline = "�w�c���b" + *(def[*(role[*i].position)].initialland) + "��" + to_string(*housenum) + "�ɩФl";
											storeevent(eventline);
											*(landpy[*i].house) -= *housenum;
											if (*(landpy[*i].landprice) >= 3000)
												*(role[*turn].money) += *housenum * 1000;
											else
												*(role[*turn].money) += *housenum * 500;
											if (*(landpy[*i].house) > 0) {
												*(def[*i].land) = *(def[*i].initialland) + to_string(*(landpy[*i].house));
												//delete temp;
											}
											else if (*(landpy[*i].house) == 0)
												*(def[*i].land) = *(def[*i].initialland);
											int *num = new int(1);
											*dice = 0;
											location(num);
											map();
										}
										else if (*(landpy[*i].house) == 0)
											cout << "�L�c�����Фl" << endl;
									}
									else if (*(c + 0) == 'q')
										break;
								}
							}
						}
						else
							cout << "���g�a�õL�Фl" << endl;
					}
					else
						cout << "���g�a�ä��O�A�֦���" << endl;
					break;
				}
			}
			if (*island == 0)
				cout << "�L���g�a" << endl;
		}
		delete choose, eventline, c, island, i, len;
	}
	void sellland() {
		string *choose = new string;
		string *eventline = new string;
		int *island = new int(0);
		int *i = new int(0);
		while (true)
		{
			cout << "�п�J�Q�c�檺�g�a�W�١A���}�Ы�q" << endl;
			getline(cin, *choose, '\n');
			if (*choose == "q")
				break;
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(def[*i].initialland) == *choose) {
					*island = 1;
					if (*(landpy[*i].buy) == *turn) {
						if (*(landpy[*i].house)> 0)
							cout << "���g�a�W���Фl�A�Х��槹�Фl�A��g�a" << endl;
						else if (*(landpy[*i].house) == 0) {
							*(landpy[*i].buy) = -1;
							cout << "�w��X" << endl;
							*eventline = "�w�c��" + *(def[*i].initialland);
							storeevent(eventline);
							checkenter();
							*(role[*turn].money) += *(landpy[*i].landprice) / 2;
							int *num = new int(1);
							int *dice = 0;
							location(num);
							map();
						}
					}
					else
						cout << "���g�a�ä��A�֦���" << endl;
					break;
				}
			}
			if (*island == 0)
				cout << "�õL���g�a" << endl;
		}
		delete choose, eventline, island, i;
	}
	int* chartonumber(char *c)
	{
		int *i = new int(0);
		int *nint = new int(0);
		int *money = new int(0);
		int *length = new int(0);
		length = checkecharlength(c);
		if (*length > 9) {
			*money = -1;
			delete i, nint, length;
			return money;
		}
		else {
			while (*(c + *i) != '\0') {
				if (*(c + *i) < '0' || *(c + *i) > '9') {
					*nint = 1;
					break;
				}
				else
					*money = *money * 10 + *(c + *i) - '0';
				*i += 1;
			}
		}
		delete i, length;
		if (*nint == 1) {
			*money = -1;
			delete nint;
			return money;
		}
		else {
			delete nint;
			return money;
		}

	}
	int* checkecharlength(char *c) {
		int *i = new int(0);
		int *count = new int(0);
		while (*(c + *i) != '\0') {
			*i += 1;
			*count += 1;
		}
		delete i;
		return count;
	}
	void build() {
		string *choose = new string;
		string *eventline = new string;
		int *houseprice = new int(0);
		int *mustsell = new int(0);
		int *paidok = new int(0);
		if (*(landpy[*(role[*turn].position)].house) <= 4) {
			while (true)
			{
				cout << "�Ыλ���: ";
				if (*(landpy[*(role[*turn].position)].landprice) < 3000)
					*houseprice = 1000;
				else
					*houseprice = 2000;
				cout << *houseprice << endl;
				cout << "��F" << *(def[*(role[*turn].position)].initialland) << "�O�_�n�\�Фl�A��J(y)���ܭn�A��J(n)���ܤ��n" << endl;
				*eventline = *(role[*turn].name) + "��F" + *(def[*(role[*turn].position)].initialland);
				storeevent(eventline);
				getline(cin, *choose, '\n');
				if (*choose == "y") {
					if (*(role[*turn].money) < *houseprice) {
						cout << "�ѩ���������ݶi����" << endl;
						paidok = sell(houseprice, mustsell);
						if (*paidok == 1) {
							*(landpy[*(role[*turn].position)].house) += 1;
							if (*(landpy[*(role[*turn].position)].house) < 4) {
								*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + to_string(*(landpy[*(role[*turn].position)].house));
							}
							else if (*(landpy[*(role[*turn].position)].house) == 5) {
								*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + "^";
							}
							cout << "�\�Ц��\" << endl;
							*eventline = "�\�Ц��\";
							storeevent(eventline);
							checkenter();
						}
						*paidok = 0;
					}
					else {
						*(role[*turn].money) -= *houseprice;
						*(landpy[*(role[*turn].position)].house) += 1;
						if (*(landpy[*(role[*turn].position)].house) < 4) {
							*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + to_string(*(landpy[*(role[*turn].position)].house));
						}
						else if (*(landpy[*(role[*turn].position)].house) == 5) {
							*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland) + "^";
						}
						cout << "�\�Ц��\" << endl;
						*eventline = "�\�Ц��\";
						storeevent(eventline);
						checkenter();
					}
					break;
				}
				else if (*choose == "n")
					break;
			}
		}
		else {
			cout << "�w�g�L�k�A�\�Фl" << endl;
			*eventline = "�w�g�L�k�A�\�Фl";
			storeevent(eventline);
			checkenter();
		}
		delete choose, eventline, houseprice, mustsell, paidok;
	}
	int* gotojail() {
		int *eventn = new int(2);//0:n,1:over,2:jail
		string *eventline = new string;
		if (*turn<*controln)
			cout << "���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����" << endl;
		if (*turn<*controln)
			*eventline = "���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����";
		else
			*eventline = to_string((*turn + 1)) + "�����a���c�A�C������T�^�X�A���U�Ӫ��T���Y��A����N�L�k����";
		storeevent(eventline);
		if (*turn<*controln)
			checkenter();
		*(def[*(role[*turn].position)].land) = *(def[*(role[*turn].position)].initialland);
		*(role[*turn].position) = 10;
		delete eventline;
		return eventn;
	}
	void location(int *num) {
		int *same = new int(-1);
		int *i = new int(0);
		for (*i = 0; *i < *playern; *i += 1) {
			if (*(role[*i].position) == *(role[*turn].position) && *i != *turn) {
				*same = *i;
				break;
			}
		}
		if (*(landpy[*(role[*turn].position)]).house > 0) {
			if (*(landpy[*(role[*turn].position)]).house <= 4) {
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + to_string(*(landpy[*(role[*turn].position)].house));
				//delete temp;
			}
			else if (*(landpy[*(role[*turn].position)]).house == 5)
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + '^';
			if (*same != -1)
				*(def[*(role[*turn].position)]).land += *(role[*same].rolesign);
		}
		else {
			if (*same != -1)
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + *(role[*same].rolesign);
			else
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland;
		}
		if (*num == 0)
			*(role[*turn].position) += *dice;
		if (*(role[*turn].position) > 39) {
			*(role[*turn].position) -= 40;
			if (*turn < *controln) {
				string *line = new string;
				int *num = new int(0);
				stockmarket(num, line);
				while (true) {
					cout << "�ʶR�Ѳ�: b�A��X�Ѳ�: s�A���}: q" << endl;
					getline(cin, *line, '\n');
					if (*line == "s")
						sellstock();
					else if (*line == "b")
						buystock();
					else if (*line == "q")
						break;
				}

				delete num, line;
			}
			else {
				string *line = new string;
				int *num = new int(0);
				stockmarket(num, line);
				sellstockc();
				if (*(role[*turn].money)>16000)
					buystockc();
				*line = *(role[*turn].tempevent);
				storeevent(line);
				delete num, line;
			}
			if (*(role[*turn].position) != 0)
				*(role[*turn].money) += 2000;
		}
		*same = -1;
		for (*i = 0; *i < *playern; *i += 1) {
			if (*(role[*i].position) == *(role[*turn].position) && *i != *turn) {
				*same = *i;
				break;
			}
		}
		if (*(landpy[*(role[*turn].position)]).house > 0) {
			if (*(landpy[*(role[*turn].position)]).house <= 4) {
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + to_string(*(landpy[*(role[*turn].position)].house));
				//delete temp;
			}
			else if (*(landpy[*(role[*turn].position)]).house == 5)
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + '^';
			if (*same == -1)
				*(def[*(role[*turn].position)]).land += *(role[*turn].rolesign);
			else if (*(role[*turn].rolesign) == "*"&&*same != -1)
				*(def[*(role[*turn].position)]).land += "*";
			else
				*(def[*(role[*turn].position)]).land += *(role[*same].rolesign);
		}
		else {
			if (*same == -1)
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + *(role[*turn].rolesign);
			else if (*(role[*turn].rolesign) == "*"&&*same != -1)
				*(def[*(role[*turn].position)]).land = *(def[*(role[*turn].position)]).initialland + "*";
		}
		delete same, i;
	}
	void map() {
		system("CLS");
		int *begin = new int(20);
		int *end = new int(30);
		int *turn1 = new int(1);
		topdown(begin, end);
		topdownLR(begin, end, turn1);
		*turn1 = 2;
		topdownLR(begin, end, turn1);
		topdown(begin, end);
		*begin = 19;
		*end = 11;
		leftright(begin, end);
		*begin = 10;
		*end = 0;
		topdown(end, begin);
		*turn1 = 3;
		topdownLR(begin, end, turn1);
		*turn1 = 4;
		topdownLR(begin, end, turn1);
		topdown(end, begin);
		cout << endl;
		int *k = new int(0);
		for (*k = 0; *k < *playern; *k += 1) {
			cout << "����W: " << *(role[*k].name) << "����лx: " << *(role[*k].rolesign) << "  �{������: " << *(role[*k].money) << endl;
			cout << "�{���g�a: ";
			int *i = new int(0);
			for (*i = 0; *i <= 39; *i += 1) {
				if (*(landpy[*i]).buy == *k)
					cout << *(def[*i]).initialland << "  ";
			}
			cout << endl;
		}
		delete k, begin, turn1, end;
	}
	void topdown(int *begin, int *end) {
		int *i = new int(0);
		for (*i = *begin; *i <= *end; *i += 1) {
			cout.width(9);
			cout << "�@�@�@�@";
		}
		cout << endl;
		delete i;
	}
	void topdownLR(int *begin, int *end, int *turn) {
		int *i = new int(0);
		if (*turn == 1 || *turn == 2) {
			for (*i = *begin; *i <= *end; *i += 1) {
				cout << "|";
				if (*turn == 1) {
					cout.setf(ios::left);//�V�����
					cout.width(8);
					cout << *(def[*i].land);
					cout.unsetf(ios::left); //�����V������覡
				}
				else if (*turn == 2) {
					cout.width(6);
					if (*(landpy[*i].landprice) != -1)
						cout << *(landpy[*i].landprice);
					else
						cout << "    ";
					cout.width(3);
				}
				if (*i == 30)
					cout << "|";
			}
		}
		else if (*turn == 3 || *turn == 4) {
			for (*i = *begin; *i >= *end; *i -= 1) {
				cout << "|";
				if (*turn == 3) {
					cout.setf(ios::left);//�V�����
					cout.width(8);
					cout << *(def[*i].land);
					cout.unsetf(ios::left); //�����V������覡
				}
				else if (*turn == 4) {
					cout.width(6);
					if (*(landpy[*i].landprice) != -1)
						cout << *(landpy[*i].landprice);
					else
						cout << "    ";
					cout.width(3);
				}
				if (*i == 0)
					cout << "|";
			}
		}
		cout << endl;
		delete i;
	}
	void leftright(int *begin, int *end) {
		int *i = new int(0);
		int *difference = new int(12);//20,32
		int *temp = new int(0);
		for (*i = *begin; *i >= *end; *i -= 1) {
			*temp = *i + *difference;
			printcountry(i);
			printspace();
			printcountry(temp);
			cout << endl;
			printprice(i);
			printspace();
			printprice(temp);
			cout << endl;
			if (*i == *end)
				break;
			cout.width(9);
			cout << "�@�@�@�@";
			printspace();
			cout.width(9);
			cout << "�@�@�@�@";
			cout << endl;
			*difference += 2;
		}
		delete temp, difference, i;
	}
	void printcountry(int *index) {
		cout << "|";
		cout.setf(ios::left);//�V�����
		cout.width(8);
		cout << *(def[*index].land);
		cout.unsetf(ios::left); //�����V������覡
		cout << "|";
	}
	void printspace() {
		int *i = new int(0);
		for (*i = 0; *i < 9; *i += 1) {
			if (*i == 8)
				cout << "        ";
			else
				cout << "         ";
		}
		delete i;
		//i = NULL;
	}
	void printprice(int *index) {
		cout << "|";
		cout.width(6);
		if (*(landpy[*index].landprice) != -1)
			cout << *(landpy[*index].landprice);
		else
			cout << "    ";
		cout.width(3);
		cout << "|";
	}
};

int main()
{
	Cfunction *fn = new Cfunction;
	fn->start();
    return 0;
}
